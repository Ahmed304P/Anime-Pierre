import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    AnimeDetailScreen(
                        anime = anime,
                        episodes = episodes,
                        isSaved = isSaved,
                        savedStatus = savedStatus,
                        onBack = { viewModel.closeAnimeDetails() },
                        onToggleSave = { status -> viewModel.toggleSaveAnime(anime.id, status) },
                        onOpenPlayer = { ep ->
                            viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                            viewModel.openPlayer(anime, ep)
                        }
                    )"""

replacement = """                    AnimeDetailScreen(
                        anime = anime,
                        episodes = episodes,
                        isSaved = isSaved,
                        savedStatus = savedStatus,
                        onBack = { viewModel.closeAnimeDetails() },
                        onToggleSave = { status -> viewModel.toggleSaveAnime(anime.id, status) },
                        onRemoveSaved = { animeId -> viewModel.removeSavedAnime(animeId) },
                        onOpenPlayer = { ep ->
                            viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                            viewModel.openPlayer(anime, ep)
                        }
                    )"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
