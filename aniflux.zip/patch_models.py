import re

with open("app/src/main/java/com/example/data/model/Models.kt", "r") as f:
    content = f.read()

# Add ageRating and season to Anime
anime_target = """    val releaseDay: String, // "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    val trendingRank: Int = 0,
    val isFeatured: Boolean = false,
    val featuredTag: String = "جديد الموسم"
)"""
anime_replacement = """    val releaseDay: String, // "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    val trendingRank: Int = 0,
    val isFeatured: Boolean = false,
    val featuredTag: String = "جديد الموسم",
    val ageRating: String = "+13", // "+13", "+17", "للجميع"
    val season: String = "ربيع" // "ربيع", "صيف", "خريف", "شتاء"
)"""
content = content.replace(anime_target, anime_replacement)

# Update FilterState
filter_target = """data class FilterState(
    val query: String = "",
    val selectedGenre: String? = null,
    val selectedStatus: String? = null, // "مستمر", "مكتمل"
    val selectedType: String? = null, // "TV", "Movie", "OVA"
    val selectedSort: String = "الأحدث" // "الأحدث", "الأعلى تقييماً", "الأبجدي"
)"""
filter_replacement = """data class FilterState(
    val query: String = "",
    val selectedGenre: String? = null,
    val selectedStatus: String? = null,
    val selectedType: String? = null,
    val selectedSort: String = "الأحدث",
    val selectedYear: Int? = null,
    val selectedStudio: String? = null,
    val selectedAgeRating: String? = null,
    val selectedSeason: String? = null
)"""
content = content.replace(filter_target, filter_replacement)

with open("app/src/main/java/com/example/data/model/Models.kt", "w") as f:
    f.write(content)
