import re

with open("app/src/main/java/com/example/data/local/Entities.kt", "r") as f:
    content = f.read()

content = content.replace(
"""data class SavedAnimeEntity(
    @PrimaryKey val animeId: String,
    val status: String, // "FAVORITE", "WATCHING", "PLAN_TO_WATCH", "COMPLETED"
    val addedTimestamp: Long = System.currentTimeMillis()
)""",
"""data class SavedAnimeEntity(
    @PrimaryKey val animeId: String,
    val status: String, // "FAVORITE", "WATCHING", "PLAN_TO_WATCH", "COMPLETED"
    val addedTimestamp: Long = System.currentTimeMillis(),
    val userRating: Int = 0
)"""
)

with open("app/src/main/java/com/example/data/local/Entities.kt", "w") as f:
    f.write(content)
