import re

with open("app/src/main/java/com/example/ui/components/ShimmerEffect.kt", "r") as f:
    content = f.read()

content = content.replace("fun ShimmerAnimeCard(isThreeColumns: Boolean) {", "fun ShimmerAnimeCard(isThreeColumns: Boolean, index: Int = 0) {")

with open("app/src/main/java/com/example/ui/components/ShimmerEffect.kt", "w") as f:
    f.write(content)
