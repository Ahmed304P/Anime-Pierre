import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add the states before ModalNavigationDrawer
content = content.replace(
    "    ModalNavigationDrawer(",
    """    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val userAvatar by viewModel.userAvatar.collectAsStateWithLifecycle()
    val userBanner by viewModel.userBanner.collectAsStateWithLifecycle()

    ModalNavigationDrawer("""
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
