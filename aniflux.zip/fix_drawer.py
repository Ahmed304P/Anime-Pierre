import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

# Add RoundedCornerShape import
if "import androidx.compose.foundation.shape.RoundedCornerShape" not in content:
    content = content.replace("import androidx.compose.foundation.shape.CircleShape", "import androidx.compose.foundation.shape.CircleShape\nimport androidx.compose.foundation.shape.RoundedCornerShape")

# Remove the left over Row trailing code
content = re.sub(
    r'            \},\n                    horizontalArrangement = Arrangement.Center,\n                    verticalAlignment = Alignment.CenterVertically\n                \) \{\n                    Text\(\n                        text = "انقر هنا لتسجيل الدخول",\n                        color = MaterialTheme.colorScheme.onBackground,\n                        fontSize = 16.sp,\n                        fontWeight = FontWeight.Medium\n                    \)\n                \}\n            \}',
    '            }',
    content
)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
