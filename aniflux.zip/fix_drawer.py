import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

content = content.replace(
    "import coil.request.ImageRequest",
    "import coil.request.ImageRequest\nimport androidx.lifecycle.viewmodel.compose.viewModel\nimport com.example.ui.viewmodel.SocialViewModel\nimport androidx.compose.runtime.collectAsState\nimport androidx.compose.runtime.getValue\nimport androidx.compose.runtime.mutableStateOf\nimport androidx.compose.runtime.remember\nimport androidx.compose.runtime.setValue"
)

old_sig = """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    isLoggedIn: Boolean,
    userName: String,
    userAvatar: String,
    userBanner: String,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit
) {"""

new_sig = """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    isLoggedIn: Boolean,
    userName: String,
    userAvatar: String,
    userBanner: String,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit,
    socialViewModel: SocialViewModel = viewModel()
) {"""

content = content.replace(old_sig, new_sig)

# We have two instances of the notification bell to replace.
old_bell_logged_in = """                    IconButton(
                        onClick = { android.widget.Toast.makeText(mContext, "لا توجد إشعارات جديدة حالياً", android.widget.Toast.LENGTH_SHORT).show() },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .statusBarsPadding()
                            .padding(end = 12.dp, top = 12.dp)
                            .size(40.dp)
                            
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsNone,
                            contentDescription = "Notifications",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }"""

new_bell_logged_in = """                    NotificationBell(
                        viewModel = socialViewModel,
                        onOpenNotifications = {
                            // Show notifications
                        },
                        onCloseDrawer = onCloseDrawer,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .statusBarsPadding()
                            .padding(end = 12.dp, top = 12.dp),
                        tint = Color.White
                    )"""

content = content.replace(old_bell_logged_in, new_bell_logged_in)

old_bell_logged_out = """                    IconButton(
                        onClick = { android.widget.Toast.makeText(mContext, "لا توجد إشعارات جديدة حالياً", android.widget.Toast.LENGTH_SHORT).show() },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(40.dp)
                            
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsNone,
                            contentDescription = "Notifications",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(22.dp)
                        )
                    }"""

new_bell_logged_out = """                    NotificationBell(
                        viewModel = socialViewModel,
                        onOpenNotifications = {
                            // Show notifications
                        },
                        onCloseDrawer = onCloseDrawer,
                        modifier = Modifier.align(Alignment.TopEnd),
                        tint = MaterialTheme.colorScheme.onBackground
                    )"""

content = content.replace(old_bell_logged_out, new_bell_logged_out)

content += """

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationBell(
    viewModel: SocialViewModel,
    onOpenNotifications: () -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.White
) {
    val notifications by viewModel.notifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }
    var showDropdown by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        IconButton(
            onClick = { showDropdown = true },
            modifier = Modifier.size(40.dp)
        ) {
            BadgedBox(
                badge = {
                    if (unreadCount > 0) {
                        Badge(
                            containerColor = Color.Red,
                            contentColor = Color.White
                        ) {
                            Text(unreadCount.toString())
                        }
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsNone,
                    contentDescription = "Notifications",
                    tint = tint,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        
        DropdownMenu(
            expanded = showDropdown,
            onDismissRequest = { showDropdown = false },
            modifier = Modifier
                .width(280.dp)
                .background(MaterialTheme.colorScheme.surface)
        ) {
            if (notifications.isEmpty()) {
                DropdownMenuItem(
                    text = { Text("لا توجد إشعارات", color = MaterialTheme.colorScheme.onSurface) },
                    onClick = { showDropdown = false }
                )
            } else {
                notifications.forEach { notif ->
                    DropdownMenuItem(
                        text = { 
                            Column {
                                Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(notif.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        },
                        onClick = { 
                            showDropdown = false
                            viewModel.markNotificationsAsRead()
                            viewModel.setTargetScrollComment(notif.targetCommentId)
                            // We need to trigger navigation to AnimeDetailScreen if not already there, 
                            // but for simplicity, we can close drawer and it'll show if we are on the anime screen,
                            // or ideally the AppViewModel should switch to AnimeDetail.
                            // In this simple layout, we might need a global navigator.
                            // Let's assume we call a global router or we just close the drawer.
                            onCloseDrawer()
                        }
                    )
                }
            }
        }
    }
}
"""

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
