import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# 1. Add showMyListSheet state to AnimeDetailScreen
state_insertion = """    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showComments by remember { mutableStateOf(false) }"""
new_state = """    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showComments by remember { mutableStateOf(false) }
    var showMyListSheet by remember { mutableStateOf(false) }"""
content = content.replace(state_insertion, new_state)

# 2. Add ModalBottomSheet at the end of AnimeDetailScreen
target_end_of_anime_detail = """        if (showComments) {
            ModalBottomSheet(
                onDismissRequest = { showComments = false },
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxHeight(0.9f)
            ) {
                com.example.ui.components.CommentSection(
                    animeId = anime.id,
                    episodeNumber = 1 // or pass the actual episode number if contextually available
                )
            }
        }
    }
}"""
new_end_of_anime_detail = """        if (showComments) {
            ModalBottomSheet(
                onDismissRequest = { showComments = false },
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxHeight(0.9f)
            ) {
                com.example.ui.components.CommentSection(
                    animeId = anime.id,
                    episodeNumber = 1
                )
            }
        }
        
        if (showMyListSheet) {
            ModalBottomSheet(
                onDismissRequest = { showMyListSheet = false },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "قائمتي",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    val options = listOf(
                        "PLAN_TO_WATCH" to "ارغب بمشاهدتها",
                        "WATCHING" to "اشاهدها حاليا",
                        "ON_HOLD" to "اكملها لاحقا",
                        "DROPPED" to "لا ارغب بمشاهدتها"
                    )
                    
                    options.forEach { (status, text) ->
                        val isSelected = savedStatus == status
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isSelected) {
                                        onRemoveSaved(anime.id)
                                    } else {
                                        onToggleSave(status)
                                    }
                                    showMyListSheet = false
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.Check else Icons.Default.Add,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = text,
                                color = Color.White,
                                fontSize = 16.sp,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.End
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}"""
content = content.replace(target_end_of_anime_detail, new_end_of_anime_detail)

# 3. Update AnimeActionsRow invocation
old_invocation = "AnimeActionsRow(anime, onToggleSave, isSaved)"
new_invocation = "AnimeActionsRow(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })"
content = content.replace(old_invocation, new_invocation)

# 4. Update AnimeActionsRow function signature and implementation
old_actions_row = """fun AnimeActionsRow(anime: Anime, onToggleSave: (String) -> Unit, isSaved: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Rating
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Star, contentDescription = "Rating", tint = AniFluxStar, modifier = Modifier.size(32.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(text = "${anime.rating}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(text = "/10", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(bottom = 2.dp))
            }
            Text(text = "114", color = Color.Gray, fontSize = 12.sp) // Mock vote count
        }
        
        // Add Rating
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.bounceClick { }) {
            Icon(Icons.Default.StarBorder, contentDescription = "Add Rating", tint = Color.White, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "إضافة تقييم", color = Color.White, fontSize = 14.sp)
        }
        
        // My List
        Column(
            horizontalAlignment = Alignment.CenterHorizontally, 
            modifier = Modifier.bounceClick { onToggleSave("PLAN_TO_WATCH") }
        ) {
            Icon(
                imageVector = if (isSaved) Icons.Default.Check else Icons.Default.Add, 
                contentDescription = "My List", 
                tint = Color.White, 
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "قائمتي", color = Color.White, fontSize = 14.sp)
        }
    }
}"""

new_actions_row = """fun AnimeActionsRow(
    anime: Anime, 
    isSaved: Boolean, 
    savedStatus: String?, 
    onOpenMyListOptions: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Rating
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Star, contentDescription = "Rating", tint = AniFluxStar, modifier = Modifier.size(32.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(text = "${anime.rating}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(text = "/10", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(bottom = 2.dp))
            }
            Text(text = "114", color = Color.Gray, fontSize = 12.sp) // Mock vote count
        }
        
        // Add Rating
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.bounceClick { }) {
            Icon(Icons.Default.StarBorder, contentDescription = "Add Rating", tint = Color.White, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "إضافة تقييم", color = Color.White, fontSize = 14.sp)
        }
        
        // My List
        val statusTextMap = mapOf(
            "PLAN_TO_WATCH" to "ارغب بمشاهدتها",
            "WATCHING" to "اشاهدها حاليا",
            "ON_HOLD" to "اكملها لاحقا",
            "DROPPED" to "لا ارغب بمشاهدتها",
            "COMPLETED" to "تم مشاهدتها"
        )
        val currentStatusText = if (isSaved && savedStatus != null) statusTextMap[savedStatus] ?: "قائمتي" else "قائمتي"
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally, 
            modifier = Modifier.bounceClick { onOpenMyListOptions() }
        ) {
            Icon(
                imageVector = if (isSaved) Icons.Default.Check else Icons.Default.Add, 
                contentDescription = "My List", 
                tint = Color.White, 
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = currentStatusText, color = Color.White, fontSize = 14.sp)
        }
    }
}"""

content = content.replace(old_actions_row, new_actions_row)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)

