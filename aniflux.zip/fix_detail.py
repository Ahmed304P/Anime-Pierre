import re
with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# Replace var showComments by remember { mutableStateOf(false) }
content = content.replace(
    "var showComments by remember { mutableStateOf(false) }",
    "val socialViewModel: SocialViewModel = viewModel()\n    val showComments by socialViewModel.shouldOpenComments.collectAsState()"
)

# And replace `showComments = true` and `showComments = false`
content = content.replace("showComments = true", "socialViewModel.setShouldOpenComments(true)")
content = content.replace("showComments = false", "socialViewModel.setShouldOpenComments(false)")
content = content.replace("val socialViewModel: SocialViewModel = viewModel()\n        AnimeCommentsScreen(", "AnimeCommentsScreen(")

# We need to add import for collectAsState if not already present
if "import androidx.compose.runtime.collectAsState" not in content:
    content = content.replace(
        "import androidx.compose.runtime.remember",
        "import androidx.compose.runtime.collectAsState\nimport androidx.compose.runtime.remember"
    )

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
