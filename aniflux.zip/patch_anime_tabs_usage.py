import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

target = """                when (targetIndex) {
                    0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })
                    1 -> AnimeEpisodesTabContent(episodes, watchedEpisodes, onToggleWatched, onOpenPlayer)
                    2 -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("الاحصائيات (قريباً)", color = Color.Gray) }
                    3 -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("الشخصيات والطاقم (قريباً)", color = Color.Gray) }
                }"""

replacement = """                when (targetIndex) {
                    0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })
                    1 -> AnimeEpisodesTabContent(episodes, watchedEpisodes, onToggleWatched, onOpenPlayer)
                    2 -> AnimeStatsTabContent(anime, isSaved, savedStatus)
                    3 -> AnimeCharactersTabContent(anime)
                }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
