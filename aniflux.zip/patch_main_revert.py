import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    1 -> ExploreScreen(
                        allAnime = allAnime,
                        filteredAnimeList = filteredAnimeList,
                        filterState = filterState,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onGenreFilterChange = { viewModel.updateGenreFilter(it) },
                        onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onYearFilterChange = { viewModel.updateYearFilter(it) },
                        onStudioFilterChange = { viewModel.updateStudioFilter(it) },
                        onAgeRatingFilterChange = { viewModel.updateAgeRatingFilter(it) },
                        onSeasonFilterChange = { viewModel.updateSeasonFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        onOpenSearch = { isSearchOverlayVisible = true },
                        title = "لائحة الانمي"
                    )"""

replacement = """                    1 -> ExploreScreen(
                        filteredAnimeList = filteredAnimeList,
                        filterState = filterState,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onGenreFilterChange = { viewModel.updateGenreFilter(it) },
                        onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        onOpenSearch = { isSearchOverlayVisible = true },
                        title = "لائحة الانمي"
                    )"""
content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
