import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# The string to remove:
bad_block = """                
                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تأكيد الخروج", color = Color.White) },
                        text = { Text("هل أنت متأكد أنك تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("إلغاء", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }"""

# Remove all bad blocks completely
content = content.replace(bad_block, "")

# Now find the correct place to insert it.
# It should be at the end of the `AniFluxAppShell` function.
# Let's look for the end of `AniFluxAppShell`.
# Wait, actually, the last overlay inside the `Box` is the `VideoPlayerModal` AnimatedVisibility block.
# Let's find:
target_insertion = """                            }
                        )
                    }
                }
                            
            }
        }
    }
}"""

replacement_insertion = """                            }
                        )
                    }
                }""" + bad_block + """
            }
        }
    }
}"""

content = content.replace(target_insertion, replacement_insertion)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

