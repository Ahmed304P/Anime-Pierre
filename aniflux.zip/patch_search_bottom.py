import re

with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "r") as f:
    content = f.read()

target = """            // Results Grid"""
replacement = """            if (showFilterSheet) {
                FilterBottomSheet(
                    allAnime = allAnime,
                    filterState = filterState,
                    onDismiss = { showFilterSheet = false },
                    onGenreFilterChange = onGenreFilterChange,
                    onStatusFilterChange = onStatusFilterChange,
                    onTypeFilterChange = onTypeFilterChange,
                    onYearFilterChange = onYearFilterChange,
                    onStudioFilterChange = onStudioFilterChange,
                    onAgeRatingFilterChange = onAgeRatingFilterChange,
                    onSeasonFilterChange = onSeasonFilterChange,
                    onResetFilters = onResetFilters
                )
            }

            // Results Grid"""

if target in content and "if (showFilterSheet) {" not in content:
    content = content.replace(target, replacement)
else:
    print("Not found or already added")

with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "w") as f:
    f.write(content)
