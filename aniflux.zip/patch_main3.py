import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    1 -> ExploreScreen(
                        filteredAnimeList = allAnime,
                        filterState = filterState,"""

replacement = """                    1 -> ExploreScreen(
                        allAnime = allAnime,
                        filteredAnimeList = filteredAnimeList,
                        filterState = filterState,"""

content = content.replace(target, replacement)

# Now, we also need to add the new callbacks to MainActivity -> ExploreScreen
target2 = """                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },"""

replacement2 = """                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onYearFilterChange = { viewModel.updateYearFilter(it) },
                        onStudioFilterChange = { viewModel.updateStudioFilter(it) },
                        onAgeRatingFilterChange = { viewModel.updateAgeRatingFilter(it) },
                        onSeasonFilterChange = { viewModel.updateSeasonFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },"""

content = content.replace(target2, replacement2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
