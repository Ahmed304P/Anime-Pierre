with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if "enter = slideInVertically(initialOffsetY = { it }" in line:
        new_lines.append("                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(animationSpec = tween(300)),\n")
        new_lines.append("                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300)) + fadeOut(animationSpec = tween(300))\n")
        new_lines.append("                ) {\n")
        skip = True
        continue
    
    if skip:
        # We are skipping until we find the end of the injected block.
        # The injected block ends with `                }` which is the end of the if statement.
        # Let's just look for `containerColor = MaterialTheme.colorScheme.surface,` which is near the end,
        # and skip 3 more lines.
        if "                    )" in line:
            # wait, it's safer to skip a fixed number of lines. The bad block is exactly 19 lines long.
            pass
        if "                }" in line and "textContentColor = Color.LightGray" in lines[i-2]:
            skip = False
            continue
        continue
        
    new_lines.append(line)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.writelines(new_lines)
