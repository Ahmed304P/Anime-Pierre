import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("val allAnime by viewModel.allAnime.collectAsStateWithLifecycle()", 
"val allAnime by viewModel.allAnime.collectAsStateWithLifecycle()\n                val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()")

content = content.replace(
"""                    0 -> HomeScreen(
                        allAnime = allAnime,""",
"""                    0 -> HomeScreen(
                        allAnime = allAnime,
                        isLoading = isLoading,"""
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
