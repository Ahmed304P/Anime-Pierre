with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("notif.targetReplyId", "notif.parentThreadId")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
