import re
with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    text = f.read()

text = text.replace(
    ".background(Color.Black.copy(alpha = 0.4f), CircleShape)",
    ""
)

text = text.replace(
    ".background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)",
    ""
)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(text)
