import re

with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "r") as f:
    content = f.read()

# Fix the import issue
content = content.replace("import androidx.compose.ui.draw.drawWithContent\npackage com.example.ui.components", "package com.example.ui.components\nimport androidx.compose.ui.draw.drawWithContent")

with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "w") as f:
    f.write(content)
