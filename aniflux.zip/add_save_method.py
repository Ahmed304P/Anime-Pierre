import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

target = """    init {
        viewModelScope.launch {
            delay(1500) // Simulate network load
            _allAnime.value = repository.sampleAnimeList
            _isLoading.value = false
        }
    }"""

replacement = """    init {
        viewModelScope.launch {
            delay(1500) // Simulate network load
            _allAnime.value = repository.sampleAnimeList
            _isLoading.value = false
        }
    }
    
    fun saveAnime(anime: Anime) {
        val currentList = _allAnime.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == anime.id }
        if (index != -1) {
            currentList[index] = anime
        } else {
            currentList.add(0, anime)
        }
        _allAnime.value = currentList
    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
