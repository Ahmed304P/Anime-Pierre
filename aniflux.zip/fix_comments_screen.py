import re

new_content = """package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import com.example.ui.components.bounceClick
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.viewmodel.SocialViewModel
import com.example.ui.viewmodel.AnimeComment
import com.example.ui.viewmodel.CommentReply
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimeCommentsScreen(
    viewModel: SocialViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var commentText by remember { mutableStateOf("") }
    var isSpoilerMode by remember { mutableStateOf(false) }
    val spoilerIconColor by animateColorAsState(targetValue = if (isSpoilerMode) Color.Red else Color.Gray, animationSpec = tween(300))
    val comments by viewModel.comments.collectAsState()
    val targetScrollCommentId by viewModel.targetScrollCommentId.collectAsState()
    val replyingToComment by viewModel.replyingToComment.collectAsState()
    
    val listState = rememberLazyListState()
    
    LaunchedEffect(targetScrollCommentId) {
        if (targetScrollCommentId != null) {
            val (commentId, replyId) = targetScrollCommentId!!
            val index = comments.indexOfFirst { it.id == commentId }
            if (index != -1) {
                listState.animateScrollToItem(index)
                delay(2000)
                viewModel.clearHighlight(commentId, replyId)
                viewModel.setTargetScrollComment(null, null)
            }
        }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "التعليقات (${comments.size})", 
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Sort options */ }) {
                        Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.background,
                modifier = Modifier.fillMaxWidth(),
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Column {
                    AnimatedVisibility(visible = replyingToComment != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "يتم الرد على ${replyingToComment?.username}",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = { viewModel.setReplyingTo(null) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel Reply", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { isSpoilerMode = !isSpoilerMode },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Spoiler Toggle",
                                tint = spoilerIconColor,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(start = 16.dp, end = 4.dp)
                            ) {
                                TextField(
                                    value = commentText,
                                    onValueChange = { commentText = it },
                                    placeholder = { Text("أضف تعليقاً...", color = Color.Gray, fontSize = 14.sp) },
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent,
                                        cursorColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier.weight(1f),
                                    textStyle = LocalTextStyle.current.copy(color = Color.White)
                                )
                                IconButton(onClick = { 
                                    if(commentText.isNotBlank()) {
                                        viewModel.addComment(commentText, isSpoilerMode)
                                        commentText = ""
                                        isSpoilerMode = false
                                    }
                                }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Send",
                                        tint = if (commentText.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(items = comments, key = { it.id }) { comment ->
                CommentItem(
                    comment = comment,
                    onLikeClick = { viewModel.toggleLike(comment.id) },
                    onDislikeClick = { viewModel.toggleDislike(comment.id) },
                    onReplyClick = { viewModel.setReplyingTo(comment) },
                    onReplyLikeClick = { replyId -> viewModel.toggleLike(comment.id, replyId) },
                    onReplyDislikeClick = { replyId -> viewModel.toggleDislike(comment.id, replyId) }
                )
                HorizontalDivider(color = Color.White.copy(alpha = 0.1f), thickness = 1.dp)
            }
        }
    }
}

@Composable
fun CommentItem(
    comment: AnimeComment,
    onLikeClick: () -> Unit,
    onDislikeClick: () -> Unit,
    onReplyClick: () -> Unit,
    onReplyLikeClick: (Int) -> Unit,
    onReplyDislikeClick: (Int) -> Unit
) {
    var isRevealed by remember { mutableStateOf(false) }
    val highlightColor by animateColorAsState(
        targetValue = if (comment.isHighlighted) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent,
        animationSpec = tween(1000)
    )
    
    var likeScale by remember { mutableStateOf(1f) }
    val animatedLikeScale by animateFloatAsState(
        targetValue = likeScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    
    var dislikeScale by remember { mutableStateOf(1f) }
    val animatedDislikeScale by animateFloatAsState(
        targetValue = dislikeScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    
    var replyScale by remember { mutableStateOf(1f) }
    val animatedReplyScale by animateFloatAsState(
        targetValue = replyScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    
    val likeColor = if (comment.isLiked) Color.Red else Color.Gray
    val dislikeColor = if (comment.isDisliked) Color.Yellow else Color.Gray

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(highlightColor)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(comment.avatarUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Avatar",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = comment.username,
                        color = Color.LightGray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = comment.timeAgo,
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                AnimatedContent(
                    targetState = comment.isSpoiler && !isRevealed,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                    },
                    label = "SpoilerRevealAnimation"
                ) { isHidden ->
                    if (isHidden) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isRevealed = true }
                                .background(Color.Red.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "التعليق يحتوي على حرق, اضغط هنا للمشاهدة",
                                color = Color.Red,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            text = comment.text,
                            color = Color.White,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Like
                        Row(
                            verticalAlignment = Alignment.CenterVertically, 
                            modifier = Modifier.clickable { 
                                likeScale = 1.3f
                                onLikeClick()
                            }
                        ) {
                            LaunchedEffect(likeScale) {
                                if (likeScale > 1f) { delay(100); likeScale = 1f }
                            }
                            Icon(
                                Icons.Default.ThumbUp, 
                                contentDescription = "Like", 
                                tint = likeColor, 
                                modifier = Modifier.size(18.dp).scale(animatedLikeScale)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${comment.likes}", color = likeColor, fontSize = 14.sp)
                        }
                        
                        // Dislike
                        Row(
                            verticalAlignment = Alignment.CenterVertically, 
                            modifier = Modifier.clickable { 
                                dislikeScale = 1.3f
                                onDislikeClick()
                            }
                        ) {
                            LaunchedEffect(dislikeScale) {
                                if (dislikeScale > 1f) { delay(100); dislikeScale = 1f }
                            }
                            Icon(
                                Icons.Default.ThumbDown, 
                                contentDescription = "Dislike", 
                                tint = dislikeColor, 
                                modifier = Modifier.size(18.dp).scale(animatedDislikeScale)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${comment.dislikes}", color = dislikeColor, fontSize = 14.sp)
                        }
                        
                        // Reply
                        Row(
                            verticalAlignment = Alignment.CenterVertically, 
                            modifier = Modifier.clickable {
                                replyScale = 1.3f
                                onReplyClick()
                            }
                        ) {
                            LaunchedEffect(replyScale) {
                                if (replyScale > 1f) { delay(100); replyScale = 1f }
                            }
                            Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Reply", tint = Color.Gray, modifier = Modifier.size(18.dp).scale(animatedReplyScale))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${comment.replies}", color = Color.Gray, fontSize = 14.sp)
                        }
                    }
                    
                    IconButton(
                        onClick = { },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.Gray)
                    }
                }
            }
        }
        
        // Render Replies
        if (comment.repliesList.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 32.dp)
            ) {
                comment.repliesList.forEach { reply ->
                    ReplyItem(
                        reply = reply,
                        onLikeClick = { onReplyLikeClick(reply.id) },
                        onDislikeClick = { onReplyDislikeClick(reply.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun ReplyItem(
    reply: CommentReply,
    onLikeClick: () -> Unit,
    onDislikeClick: () -> Unit
) {
    var isRevealed by remember { mutableStateOf(false) }
    val highlightColor by animateColorAsState(
        targetValue = if (reply.isHighlighted) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent,
        animationSpec = tween(1000)
    )
    
    var likeScale by remember { mutableStateOf(1f) }
    val animatedLikeScale by animateFloatAsState(
        targetValue = likeScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    var dislikeScale by remember { mutableStateOf(1f) }
    val animatedDislikeScale by animateFloatAsState(
        targetValue = dislikeScale,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    
    val likeColor = if (reply.isLiked) Color.Red else Color.Gray
    val dislikeColor = if (reply.isDisliked) Color.Yellow else Color.Gray

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(highlightColor, RoundedCornerShape(8.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(reply.avatarUrl)
                .crossfade(true)
                .build(),
            contentDescription = "Avatar",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = reply.username,
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = reply.timeAgo,
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            
            AnimatedContent(
                targetState = reply.isSpoiler && !isRevealed,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                },
                label = "SpoilerRevealAnimation"
            ) { isHidden ->
                if (isHidden) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isRevealed = true }
                            .background(Color.Red.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "التعليق يحتوي على حرق, اضغط هنا للمشاهدة",
                            color = Color.Red,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        text = reply.text,
                        color = Color.White,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Like
                Row(
                    verticalAlignment = Alignment.CenterVertically, 
                    modifier = Modifier.clickable { 
                        likeScale = 1.3f
                        onLikeClick()
                    }
                ) {
                    LaunchedEffect(likeScale) {
                        if (likeScale > 1f) { delay(100); likeScale = 1f }
                    }
                    Icon(
                        Icons.Default.ThumbUp, 
                        contentDescription = "Like", 
                        tint = likeColor, 
                        modifier = Modifier.size(16.dp).scale(animatedLikeScale)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("${reply.likes}", color = likeColor, fontSize = 12.sp)
                }
                
                // Dislike
                Row(
                    verticalAlignment = Alignment.CenterVertically, 
                    modifier = Modifier.clickable { 
                        dislikeScale = 1.3f
                        onDislikeClick()
                    }
                ) {
                    LaunchedEffect(dislikeScale) {
                        if (dislikeScale > 1f) { delay(100); dislikeScale = 1f }
                    }
                    Icon(
                        Icons.Default.ThumbDown, 
                        contentDescription = "Dislike", 
                        tint = dislikeColor, 
                        modifier = Modifier.size(16.dp).scale(animatedDislikeScale)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("${reply.dislikes}", color = dislikeColor, fontSize = 12.sp)
                }
            }
        }
    }
}
"""

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "w") as f:
    f.write(new_content)
