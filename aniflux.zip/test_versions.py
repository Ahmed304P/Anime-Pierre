with open("gradle/libs.versions.toml", "r") as f:
    content = f.read()

content = content.replace('kotlin = "2.2.10"', 'kotlin = "2.0.21"')
content = content.replace('googleDevtoolsKsp = "2.3.5"', 'googleDevtoolsKsp = "2.0.21-1.0.27"')

with open("gradle/libs.versions.toml", "w") as f:
    f.write(content)
