import re

with open("app/src/main/java/com/example/data/local/AniFluxDatabase.kt", "r") as f:
    content = f.read()

content = content.replace(
    "entities = [SavedAnimeEntity::class, WatchHistoryEntity::class, LocalCommentEntity::class, CustomListEntity::class, CustomListItemEntity::class]",
    "entities = [SavedAnimeEntity::class, WatchHistoryEntity::class, LocalCommentEntity::class, CustomListEntity::class, CustomListItemEntity::class, WatchedEpisodeEntity::class]"
)
content = content.replace("version = 2,", "version = 3,")

with open("app/src/main/java/com/example/data/local/AniFluxDatabase.kt", "w") as f:
    f.write(content)
