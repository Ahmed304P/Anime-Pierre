import os
import re

files_to_update = [
    "app/src/main/java/com/example/ui/screens/MyListScreen.kt",
    "app/src/main/java/com/example/ui/screens/FavoritesScreen.kt",
    "app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt",
    "app/src/main/java/com/example/ui/screens/CustomListDetailScreen.kt",
    "app/src/main/java/com/example/ui/screens/SeasonsScreen.kt",
    "app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt",
    "app/src/main/java/com/example/ui/screens/LibraryScreen.kt"
]

for file_path in files_to_update:
    if not os.path.exists(file_path):
        continue
        
    with open(file_path, "r") as f:
        content = f.read()

    # If the file has GridCells.Fixed(3), replace it with GridCells.Fixed(if (isGridMode) 3 else 1)
    if "GridCells.Fixed(3)" in content:
        content = content.replace("GridCells.Fixed(3)", "GridCells.Fixed(if (isGridMode) 3 else 1)")
        
    # Replace the AnimeCard or HistoryAnimeCard to use AnimeListCard or whatever depending on isGridMode
    # It's easier to manually review, but we can try a regex
    # Wait, some screens use HistoryAnimeCard, some use AnimeCard.
    # We will do this manually for each to ensure correctness.
    
    with open(file_path, "w") as f:
        f.write(content)

print("Done")
