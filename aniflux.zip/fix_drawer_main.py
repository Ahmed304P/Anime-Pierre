import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace(
    """            AnimeSlayerDrawerContent(
                selectedTab = selectedTab,
                isLoggedIn = isLoggedIn,
                userName = userName,
                userAvatar = userAvatar,
                userBanner = userBanner,
                onSelectTab = { tabIndex -> viewModel.setSelectedTab(tabIndex) },
                onCloseDrawer = { scope.launch { drawerState.close() } }
            )""",
    """            AnimeSlayerDrawerContent(
                selectedTab = selectedTab,
                isLoggedIn = isLoggedIn,
                userName = userName,
                userAvatar = userAvatar,
                userBanner = userBanner,
                onSelectTab = { tabIndex -> viewModel.setSelectedTab(tabIndex) },
                onCloseDrawer = { scope.launch { drawerState.close() } },
                socialViewModel = socialViewModel,
                onNotificationClicked = {
                    if (allAnime.isNotEmpty() && selectedAnimeDetails == null) {
                        viewModel.openAnimeDetails(allAnime.first())
                    }
                    socialViewModel.setShouldOpenComments(true)
                }
            )"""
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
