import re

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "r") as f:
    text = f.read()

# Update signature
text = text.replace(
    "title: String = \"لائحة الانمي\",\n    modifier: Modifier = Modifier\n) {",
    "title: String = \"لائحة الانمي\",\n    isGridMode: Boolean = true,\n    onToggleGridMode: () -> Unit = {},\n    modifier: Modifier = Modifier\n) {"
)

# Remove local state
text = text.replace("    var isGridView by remember { mutableStateOf(true) }\n", "")

# Replace isGridView with isGridMode
text = text.replace("isGridView", "isGridMode")
text = text.replace("onClick = { isGridMode = !isGridMode }", "onClick = onToggleGridMode")

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "w") as f:
    f.write(text)
