import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

replacement = """    // --- Custom Lists ---
    fun getAllCustomLists(): Flow<List<CustomListEntity>> = dao.getAllCustomLists()
    
    suspend fun createCustomList(name: String, description: String): Long {
        return dao.insertCustomList(CustomListEntity(name = name, description = description))
    }
    
    suspend fun deleteCustomList(listId: Long) {
        dao.deleteCustomListItems(listId)
        dao.deleteCustomList(listId)
    }
    
    fun getCustomListItems(listId: Long): Flow<List<CustomListItemEntity>> = dao.getCustomListItems(listId)
    
    suspend fun addAnimeToCustomList(listId: Long, animeId: String) {
        dao.insertCustomListItem(CustomListItemEntity(listId = listId, animeId = animeId))
    }
    
    suspend fun removeAnimeFromCustomList(listId: Long, animeId: String) {
        dao.deleteCustomListItem(listId, animeId)
    }
}"""

content = content.replace("}", replacement)
# Wait, this will replace all closing braces. Let's do it safely.
# Replace the very last closing brace.
content = content[:content.rfind("}")] + replacement

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
    f.write(content)
