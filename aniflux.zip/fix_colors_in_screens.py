import os
import re

color_mappings = {
    "AniFluxBg": "MaterialTheme.colorScheme.background",
    "AniFluxSurfaceVariant": "MaterialTheme.colorScheme.surfaceVariant",
    "AniFluxSurface": "MaterialTheme.colorScheme.surface",
    "AniFluxTextPrimary": "MaterialTheme.colorScheme.onBackground",
    "AniFluxTextSecondary": "MaterialTheme.colorScheme.onSurfaceVariant",
    "AniFluxPrimary": "MaterialTheme.colorScheme.primary"
}

def process_file(filepath):
    with open(filepath, "r") as f:
        content = f.read()

    changed = False
    for k, v in color_mappings.items():
        if k in content and f"val {k}" not in content:
            content = re.sub(r'\b' + k + r'\b', v, content)
            changed = True

    if changed:
        if "import androidx.compose.material3.MaterialTheme" not in content:
            content = content.replace("import androidx.compose.material3.*", "import androidx.compose.material3.*\nimport androidx.compose.material3.MaterialTheme")
            if "import androidx.compose.material3.MaterialTheme" not in content:
                content = content.replace("import androidx.compose.runtime.*", "import androidx.compose.runtime.*\nimport androidx.compose.material3.MaterialTheme")
        
        # Remove unused imports
        for k in color_mappings.keys():
            content = re.sub(r'import com\.example\.ui\.theme\.' + k + r'\n', '', content)
            
        with open(filepath, "w") as f:
            f.write(content)

for root, _, files in os.walk("app/src/main/java/com/example/ui"):
    for file in files:
        if file.endswith(".kt"):
            process_file(os.path.join(root, file))

process_file("app/src/main/java/com/example/MainActivity.kt")
