import re
with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "r") as f:
    content = f.read()

# Add isSpoilerMode state and animateColor
old_var_comment = 'var commentText by remember { mutableStateOf("") }'
new_var_comment = '''var commentText by remember { mutableStateOf("") }
    var isSpoilerMode by remember { mutableStateOf(false) }
    val spoilerIconColor by animateColorAsState(targetValue = if (isSpoilerMode) Color.Red else Color.Gray, animationSpec = tween(300))'''
content = content.replace(old_var_comment, new_var_comment)

# Update Fire Department icon to be clickable and use animated color
old_fire = '''                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Hot",
                        tint = Color.Gray,
                        modifier = Modifier.size(28.dp)
                    )'''
new_fire = '''                    IconButton(
                        onClick = { isSpoilerMode = !isSpoilerMode },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Spoiler Toggle",
                            tint = spoilerIconColor,
                            modifier = Modifier.size(28.dp)
                        )
                    }'''
content = content.replace(old_fire, new_fire)

# Update Send button logic
old_send = '''IconButton(onClick = { if(commentText.isNotBlank()) commentText = "" }) {'''
new_send = '''IconButton(onClick = { 
                                if(commentText.isNotBlank()) {
                                    viewModel.addComment(commentText, isSpoilerMode)
                                    commentText = ""
                                    isSpoilerMode = false
                                }
                            }) {'''
content = content.replace(old_send, new_send)

# Add isRevealed to CommentItem
old_comment_item = '''fun CommentItem(
    comment: AnimeComment,
    onLikeClick: () -> Unit,
    onDislikeClick: () -> Unit
) {'''
new_comment_item = '''fun CommentItem(
    comment: AnimeComment,
    onLikeClick: () -> Unit,
    onDislikeClick: () -> Unit
) {
    var isRevealed by remember { mutableStateOf(false) }'''
content = content.replace(old_comment_item, new_comment_item)

# Update Text rendering for Spoiler
old_text = '''Text(
                    text = comment.text,
                    color = Color.White,
                    fontSize = 15.sp,
                    lineHeight = 22.sp
                )'''

new_text = '''AnimatedContent(
                    targetState = comment.isSpoiler && !isRevealed,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                    },
                    label = "SpoilerRevealAnimation"
                ) { isHidden ->
                    if (isHidden) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isRevealed = true }
                                .background(Color.Red.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "التعليق يحتوي على حرق, اضغط هنا للمشاهدة",
                                color = Color.Red,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            text = comment.text,
                            color = Color.White,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        )
                    }
                }'''
content = content.replace(old_text, new_text)

# We need to make sure to import togetherWith
if 'togetherWith' not in content:
    content = content.replace('import androidx.compose.animation.core.*', 'import androidx.compose.animation.core.*\nimport androidx.compose.animation.togetherWith')

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "w") as f:
    f.write(content)

