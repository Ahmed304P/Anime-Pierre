import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

bad_block = """                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تأكيد الخروج", color = Color.White) },
                        text = { Text("هل أنت متأكد أنك تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("إلغاء", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }"""

# Since the file ends with a bunch of closing braces, let's just use regex to replace the final braces.
# We will replace the final `            }\n        }\n    }\n}}}` with the block + braces.
# Let's just find the `VideoPlayerModal` call.

modal_end = r"VideoPlayerModal\([\s\S]*?onRecordProgress = \{[\s\S]*?\}\n                        \)\n                    \}\n                \}"

match = re.search(modal_end, content)
if match:
    insert_pos = match.end()
    content = content[:insert_pos] + "\n" + bad_block + "\n" + content[insert_pos:]
    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content)
    print("Success")
else:
    print("Failed")

