import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

content = content.replace(
    ".padding(horizontal = 20.dp, top = 12.dp, bottom = 32.dp)",
    ".padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 32.dp)"
)

# And fix the toast context
content = content.replace(
    """) {
    Surface(""",
    """) {
    val context = LocalContext.current
    Surface("""
)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
