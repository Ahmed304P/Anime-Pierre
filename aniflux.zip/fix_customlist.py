import re
with open("app/src/main/java/com/example/ui/screens/CustomListDetailScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    "onRemove = { onRemoveAnime(anime.id) }\n                                )",
    "onRemove = { onRemoveAnime(anime.id) },\n                                    isGridMode = isGridMode\n                                )"
)

with open("app/src/main/java/com/example/ui/screens/CustomListDetailScreen.kt", "w") as f:
    f.write(text)
