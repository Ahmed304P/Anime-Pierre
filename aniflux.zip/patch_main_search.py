import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                SearchScreenOverlay(
                    visible = isSearchOverlayVisible,
                    onClose = { isSearchOverlayVisible = false },
                    searchQuery = filterState.query,
                    onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                    searchResults = filteredAnimeList,
                    onOpenAnimeDetails = { viewModel.openAnimeDetails(it) }
                )"""

replacement = """                SearchScreenOverlay(
                    visible = isSearchOverlayVisible,
                    onClose = { isSearchOverlayVisible = false },
                    searchQuery = filterState.query,
                    onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                    searchResults = filteredAnimeList,
                    onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                    allAnime = allAnime,
                    filterState = filterState,
                    onGenreFilterChange = { viewModel.updateGenreFilter(it) },
                    onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                    onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                    onYearFilterChange = { viewModel.updateYearFilter(it) },
                    onStudioFilterChange = { viewModel.updateStudioFilter(it) },
                    onAgeRatingFilterChange = { viewModel.updateAgeRatingFilter(it) },
                    onSeasonFilterChange = { viewModel.updateSeasonFilter(it) },
                    onResetFilters = { viewModel.resetFilters() }
                )"""
content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
