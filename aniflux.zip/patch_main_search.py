import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Update BackHandler
content = content.replace(
    "} else if (isSearchOverlayVisible) {\n            isSearchOverlayVisible = false\n        }",
    "} else if (isSearchOverlayVisible) {\n            isSearchOverlayVisible = false\n            viewModel.updateSearchQuery(\"\")\n        }"
)

# Update SearchScreenOverlay arguments
content = content.replace(
    "onClose = { isSearchOverlayVisible = false },",
    "onClose = { \n                        isSearchOverlayVisible = false\n                        viewModel.updateSearchQuery(\"\")\n                    },"
)

content = content.replace(
    "onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },",
    "onOpenAnimeDetails = { \n                        isSearchOverlayVisible = false\n                        viewModel.updateSearchQuery(\"\")\n                        viewModel.openAnimeDetails(it)\n                    },"
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
