import os

files = [
    "app/src/main/java/com/example/ui/screens/LibraryScreen.kt",
    "app/src/main/java/com/example/ui/screens/RecommendationsScreen.kt",
    "app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt",
    "app/src/main/java/com/example/ui/screens/AiAssistantScreen.kt",
    "app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt"
]

for filepath in files:
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            content = f.read()
        
        if "androidx.compose.foundation.lazy.itemsIndexed" not in content:
            content = content.replace("import androidx.compose.foundation.lazy.items", "import androidx.compose.foundation.lazy.items\nimport androidx.compose.foundation.lazy.itemsIndexed")
        if "androidx.compose.foundation.lazy.grid.itemsIndexed" not in content and "LazyVerticalGrid" in content:
            content = content.replace("import androidx.compose.foundation.lazy.grid.items", "import androidx.compose.foundation.lazy.grid.items\nimport androidx.compose.foundation.lazy.grid.itemsIndexed")
            
        with open(filepath, "w") as f:
            f.write(content)
