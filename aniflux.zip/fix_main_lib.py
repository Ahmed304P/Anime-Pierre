import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    text = f.read()

text = text.replace(
    "onOpenMenu = { scope.launch { drawerState.open() } }\n                        )",
    "onOpenMenu = { scope.launch { drawerState.open() } },\n                            isGridMode = isGridMode\n                        )"
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(text)
