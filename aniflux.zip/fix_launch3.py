import re

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

# Add the import back
content = content.replace("import kotlinx.coroutines.delay", "import kotlinx.coroutines.delay\nimport kotlinx.coroutines.launch")

# Replace inner launches inside coroutine scope
content = content.replace(
    """                    LaunchedEffect(anime.id) {
                        launch { animatedAlpha.animateTo(1f, androidx.compose.animation.core.tween(500)) }
                        launch { animatedTranslationY.animateTo(0f, androidx.compose.animation.core.tween(500)) }
                    }""",
    """                    LaunchedEffect(anime.id) {
                        launch { animatedAlpha.animateTo(1f, androidx.compose.animation.core.tween(500)) }
                        launch { animatedTranslationY.animateTo(0f, androidx.compose.animation.core.tween(500)) }
                    }"""
)

# Replace any occurrence of just 'launch' not part of 'coroutineScope.launch'
# Actually wait, `launch` is an extension function on CoroutineScope.
# `LaunchedEffect` provides a `CoroutineScope` receiver. So `launch` SHOULD be resolved if we have `kotlinx.coroutines.launch` imported.
# Let's ensure the import is there.

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
