import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

content = content.replace("dao.getWatchedEpisodesForAnime", "db.dao().getWatchedEpisodesForAnime")
content = content.replace("dao.insertWatchedEpisode", "db.dao().insertWatchedEpisode")
content = content.replace("dao.removeWatchedEpisode", "db.dao().removeWatchedEpisode")

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
