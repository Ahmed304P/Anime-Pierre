with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "r") as f:
    content = f.read()

bad_transition = """slideInHorizontally(initialOffsetX = { if (it) it else -it }) togetherWith slideOutHorizontally(targetOffsetX = { if (it) -it else it })"""
good_transition = """if (targetState) {
                slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
            } else {
                slideInHorizontally { -it } togetherWith slideOutHorizontally { it }
            }"""

content = content.replace(bad_transition, good_transition)

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "w") as f:
    f.write(content)
