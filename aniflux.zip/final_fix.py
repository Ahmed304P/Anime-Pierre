import re

with open("app/src/main/java/com/example/ui/screens/AdminAnimeEditScreen.kt", "r") as f:
    content = f.read()

# Fix the import location
content = content.replace("import com.example.data.model.Anime\n@OptIn", "@OptIn")
content = content.replace("import androidx.compose.foundation.background", "import androidx.compose.foundation.background\nimport com.example.data.model.Anime")

# Fix Anime creation
target = """                    val newAnime = Anime(
                        id = currentId,
                        titleAr = titleAr.ifBlank { "أنمي جديد" },
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsis = synopsisAr,
                        status = status,
                        type = type,
                        year = year,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24
                    )"""

replacement = """                    val newAnime = Anime(
                        id = currentId,
                        titleAr = titleAr.ifBlank { "أنمي جديد" },
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsisAr = synopsisAr,
                        status = status,
                        type = type,
                        year = year.toIntOrNull() ?: 2026,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24,
                        releaseDay = "الأحد"
                    )"""

content = content.replace(target, replacement)

target2 = """                    val newAnime = Anime(
                        id = animeId ?: java.util.UUID.randomUUID().toString(),
                        titleAr = titleAr,
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsis = synopsisAr,
                        status = status,
                        type = type,
                        year = year,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24
                    )"""

replacement2 = """                    val newAnime = Anime(
                        id = animeId ?: java.util.UUID.randomUUID().toString(),
                        titleAr = titleAr,
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsisAr = synopsisAr,
                        status = status,
                        type = type,
                        year = year.toIntOrNull() ?: 2026,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24,
                        releaseDay = "الأحد"
                    )"""

content = content.replace(target2, replacement2)

with open("app/src/main/java/com/example/ui/screens/AdminAnimeEditScreen.kt", "w") as f:
    f.write(content)

