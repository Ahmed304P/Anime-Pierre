import re

with open("app/src/main/java/com/example/ui/screens/CustomListsScreen.kt", "r") as f:
    content = f.read()
content = content.replace('"لا يوجد قوائم مخصصة"', '"لا يوجد بيانات"')
with open("app/src/main/java/com/example/ui/screens/CustomListsScreen.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/ui/screens/CustomListDetailScreen.kt", "r") as f:
    content2 = f.read()
content2 = content2.replace('"القائمة فارغة"', '"لا يوجد بيانات"')
with open("app/src/main/java/com/example/ui/screens/CustomListDetailScreen.kt", "w") as f:
    f.write(content2)
