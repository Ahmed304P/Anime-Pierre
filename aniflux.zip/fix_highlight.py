import re
with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "r") as f:
    content = f.read()

# Clear highlight after 2 seconds
content = content.replace(
    """        if (targetScrollCommentId != null) {
            val index = comments.indexOfFirst { it.id == targetScrollCommentId }
            if (index != -1) {
                listState.animateScrollToItem(index)
            }
        }""",
    """        if (targetScrollCommentId != null) {
            val index = comments.indexOfFirst { it.id == targetScrollCommentId }
            if (index != -1) {
                listState.animateScrollToItem(index)
                delay(2000)
                viewModel.clearHighlight(targetScrollCommentId!!)
                viewModel.setTargetScrollComment(null)
            }
        }"""
)

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "w") as f:
    f.write(content)
