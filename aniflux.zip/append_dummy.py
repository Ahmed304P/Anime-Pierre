import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

dummy_items = ""
for i in range(1, 16):
    dummy_items += f"""        Anime(
            id = "dummy_{i}",
            titleAr = "انمي وهمي {i}",
            titleEn = "Fake Anime {i}",
            posterUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop",
            rating = 8.{i % 10},
            totalEpisodes = 24,
            currentEpisodes = {i + 5},
            status = "مكتمل",
            type = "TV",
            year = 2023,
            studio = "Studio {i}",
            synopsisAr = "هذا نص تجريبي لمعلومات الانمي الوهمي رقم {i}. يتم استخدامه فقط كعنصر وهمي لتجربة التطبيق.",
            genres = listOf("أكشن", "خيال"),
            releaseDay = "الاثنين",
            trendingRank = {i + 10},
            isFeatured = false
        ),
"""

# We can insert these right after the opening of the list
content = content.replace("    val sampleAnimeList = listOf(", "    val sampleAnimeList = listOf(\n" + dummy_items)

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
    f.write(content)
