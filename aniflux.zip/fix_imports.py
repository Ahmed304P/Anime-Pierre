import re
import os

files = [
    "app/src/main/java/com/example/ui/components/AnimeCard.kt",
    "app/src/main/java/com/example/ui/screens/ExploreScreen.kt",
    "app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt"
]

imports_to_add = """
import kotlinx.coroutines.launch
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
"""

for f_path in files:
    with open(f_path, "r") as f:
        content = f.read()
    
    # Just insert it after package declaration
    if "import kotlinx.coroutines.launch" not in content or "import androidx.compose.ui.graphics.graphicsLayer" not in content:
        content = re.sub(r'(package .*\n)', r'\1' + imports_to_add, content)
    
    with open(f_path, "w") as f:
        f.write(content)

