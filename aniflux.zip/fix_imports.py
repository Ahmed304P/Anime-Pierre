import os
import re

files_to_update = [
    "app/src/main/java/com/example/ui/screens/HomeScreen.kt",
    "app/src/main/java/com/example/ui/screens/ExploreScreen.kt",
    "app/src/main/java/com/example/ui/screens/MyListScreen.kt",
    "app/src/main/java/com/example/ui/screens/RankingScreen.kt",
    "app/src/main/java/com/example/ui/screens/ScheduleScreen.kt",
    "app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt",
    "app/src/main/java/com/example/ui/screens/SeasonsScreen.kt"
]

for filepath in files_to_update:
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            content = f.read()
        
        # Remove the wrongly placed imports at the very beginning
        wrong_imports = "import androidx.compose.foundation.lazy.grid.itemsIndexed\nimport androidx.compose.foundation.lazy.itemsIndexed\n"
        if content.startswith(wrong_imports):
            content = content[len(wrong_imports):]
            
            # Now insert them after the package declaration
            content = content.replace("package com.example.ui.screens", "package com.example.ui.screens\n\n" + wrong_imports)
            
        with open(filepath, "w") as f:
            f.write(content)
