import re

with open("app/src/main/java/com/example/ui/screens/AdminAnimeManagerScreen.kt", "r") as f:
    content = f.read()

content = content.replace("viewModel.recommendedAnime.collectAsState()", "viewModel.allAnime.collectAsState()")
content = content.replace("anime.id", "anime.id") # Just making sure

with open("app/src/main/java/com/example/ui/screens/AdminAnimeManagerScreen.kt", "w") as f:
    f.write(content)

