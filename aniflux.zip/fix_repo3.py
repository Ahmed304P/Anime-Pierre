import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

content = content.replace("dao.insertWatchHistory(entity)", "dao.saveWatchHistory(entity)")
content = content.replace("dao.deleteWatchHistoryByAnime(animeId)", "dao.removeWatchHistoryByAnime(animeId)")
content = content.replace("dao.insertSavedAnime(entity)", "dao.saveAnime(entity)")
content = content.replace("dao.deleteSavedAnime(animeId)", "dao.removeSavedAnime(animeId)")

# Fix getEpisodesForAnime
old_episodes_func = """    fun getEpisodesForAnime(animeId: String, totalEpisodes: Int): List<Episode> {
        return (1..totalEpisodes).map { num ->
            com.example.data.model.Episode(
                id = "${animeId}_ep_$num",
                episodeNumber = num,
                title = "الحلقة $num",
                duration = "24:00",
                thumbnailUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&auto=format&fit=crop"
            )
        }
    }"""

new_episodes_func = """    fun getEpisodesForAnime(animeId: String, totalEpisodes: Int): List<com.example.data.model.Episode> {
        return (1..totalEpisodes).map { num ->
            com.example.data.model.Episode(
                id = "${animeId}_ep_$num",
                animeId = animeId,
                episodeNumber = num,
                titleAr = "الحلقة $num",
                durationMinutes = 24,
                thumbnailUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&auto=format&fit=crop",
                releaseDate = "2023-01-01",
                servers = emptyList()
            )
        }
    }"""
content = content.replace(old_episodes_func, new_episodes_func)

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
    f.write(content)
