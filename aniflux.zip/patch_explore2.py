import re

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "r") as f:
    content = f.read()

target = """            // Bottom Center Overlaid Badge: Year (e.g. 2010)
            Surface(
                shape = RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {"""

replacement = """            // Bottom Right Overlaid Badge: Year (e.g. 2010)
            Surface(
                shape = RoundedCornerShape(topStart = 6.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier.align(Alignment.BottomEnd)
            ) {"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "w") as f:
    f.write(content)
