import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    3, 8, 12 -> {
                        val title = when (selectedTab) {
                            8 -> "القائمة المخصصة"
                            12 -> "تحميلاتي"
                            else -> "قائمتي"
                        }
                        LibraryScreen(
                            selectedCategory = selectedLibraryCategory,
                            savedEntities = savedEntities,
                            watchHistoryList = watchHistoryList,
                            allAnimeList = allAnime,
                            onSelectCategory = { viewModel.setLibraryCategory(it) },
                            onRemoveSaved = { viewModel.removeSavedAnime(it) },
                            onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                            onOpenMenu = { scope.launch { drawerState.open() } },
                            title = title
                        )
                    }"""

replacement = """                    3, 12 -> {
                        val title = when (selectedTab) {
                            12 -> "تحميلاتي"
                            else -> "قائمتي"
                        }
                        LibraryScreen(
                            selectedCategory = selectedLibraryCategory,
                            savedEntities = savedEntities,
                            watchHistoryList = watchHistoryList,
                            allAnimeList = allAnime,
                            onSelectCategory = { viewModel.setLibraryCategory(it) },
                            onRemoveSaved = { viewModel.removeSavedAnime(it) },
                            onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                            onOpenMenu = { scope.launch { drawerState.open() } },
                            title = title
                        )
                    }
                    8 -> {
                        var customListScreenState by remember { mutableStateOf("MAIN") }
                        var selectedList by remember { mutableStateOf<com.example.data.local.CustomListEntity?>(null) }
                        
                        val customLists by viewModel.customLists.collectAsStateWithLifecycle()
                        val currentListItems by viewModel.currentCustomListItems.collectAsStateWithLifecycle()
                        
                        when (customListScreenState) {
                            "MAIN" -> {
                                com.example.ui.screens.CustomListsScreen(
                                    customLists = customLists,
                                    onOpenMenu = { scope.launch { drawerState.open() } },
                                    onOpenSearch = { isSearchOverlayVisible = true },
                                    onCreateListClick = { customListScreenState = "CREATE" },
                                    onListClick = { list -> 
                                        selectedList = list
                                        viewModel.loadCustomListItems(list.id)
                                        customListScreenState = "DETAIL"
                                    }
                                )
                            }
                            "CREATE" -> {
                                com.example.ui.screens.CreateListScreen(
                                    onBack = { customListScreenState = "MAIN" },
                                    onCreate = { name, description -> 
                                        viewModel.createCustomList(name, description)
                                        customListScreenState = "MAIN"
                                    }
                                )
                            }
                            "DETAIL" -> {
                                if (selectedList != null) {
                                    com.example.ui.screens.CustomListDetailScreen(
                                        list = selectedList!!,
                                        listItems = currentListItems,
                                        allAnimeList = allAnime,
                                        onBack = { customListScreenState = "MAIN" },
                                        onAddAnimeClick = { customListScreenState = "ADD" },
                                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                                        onDeleteList = {
                                            viewModel.deleteCustomList(selectedList!!.id)
                                            customListScreenState = "MAIN"
                                        },
                                        onRemoveAnime = { animeId ->
                                            viewModel.removeAnimeFromCustomList(selectedList!!.id, animeId)
                                        }
                                    )
                                }
                            }
                            "ADD" -> {
                                if (selectedList != null) {
                                    com.example.ui.screens.AddAnimeToListScreen(
                                        allAnimeList = allAnime,
                                        currentAnimeIds = currentListItems.map { it.animeId },
                                        onBack = { customListScreenState = "DETAIL" },
                                        onAdd = { animeId -> viewModel.addAnimeToCustomList(selectedList!!.id, animeId) },
                                        onRemove = { animeId -> viewModel.removeAnimeFromCustomList(selectedList!!.id, animeId) }
                                    )
                                }
                            }
                        }
                    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
