import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

# Fix the import issue
content = content.replace("import kotlinx.coroutines.flow.map\npackage com.example.ui.viewmodel", "package com.example.ui.viewmodel\nimport kotlinx.coroutines.flow.map")

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
