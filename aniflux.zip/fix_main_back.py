import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add showExitDialog state and change BackHandler logic
target_backhandler = """    var isSearchOverlayVisible by remember { mutableStateOf(false) }
    val tabHistorySize by viewModel.tabHistorySize.collectAsStateWithLifecycle()
    val shouldOpenNotifications by socialViewModel.shouldOpenNotifications.collectAsStateWithLifecycle()

    val isBackEnabled = activePlayerPair != null || 
        selectedAnimeDetails != null || 
        isSearchOverlayVisible || 
        drawerState.isOpen || 
        selectedTab != 0 || 
        tabHistorySize > 0

    BackHandler(enabled = isBackEnabled) {
        if (activePlayerPair != null) {
            viewModel.closePlayer()
        } else if (selectedAnimeDetails != null) {
            viewModel.closeAnimeDetails()
        } else if (isSearchOverlayVisible) {
            isSearchOverlayVisible = false
            viewModel.updateSearchQuery("")
        } else if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (tabHistorySize > 0) {
            viewModel.popTabStack()
        } else if (selectedTab != 0) {
            viewModel.setSelectedTab(0, addToHistory = false)
        }
    }"""

replacement_backhandler = """    var isSearchOverlayVisible by remember { mutableStateOf(false) }
    val tabHistorySize by viewModel.tabHistorySize.collectAsStateWithLifecycle()
    val shouldOpenNotifications by socialViewModel.shouldOpenNotifications.collectAsStateWithLifecycle()
    var showExitDialog by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    BackHandler(enabled = true) {
        if (activePlayerPair != null) {
            viewModel.closePlayer()
        } else if (selectedAnimeDetails != null) {
            viewModel.closeAnimeDetails()
        } else if (isSearchOverlayVisible) {
            isSearchOverlayVisible = false
            viewModel.updateSearchQuery("")
        } else if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (tabHistorySize > 0) {
            viewModel.popTabStack()
        } else if (selectedTab != 0) {
            viewModel.setSelectedTab(0, addToHistory = false)
        } else {
            showExitDialog = true
        }
    }"""

content = content.replace(target_backhandler, replacement_backhandler)

# Add the Exit Dialog composable UI at the end of the Scaffold, inside Box
target_scaffold_end = """            }
        }
    }
}"""
replacement_scaffold_end = """                
                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تأكيد الخروج", color = Color.White) },
                        text = { Text("هل أنت متأكد أنك تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("إلغاء", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }
            }
        }
    }
}"""
content = content.replace(target_scaffold_end, replacement_scaffold_end)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

