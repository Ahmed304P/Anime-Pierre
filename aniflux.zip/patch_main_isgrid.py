import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    text = f.read()

# Add to state collection
text = text.replace(
    "val filterState by viewModel.filterState.collectAsStateWithLifecycle()",
    "val filterState by viewModel.filterState.collectAsStateWithLifecycle()\n                val isGridMode by viewModel.isGridMode.collectAsStateWithLifecycle()"
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(text)
