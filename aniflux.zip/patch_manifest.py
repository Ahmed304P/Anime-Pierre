import re

with open("app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

if "android.permission.ACCESS_NETWORK_STATE" not in content:
    content = content.replace(
        '<uses-permission android:name="android.permission.INTERNET" />',
        '<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />'
    )

with open("app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
