import re
with open("app/src/main/java/com/example/ui/components/ShimmerEffect.kt", "r") as f:
    text = f.read()

text = text.replace("ShimmerAnimeCard(isThreeColumns: Boolean, index: Int = 0)", "ShimmerAnimeCard(isGridMode: Boolean, index: Int = 0)")

with open("app/src/main/java/com/example/ui/components/ShimmerEffect.kt", "w") as f:
    f.write(text)
