import re
with open("app/src/main/java/com/example/ui/viewmodel/SocialViewModel.kt", "r") as f:
    content = f.read()

content = content.replace(
    """    private val _shouldOpenComments = MutableStateFlow(false)
    val shouldOpenComments = _shouldOpenComments.asStateFlow()
    
    fun setShouldOpenComments(open: Boolean) {
        _shouldOpenComments.value = open
    }""",
    """    private val _shouldOpenComments = MutableStateFlow(false)
    val shouldOpenComments = _shouldOpenComments.asStateFlow()
    
    fun setShouldOpenComments(open: Boolean) {
        _shouldOpenComments.value = open
    }
    
    private val _shouldOpenNotifications = MutableStateFlow(false)
    val shouldOpenNotifications = _shouldOpenNotifications.asStateFlow()
    
    fun setShouldOpenNotifications(open: Boolean) {
        _shouldOpenNotifications.value = open
    }
    
    fun clearAllNotifications() {
        _notifications.value = emptyList()
    }"""
)

with open("app/src/main/java/com/example/ui/viewmodel/SocialViewModel.kt", "w") as f:
    f.write(content)
