import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("socialViewModel.setTargetScrollComment(notif.targetCommentId)", "socialViewModel.setTargetScrollComment(notif.targetCommentId, notif.targetReplyId)")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
