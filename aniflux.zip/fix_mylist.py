import re

with open("app/src/main/java/com/example/ui/screens/MyListScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    ", isGridMode: Boolean = true) {",
    ", isGridMode: Boolean = true,\n    onToggleGridMode: () -> Unit = {}\n) {"
)

text = text.replace(
    "onClick = { isGridMode = !isGridMode }",
    "onClick = onToggleGridMode"
)

with open("app/src/main/java/com/example/ui/screens/MyListScreen.kt", "w") as f:
    f.write(text)
