import re
with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

content = content.replace(
    """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    isLoggedIn: Boolean,
    userName: String,
    userAvatar: String,
    userBanner: String,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit,
    socialViewModel: SocialViewModel = viewModel()
) {""",
    """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    isLoggedIn: Boolean,
    userName: String,
    userAvatar: String,
    userBanner: String,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit,
    socialViewModel: SocialViewModel = viewModel(),
    onNotificationClicked: () -> Unit = {}
) {"""
)

# And pass it to NotificationBell
content = content.replace(
    """@Composable
fun NotificationBell(
    viewModel: SocialViewModel,
    onOpenNotifications: () -> Unit,
    onCloseDrawer: () -> Unit,""",
    """@Composable
fun NotificationBell(
    viewModel: SocialViewModel,
    onOpenNotifications: () -> Unit,
    onCloseDrawer: () -> Unit,
    onNotificationClicked: () -> Unit = {},"""
)

content = content.replace(
    """                    NotificationBell(
                        viewModel = socialViewModel,
                        onOpenNotifications = {
                            // Show notifications
                        },
                        onCloseDrawer = onCloseDrawer,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .statusBarsPadding()
                            .padding(end = 12.dp, top = 12.dp),
                        tint = Color.White
                    )""",
    """                    NotificationBell(
                        viewModel = socialViewModel,
                        onOpenNotifications = {
                        },
                        onCloseDrawer = onCloseDrawer,
                        onNotificationClicked = onNotificationClicked,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .statusBarsPadding()
                            .padding(end = 12.dp, top = 12.dp),
                        tint = Color.White
                    )"""
)

content = content.replace(
    """                    NotificationBell(
                        viewModel = socialViewModel,
                        onOpenNotifications = {
                            // Show notifications
                        },
                        onCloseDrawer = onCloseDrawer,
                        modifier = Modifier.align(Alignment.TopEnd),
                        tint = MaterialTheme.colorScheme.onBackground
                    )""",
    """                    NotificationBell(
                        viewModel = socialViewModel,
                        onOpenNotifications = {
                        },
                        onCloseDrawer = onCloseDrawer,
                        onNotificationClicked = onNotificationClicked,
                        modifier = Modifier.align(Alignment.TopEnd),
                        tint = MaterialTheme.colorScheme.onBackground
                    )"""
)

# And call it in the dropdown menu
content = content.replace(
    """                            // We need to trigger navigation to AnimeDetailScreen if not already there, 
                            // but for simplicity, we can close drawer and it'll show if we are on the anime screen,
                            // or ideally the AppViewModel should switch to AnimeDetail.
                            // In this simple layout, we might need a global navigator.
                            // Let's assume we call a global router or we just close the drawer.
                            onCloseDrawer()""",
    """                            onCloseDrawer()
                            onNotificationClicked()"""
)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
