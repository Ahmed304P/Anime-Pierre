import re

with open("app/src/main/java/com/example/ui/screens/MyListScreen.kt", "r") as f:
    content = f.read()

content = content.replace("import androidx.compose.material3.*", "import androidx.compose.material3.*\nimport androidx.compose.material3.TabRowDefaults.tabIndicatorOffset")

with open("app/src/main/java/com/example/ui/screens/MyListScreen.kt", "w") as f:
    f.write(content)
