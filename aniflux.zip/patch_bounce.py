with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "r") as f:
    text = f.read()

text = text.replace(
    "    onClick: () -> Unit,\n    onLongClick: (() -> Unit)? = null\n) = composed {",
    "    onLongClick: (() -> Unit)? = null,\n    onClick: () -> Unit\n) = composed {"
)

with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "w") as f:
    f.write(text)
