import re

with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "r") as f:
    content = f.read()

target = """    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = interactionSource,
            indication = androidx.compose.material3.ripple(),
            onClick = onClick
        )"""

replacement = """    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = interactionSource,
            indication = androidx.compose.material3.ripple(),
            onClick = onClick
        )
        .drawWithContent {
            drawContent()
            if (isPressed) {
                drawRect(
                    color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.3f),
                    size = size
                )
            }
        }"""

if "drawWithContent" not in content:
    content = content.replace(target, replacement)
    content = "import androidx.compose.ui.draw.drawWithContent\n" + content

with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "w") as f:
    f.write(content)
