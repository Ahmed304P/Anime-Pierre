import re

for file in ["app/src/main/java/com/example/ui/screens/RecommendationsScreen.kt", "app/src/main/java/com/example/ui/screens/PopularCharactersScreen.kt"]:
    with open(file, "r") as f:
        content = f.read()
    
    if "RecommendationsScreen.kt" in file:
        content = re.sub(r'fun RecommendationsScreen\([\s\S]*?\) \{', r'\g<0>\n    var isRefreshing by remember { mutableStateOf(false) }\n    val coroutineScope = rememberCoroutineScope()\n    val recommendations = remember { generateRecommendations(animeList) }', content)
        # Also fix the closing brace syntax error at line 145 if it exists.
        # It's complaining about `Expecting '}'`. My previous script replaced `LazyColumn` and might have missed a brace.
        # Let's just fix it manually by re-downloading or replacing the whole file if it's too broken.
    elif "PopularCharactersScreen" in file:
        content = re.sub(r'fun PopularCharactersScreen\([\s\S]*?\) \{', r'\g<0>\n    var isRefreshing by remember { mutableStateOf(false) }\n    val coroutineScope = rememberCoroutineScope()\n    val characters = remember { generateMockCharacters() }', content)
        
    with open(file, "w") as f:
        f.write(content)
