import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

old_block = """            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, top = 20.dp, bottom = 32.dp)
                ) {
                    IconButton(
                        onClick = { /* Handle Notifications */ },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsNone,
                            contentDescription = "Notifications",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    
                    Row(
                        modifier = Modifier
                            .padding(top = 24.dp)
                            .align(Alignment.Center)
                            .bounceClick(onClick = {
                                onSelectTab(17) // LoginScreen
                                onCloseDrawer()
                            }),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {"""

new_block = """            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, top = 12.dp, bottom = 32.dp)
                ) {
                    IconButton(
                        onClick = { /* Handle Notifications */ },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(40.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsNone,
                            contentDescription = "Notifications",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    
                    Row(
                        modifier = Modifier
                            .padding(top = 36.dp)
                            .align(Alignment.Center)
                            .bounceClick(onClick = {
                                onSelectTab(17) // LoginScreen
                                onCloseDrawer()
                            }),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {"""

if old_block in content:
    content = content.replace(old_block, new_block)
else:
    print("Old block not found!")

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
