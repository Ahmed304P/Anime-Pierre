import re

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace("fun HomeScreen(", "fun HomeScreen(\n    isLoading: Boolean,")

shimmer_code = """
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (isThreeColumns) 3 else 1),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (isLoading) {
                    items(15) {
                        com.example.ui.components.ShimmerAnimeCard(isThreeColumns = isThreeColumns)
                    }
                } else {
                    items(items = allAnime, key = { it.id }) { anime ->
"""

# Find the existing LazyVerticalGrid and replace its start
grid_pattern = re.compile(r'            LazyVerticalGrid\([\s\S]*?            \) \{\n                items\(items = allAnime, key = \{ it\.id \}\) \{ anime ->')

content = grid_pattern.sub(shimmer_code, content)

# We also need to add an extra } at the end of the items block
# The easiest way is to find the end of the LazyVerticalGrid items block
# It looks like:
#                        )
#                    }
#                }
#            }
#        }

content = content.replace(
"""                        )
                    }
                }
            }
        }
    }
}""",
"""                        )
                    }
                }
                }
            }
        }
    }
}"""
)

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
