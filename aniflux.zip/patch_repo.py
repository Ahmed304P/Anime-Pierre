import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

target = """    fun getAllWatchHistory(): Flow<List<WatchHistoryEntity>> = dao.getAllWatchHistory()"""

replacement = """    fun getAllWatchHistory(): Flow<List<WatchHistoryEntity>> = dao.getAllWatchHistory()
    
    suspend fun removeWatchHistoryByAnime(animeId: String) {
        dao.removeWatchHistoryByAnime(animeId)
    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
    f.write(content)
