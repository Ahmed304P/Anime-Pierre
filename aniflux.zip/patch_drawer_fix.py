import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

# Replace context with mContext inside the toast
content = content.replace(
    "android.widget.Toast.makeText(context,",
    "android.widget.Toast.makeText(mContext,"
)

# Fix the accidental injection in DrawerMenuItem
content = content.replace(
    """) {
    val context = LocalContext.current
    Surface(
        color = if (isSelected)""",
    """) {
    Surface(
        color = if (isSelected)"""
)

# Correctly inject mContext into AnimeSlayerDrawerContent
content = content.replace(
    """) {
    Surface(
        modifier = Modifier.fillMaxHeight().width(300.dp),""",
    """) {
    val mContext = LocalContext.current
    Surface(
        modifier = Modifier.fillMaxHeight().width(300.dp),"""
)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
