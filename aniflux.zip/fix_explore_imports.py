import re

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "r") as f:
    content = f.read()

# Remove them from the middle
content = content.replace("@OptIn(ExperimentalMaterial3Api::class)\nimport androidx.compose.material.icons.filled.FilterAlt\nimport com.example.ui.components.FilterBottomSheet\n", "")

# Add them to the top
new_imports = """import androidx.compose.material.icons.filled.FilterAlt
import com.example.ui.components.FilterBottomSheet
"""
content = re.sub(r'(package .*\n)', r'\1\n' + new_imports, content)

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "w") as f:
    f.write(content)
