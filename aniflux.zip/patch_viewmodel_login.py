import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

new_state = """
    // User Profile State
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userName = MutableStateFlow("مستخدم جديد")
    val userName: StateFlow<String> = _userName.asStateFlow()
    
    private val _userAvatar = MutableStateFlow("https://images.unsplash.com/photo-1534447677768-be436bb09401?w=200&auto=format&fit=crop")
    val userAvatar: StateFlow<String> = _userAvatar.asStateFlow()
    
    private val _userBanner = MutableStateFlow("https://images.unsplash.com/photo-1542451313056-b7c8e626645f?q=80&w=1000&auto=format&fit=crop")
    val userBanner: StateFlow<String> = _userBanner.asStateFlow()

    fun completeLogin(name: String, avatar: String, banner: String) {
        _userName.value = name
        _userAvatar.value = avatar
        _userBanner.value = banner
        _isLoggedIn.value = true
    }
    
    fun logout() {
        _isLoggedIn.value = false
        _userName.value = ""
        _userAvatar.value = ""
        _userBanner.value = ""
    }

    // UI Navigation State
"""

content = content.replace("    // UI Navigation State", new_state)

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
