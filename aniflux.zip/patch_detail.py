import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# Add rememberLazyListState to AnimeDetailsContent
# In `fun AnimeDetailsContent(anime: Anime...)`, we need to find LazyColumn and pass a state
content = content.replace("fun AnimeDetailsContent(", "fun AnimeDetailsContent(\n    lazyListState: androidx.compose.foundation.lazy.LazyListState,")
content = content.replace(
    """    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {""",
    """    LazyColumn(
        state = lazyListState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {"""
)
content = content.replace("AnimeDetailsHeader(anime)", "AnimeDetailsHeader(anime, lazyListState)")

content = content.replace("fun AnimeDetailsHeader(anime: Anime)", "fun AnimeDetailsHeader(anime: Anime, lazyListState: androidx.compose.foundation.lazy.LazyListState? = null)")

# Add graphicsLayer to the SubcomposeAsyncImage in AnimeDetailsHeader
parallax_target = """        // Blurred Background
        SubcomposeAsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(anime.bannerUrl.ifEmpty { anime.posterUrl })
                .crossfade(true)
                .build(),
            loading = { androidx.compose.foundation.layout.Box(modifier = androidx.compose.ui.Modifier.fillMaxSize().shimmerEffect()) },
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .blur(radius = 24.dp)
        )"""

parallax_replacement = """        // Blurred Background
        SubcomposeAsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(anime.bannerUrl.ifEmpty { anime.posterUrl })
                .crossfade(true)
                .build(),
            loading = { androidx.compose.foundation.layout.Box(modifier = androidx.compose.ui.Modifier.fillMaxSize().shimmerEffect()) },
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    if (lazyListState != null && lazyListState.firstVisibleItemIndex == 0) {
                        translationY = lazyListState.firstVisibleItemScrollOffset * 0.4f
                    }
                }
                .blur(radius = 24.dp)
        )"""
content = content.replace(parallax_target, parallax_replacement)

# Update EpisodesList to use staggered animation
episodes_target = """    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        items(items = episodes, key = { it.id }) { ep ->"""
        
episodes_replacement = """    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        itemsIndexed(items = episodes, key = { _, it -> it.id }) { index, ep ->
            com.example.ui.components.StaggeredAnimatedItem(index = index) {"""

episodes_end_target = """                        }
                    }
                }
            }
        }
    }"""
    
episodes_end_replacement = """                        }
                    }
                }
            }
            }
        }
    }"""
content = content.replace(episodes_target, episodes_replacement)
content = content.replace(episodes_end_target, episodes_end_replacement)


# Now in AnimeDetailScreen where we call AnimeDetailsContent, we need to pass the listState
# Wait, we need to see how AnimeDetailsContent is called
with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
