import re

with open("app/src/main/java/com/example/ui/screens/AdminAnimeManagerScreen.kt", "r") as f:
    content = f.read()

content = content.replace("AnimeSlayerViewModel", "AnimeViewModel")

with open("app/src/main/java/com/example/ui/screens/AdminAnimeManagerScreen.kt", "w") as f:
    f.write(content)

