import re

with open("app/src/main/java/com/example/data/local/AniFluxDatabase.kt", "r") as f:
    content = f.read()

content = content.replace(
    "entities = [SavedAnimeEntity::class, WatchHistoryEntity::class, LocalCommentEntity::class],",
    "entities = [SavedAnimeEntity::class, WatchHistoryEntity::class, LocalCommentEntity::class, CustomListEntity::class, CustomListItemEntity::class],"
).replace("version = 1,", "version = 2,")

with open("app/src/main/java/com/example/data/local/AniFluxDatabase.kt", "w") as f:
    f.write(content)
