import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

imports = """import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
"""
if "import androidx.compose.runtime.getValue" not in content:
    content = content.replace("import androidx.compose.runtime.remember", imports + "import androidx.compose.runtime.remember")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
