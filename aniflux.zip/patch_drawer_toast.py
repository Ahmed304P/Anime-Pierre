import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

# Replace both /* Handle Notifications */ with Toast
content = content.replace(
    "onClick = { /* Handle Notifications */ }",
    "onClick = { android.widget.Toast.makeText(context, \"لا توجد إشعارات جديدة حالياً\", android.widget.Toast.LENGTH_SHORT).show() }"
)

# Also need to make sure context is available. Let's check if `val context = LocalContext.current` is present in AnimeSlayerDrawerContent.
with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
