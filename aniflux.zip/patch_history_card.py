import re

with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "r") as f:
    text = f.read()

# Replace the inner HistoryAnimeCard invocation to pass isGridMode
text = text.replace(
    "onRemove = { onRemoveFromHistory(anime.id) }\n                                )",
    "onRemove = { onRemoveFromHistory(anime.id) },\n                                    isGridMode = isGridMode\n                                )"
)

# Do the same for FavoritesScreen
with open("app/src/main/java/com/example/ui/screens/FavoritesScreen.kt", "r") as f:
    text_fav = f.read()

text_fav = text_fav.replace(
    "onRemove = { onRemoveFromFavorites(anime.id) }\n                                )",
    "onRemove = { onRemoveFromFavorites(anime.id) },\n                                    isGridMode = isGridMode\n                                )"
)
with open("app/src/main/java/com/example/ui/screens/FavoritesScreen.kt", "w") as f:
    f.write(text_fav)


with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "w") as f:
    f.write(text)

