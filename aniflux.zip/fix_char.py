import re

with open("app/src/main/java/com/example/ui/screens/PopularCharactersScreen.kt", "r") as f:
    content = f.read()

# Remove `val characters = remember { generateMockCharacters() }`
content = content.replace("    val characters = remember { generateMockCharacters() }\n", "")

# Fix CharacterCard call
content = content.replace("CharacterCard(character = char)", "CharacterCard(name = char.first, imageUrl = char.second)")

with open("app/src/main/java/com/example/ui/screens/PopularCharactersScreen.kt", "w") as f:
    f.write(content)
