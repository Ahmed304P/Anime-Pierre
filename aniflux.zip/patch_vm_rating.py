import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

new_methods = """
    fun rateAnime(animeId: String, rating: Int) {
        viewModelScope.launch {
            val existing = db.dao().getSavedAnimeById(animeId).firstOrNull()
            if (existing != null) {
                db.dao().saveAnime(existing.copy(userRating = rating))
            } else {
                db.dao().saveAnime(com.example.data.local.SavedAnimeEntity(animeId, "NONE", userRating = rating))
            }
        }
    }
"""

if "rateAnime" not in content:
    content = content.replace("fun toggleEpisodeWatched", new_methods + "\n    fun toggleEpisodeWatched")

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
