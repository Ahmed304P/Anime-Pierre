import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

target = """                    val snackbarHostState = remember { SnackbarHostState() }
                    LaunchedEffect(Unit) {
                        // Just initializing
                    }
                    val coroutineScope = rememberCoroutineScope()
                    IconButton(onClick = {"""

replacement = """                    IconButton(onClick = {"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)

