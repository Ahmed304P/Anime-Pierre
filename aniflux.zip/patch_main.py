import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Replace the 'when (selectedTab)' block with an AnimatedContent block
target_when = """                // Main Navigation Screen Selection
                when (selectedTab) {"""
                
replacement_when = """                // Main Navigation Screen Selection
                androidx.compose.animation.AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        androidx.compose.animation.slideInHorizontally(
                            initialOffsetX = { fullWidth -> fullWidth },
                            animationSpec = androidx.compose.animation.core.tween(300)
                        ) + androidx.compose.animation.fadeIn(animationSpec = androidx.compose.animation.core.tween(300)) togetherWith
                        androidx.compose.animation.slideOutHorizontally(
                            targetOffsetX = { fullWidth -> -fullWidth },
                            animationSpec = androidx.compose.animation.core.tween(300)
                        ) + androidx.compose.animation.fadeOut(animationSpec = androidx.compose.animation.core.tween(300))
                    },
                    label = "tab_transition"
                ) { targetTab ->
                    when (targetTab) {"""

# And we need to close the AnimatedContent block.
# We can find the end of the when block. It ends just before "// Overlays"
target_end_when = """                    )
                }

                // Overlays"""

replacement_end_when = """                    )
                }
                } // End of AnimatedContent

                // Overlays"""

content = content.replace(target_when, replacement_when)
content = content.replace(target_end_when, replacement_end_when)

# Now, for AnimeDetailScreen overlay, change scaleIn/Out to slideIn/Out + fadeIn/Out
target_details_enter = """                    enter = scaleIn(initialScale = 0.85f, animationSpec = tween(300)) + fadeIn(animationSpec = tween(300)),
                    exit = scaleOut(targetScale = 0.85f, animationSpec = tween(300)) + fadeOut(animationSpec = tween(300))"""
                    
replacement_details_enter = """                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400)) + fadeIn(animationSpec = tween(400)),
                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(400)) + fadeOut(animationSpec = tween(400))"""
                    
content = content.replace(target_details_enter, replacement_details_enter)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
