import re

with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "r") as f:
    content = f.read()

target = """                drawRect(
                    color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.3f),
                    size = size
                )"""

replacement = """                drawRoundRect(
                    color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.3f),
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f)
                )"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/components/BounceClick.kt", "w") as f:
    f.write(content)
