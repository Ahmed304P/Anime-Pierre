import re

with open("app/src/main/java/com/example/ui/screens/AdminAnimeEditScreen.kt", "r") as f:
    content = f.read()

target1 = """@Composable
fun AdminAnimeEditScreen(
    animeId: String?,
    onBack: () -> Unit,
    onManageEpisodes: (String) -> Unit,
    modifier: Modifier = Modifier
) {"""

replacement1 = """import com.example.data.model.Anime
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAnimeEditScreen(
    animeId: String?,
    onBack: () -> Unit,
    onManageEpisodes: (String) -> Unit,
    onSaveAnime: (Anime) -> Unit = {},
    modifier: Modifier = Modifier
) {"""

content = re.sub(r'@Composable\nfun AdminAnimeEditScreen\(\n\s*animeId: String\?,\n\s*onBack: \(\) -> Unit,\n\s*onManageEpisodes: \(String\) -> Unit,\n\s*modifier: Modifier = Modifier\n\) \{', replacement1, content)


target2 = """                    scope.launch {
                        isLoading = true
                        delay(2000)
                        isLoading = false
                        snackbarHostState.showSnackbar(if (isEditMode) "تم تحديث الأنمي بنجاح" else "تمت إضافة الأنمي بقاعدة البيانات بنجاح")
                        delay(500)
                        onBack()
                    }"""

replacement2 = """                    val newAnime = Anime(
                        id = animeId ?: java.util.UUID.randomUUID().toString(),
                        titleAr = titleAr,
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsis = synopsisAr,
                        status = status,
                        type = type,
                        year = year,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24
                    )
                    
                    scope.launch {
                        isLoading = true
                        delay(1000)
                        onSaveAnime(newAnime)
                        isLoading = false
                        snackbarHostState.showSnackbar(if (isEditMode) "تم تحديث الأنمي بنجاح" else "تمت إضافة الأنمي بقاعدة البيانات بنجاح")
                        delay(500)
                        // If it's a new anime, maybe don't go back immediately if they want to add episodes?
                        // But going back to manager is standard.
                        onBack()
                    }"""

content = content.replace(target2, replacement2)

# Fix the manage episodes button
target3 = """            Button(
                onClick = { if (isEditMode) onManageEpisodes(animeId!!) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isEditMode) Color(0xFF2196F3) else Color.DarkGray,
                    disabledContainerColor = Color.DarkGray
                ),
                shape = RoundedCornerShape(12.dp),
                enabled = isEditMode,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(
                    if (isEditMode) "إدارة الحلقات واستخراج السيرفرات" else "إدارة الحلقات (يجب حفظ الأنمي أولاً)", 
                    color = if (isEditMode) Color.White else Color.Gray, 
                    fontSize = 16.sp, 
                    fontWeight = FontWeight.Bold
                )
            }"""

replacement3 = """            Button(
                onClick = { 
                    val currentId = animeId ?: java.util.UUID.randomUUID().toString()
                    val newAnime = Anime(
                        id = currentId,
                        titleAr = titleAr.ifBlank { "أنمي جديد" },
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsis = synopsisAr,
                        status = status,
                        type = type,
                        year = year,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24
                    )
                    onSaveAnime(newAnime)
                    onManageEpisodes(currentId) 
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3)),
                shape = RoundedCornerShape(12.dp),
                enabled = true,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(
                    "إدارة الحلقات واستخراج السيرفرات", 
                    color = Color.White, 
                    fontSize = 16.sp, 
                    fontWeight = FontWeight.Bold
                )
            }"""

content = content.replace(target3, replacement3)

with open("app/src/main/java/com/example/ui/screens/AdminAnimeEditScreen.kt", "w") as f:
    f.write(content)
