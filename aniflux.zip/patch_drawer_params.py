import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

content = content.replace(
    """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit
) {""",
    """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    isLoggedIn: Boolean,
    userName: String,
    userAvatar: String,
    userBanner: String,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit
) {"""
)

content = content.replace("    val isLoggedIn = true // Simulated login state", "")

content = content.replace(
    """                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data("https://images.unsplash.com/photo-1542451313056-b7c8e626645f?q=80&w=1000&auto=format&fit=crop")
                                    .crossfade(true)
                                    .build(),""",
    """                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(userBanner)
                                    .crossfade(true)
                                    .build(),"""
)

content = content.replace(
    """                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data("https://images.unsplash.com/photo-1534447677768-be436bb09401?w=200&auto=format&fit=crop&q=80")
                                        .crossfade(true)
                                        .build(),""",
    """                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data(userAvatar)
                                        .crossfade(true)
                                        .build(),"""
)

content = content.replace(
    'text = "¯\\\\shiro/¯",',
    'text = userName,'
)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
