import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

target = """    fun openAnimeDetails(anime: Anime) {
        _selectedAnimeForDetails.value = anime
    }"""

replacement = """    fun openAnimeDetails(anime: Anime) {
        _selectedAnimeForDetails.value = anime
        // Auto-add to watch history when entering details screen
        viewModelScope.launch {
            repository.recordWatchProgress(anime.id, 0, "Details", 0, 0)
        }
    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
