import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# Add imports
imports_to_add = """import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
"""

if "import androidx.compose.animation.AnimatedContent" not in content:
    content = content.replace("import androidx.compose.animation.AnimatedVisibility\n", imports_to_add + "import androidx.compose.animation.AnimatedVisibility\n")


# Replace `when (selectedTabIndex) {` block
target = """            when (selectedTabIndex) {
                0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })
                1 -> AnimeEpisodesTabContent(episodes, onOpenPlayer)
                2 -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("الاحصائيات (قريباً)", color = Color.Gray) }
                3 -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("الشخصيات والطاقم (قريباً)", color = Color.Gray) }
            }"""

replacement = """            AnimatedContent(
                targetState = selectedTabIndex,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(animationSpec = tween(300)) { width -> width } + fadeIn(animationSpec = tween(300))).togetherWith(
                            slideOutHorizontally(animationSpec = tween(300)) { width -> -width } + fadeOut(animationSpec = tween(300)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(300)) { width -> -width } + fadeIn(animationSpec = tween(300))).togetherWith(
                            slideOutHorizontally(animationSpec = tween(300)) { width -> width } + fadeOut(animationSpec = tween(300)))
                    }
                },
                label = "TabContentAnimation"
            ) { targetIndex ->
                when (targetIndex) {
                    0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })
                    1 -> AnimeEpisodesTabContent(episodes, onOpenPlayer)
                    2 -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("الاحصائيات (قريباً)", color = Color.Gray) }
                    3 -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("الشخصيات والطاقم (قريباً)", color = Color.Gray) }
                }
            }"""

if target in content:
    content = content.replace(target, replacement)
else:
    print("Target block not found.")

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
