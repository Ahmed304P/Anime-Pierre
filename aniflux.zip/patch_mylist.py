import re

with open("app/src/main/java/com/example/ui/screens/MyListScreen.kt", "r") as f:
    content = f.read()

content = content.replace("AnimeCard(\n                                    anime = anime,\n                                    onClick = { onOpenAnimeDetails(anime) },\n                                    isListLayout = !isGridView\n                                )", "if (isGridView) AnimeCard(anime = anime, onClick = { onOpenAnimeDetails(anime) }) else com.example.ui.components.AnimeListCard(anime = anime, onClick = { onOpenAnimeDetails(anime) })")

with open("app/src/main/java/com/example/ui/screens/MyListScreen.kt", "w") as f:
    f.write(content)
