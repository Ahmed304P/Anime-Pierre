import re

with open("app/src/main/java/com/example/data/model/Models.kt", "r") as f:
    content = f.read()

target = """    val ageRating: String = "+13", // "+13", "+17", "للجميع"
    val season: String = "ربيع" // "ربيع", "صيف", "خريف", "شتاء"
)"""
replacement = """    val ageRating: String = "+13", // "+13", "+17", "للجميع"
    val season: String = "ربيع", // "ربيع", "صيف", "خريف", "شتاء"
    val isCommentsLocked: Boolean = false
)"""
content = content.replace(target, replacement)

with open("app/src/main/java/com/example/data/model/Models.kt", "w") as f:
    f.write(content)

