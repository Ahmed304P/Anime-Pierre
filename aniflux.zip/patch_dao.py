import re

with open("app/src/main/java/com/example/data/local/AniFluxDao.kt", "r") as f:
    content = f.read()

new_dao_methods = """
    @Query("SELECT * FROM watched_episodes WHERE animeId = :animeId")
    fun getWatchedEpisodesForAnime(animeId: String): Flow<List<WatchedEpisodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchedEpisode(entity: WatchedEpisodeEntity)

    @Query("DELETE FROM watched_episodes WHERE id = :id")
    suspend fun removeWatchedEpisode(id: String)
"""

if "getWatchedEpisodesForAnime" not in content:
    content = content.replace("}", new_dao_methods + "}")

with open("app/src/main/java/com/example/data/local/AniFluxDao.kt", "w") as f:
    f.write(content)
