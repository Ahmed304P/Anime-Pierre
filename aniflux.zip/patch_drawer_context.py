import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

old_block = """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    isLoggedIn: Boolean,
    userName: String,
    userAvatar: String,
    userBanner: String,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit
) {
    Surface("""

new_block = """fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    isLoggedIn: Boolean,
    userName: String,
    userAvatar: String,
    userBanner: String,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit
) {
    val context = LocalContext.current
    Surface("""

if old_block in content:
    content = content.replace(old_block, new_block)
else:
    print("Old block not found!")

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
