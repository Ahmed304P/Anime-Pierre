with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    text = f.read()

count = 0
for line_num, line in enumerate(text.split("\n"), 1):
    for char in line:
        if char == '{': count += 1
        elif char == '}': count -= 1
    if "fun AnimeStatsTabContent" in line:
        print(f"Brace count at AnimeStatsTabContent: {count}")
    if "fun AnimeCharactersTabContent" in line:
        print(f"Brace count at AnimeCharactersTabContent: {count}")
