import re

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "r") as f:
    content = f.read()

imports = """import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
"""

if "import androidx.compose.animation.core.Animatable" not in content:
    content = content.replace("import androidx.compose.runtime.Composable", imports + "import androidx.compose.runtime.Composable")

# AnimeExploreGridCard
target_grid = """fun AnimeExploreGridCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()"""

replacement_grid = """fun AnimeExploreGridCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedAlpha = remember { Animatable(0f) }
    val animatedTranslationY = remember { Animatable(100f) }
    
    LaunchedEffect(anime.id) {
        launch { animatedAlpha.animateTo(1f, tween(500)) }
        launch { animatedTranslationY.animateTo(0f, tween(500)) }
    }

    Column(
        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()"""

content = content.replace(target_grid, replacement_grid)

# AnimeExploreListCard
target_list = """fun AnimeExploreListCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()"""

replacement_list = """fun AnimeExploreListCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedAlpha = remember { Animatable(0f) }
    val animatedTranslationY = remember { Animatable(100f) }
    
    LaunchedEffect(anime.id) {
        launch { animatedAlpha.animateTo(1f, tween(500)) }
        launch { animatedTranslationY.animateTo(0f, tween(500)) }
    }

    Row(
        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()"""

content = content.replace(target_list, replacement_list)

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "w") as f:
    f.write(content)
