import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

# Fix comments methods
old_comments = """    // --- Comments ---
    fun getLocalComments(animeId: String, episodeNumber: Int): kotlinx.coroutines.flow.Flow<List<com.example.data.local.LocalCommentEntity>> {
        return dao.getCommentsForEpisode(animeId, episodeNumber)
    }
    
    fun getInitialComments(animeId: String, episodeNumber: Int): List<com.example.data.local.LocalCommentEntity> {
        return emptyList()
    }

    suspend fun addComment(animeId: String, episodeNumber: Int, authorName: String, content: String, timestamp: String) {
        val entity = com.example.data.local.LocalCommentEntity(
            animeId = animeId,
            episodeNumber = episodeNumber,
            authorName = authorName,
            content = content,
            timestamp = timestamp
        )
        dao.insertComment(entity)
    }"""

new_comments = """    // --- Comments ---
    fun getLocalComments(animeId: String, episodeNumber: Int): kotlinx.coroutines.flow.Flow<List<com.example.data.model.CommentItem>> {
        return kotlinx.coroutines.flow.map(dao.getCommentsForEpisode(animeId, episodeNumber)) { list ->
            list.map { entity ->
                com.example.data.model.CommentItem(
                    id = entity.id.toString(),
                    authorName = entity.authorName,
                    content = entity.content,
                    timestamp = entity.timestamp,
                    likesCount = entity.likesCount,
                    isLiked = entity.isLiked
                )
            }
        }
    }
    
    fun getInitialComments(animeId: String, episodeNumber: Int): List<com.example.data.model.CommentItem> {
        return emptyList()
    }

    suspend fun addComment(animeId: String, episodeNumber: Int, authorName: String, content: String) {
        val entity = com.example.data.local.LocalCommentEntity(
            animeId = animeId,
            episodeNumber = episodeNumber,
            authorName = authorName,
            content = content,
            timestamp = "الآن"
        )
        dao.insertComment(entity)
    }"""
content = content.replace(old_comments, new_comments)

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
    f.write(content)
