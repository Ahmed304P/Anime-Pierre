import re

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "r") as f:
    content = f.read()

# Add imports if missing
imports = """import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.graphicsLayer
"""

if "import androidx.compose.animation.core.Animatable" not in content:
    content = content.replace("import androidx.compose.runtime.Composable", imports + "import androidx.compose.runtime.Composable")

# Update AnimeCard
target_anime_card = """fun AnimeCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showLargePoster: Boolean = false
) {
    Column(
        modifier = modifier
            .fillMaxWidth()"""

replacement_anime_card = """fun AnimeCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showLargePoster: Boolean = false
) {
    val animatedAlpha = remember { Animatable(0f) }
    val animatedTranslationY = remember { Animatable(100f) }
    
    LaunchedEffect(anime.id) {
        launch { animatedAlpha.animateTo(1f, tween(500)) }
        launch { animatedTranslationY.animateTo(0f, tween(500)) }
    }

    Column(
        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()"""

content = content.replace(target_anime_card, replacement_anime_card)

# Update AnimeListCard
target_anime_list_card = """fun AnimeListCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()"""

replacement_anime_list_card = """fun AnimeListCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedAlpha = remember { Animatable(0f) }
    val animatedTranslationY = remember { Animatable(100f) }
    
    LaunchedEffect(anime.id) {
        launch { animatedAlpha.animateTo(1f, tween(500)) }
        launch { animatedTranslationY.animateTo(0f, tween(500)) }
    }

    Row(
        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()"""

content = content.replace(target_anime_list_card, replacement_anime_list_card)

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "w") as f:
    f.write(content)
