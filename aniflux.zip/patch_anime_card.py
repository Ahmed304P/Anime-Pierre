import re

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "r") as f:
    content = f.read()

# Add imports for SubcomposeAsyncImage and shimmerEffect
if "import coil.compose.SubcomposeAsyncImage" not in content:
    content = content.replace(
        "import coil.compose.AsyncImage",
        "import coil.compose.SubcomposeAsyncImage\nimport com.example.util.shimmerEffect"
    )

# Replace AsyncImage in AnimeCard
target_card = """            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(anime.posterUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = anime.titleAr,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )"""

replacement_card = """            SubcomposeAsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(anime.posterUrl)
                    .crossfade(true)
                    .build(),
                loading = {
                    Box(modifier = Modifier.fillMaxSize().shimmerEffect())
                },
                contentDescription = anime.titleAr,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )"""

content = content.replace(target_card, replacement_card)

# Replace AsyncImage in AnimeListCard
target_list_card = """            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(anime.posterUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = anime.titleAr,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )"""

content = content.replace(target_list_card, replacement_card)

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "w") as f:
    f.write(content)
