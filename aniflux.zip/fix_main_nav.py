import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    20 -> MasterAdminDashboardScreen(
                        onBack = { viewModel.setSelectedTab(19) }
                    )"""

replacement = """                    20 -> MasterAdminDashboardScreen(
                        onBack = { viewModel.setSelectedTab(19) },
                        onNavigateToAnimeManager = { viewModel.setSelectedTab(21) }
                    )
                    21 -> AdminAnimeManagerScreen(
                        onBack = { viewModel.setSelectedTab(20) },
                        onEditAnime = { id -> 
                            // In a real app we'd pass ID through ViewModel or Navigation Args
                            // For now we just route to edit screen
                            viewModel.setSelectedTab(22) 
                        },
                        viewModel = viewModel
                    )
                    22 -> AdminAnimeEditScreen(
                        animeId = "mock_id", // For mock purposes
                        onBack = { viewModel.setSelectedTab(21) },
                        onManageEpisodes = { id -> viewModel.setSelectedTab(23) }
                    )
                    23 -> AdminEpisodeManagerScreen(
                        animeId = "mock_id",
                        onBack = { viewModel.setSelectedTab(22) }
                    )"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

