import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("viewModel.selectAnimeForDetails(allAnime.first())", "viewModel.openAnimeDetails(allAnime.first())")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
