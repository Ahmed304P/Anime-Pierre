import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    text = f.read()

text = text.replace("SearchScreenOverlay(\n                    visible = isSearchOverlayVisible,", "SearchScreenOverlay(\n                    visible = isSearchOverlayVisible,\n                    isDetailScreenOpen = selectedAnimeDetails != null,")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(text)
