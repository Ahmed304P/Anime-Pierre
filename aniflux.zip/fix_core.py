with open("gradle/libs.versions.toml", "r") as f:
    content = f.read()

content = content.replace('coreKtx = "1.18.0"', 'coreKtx = "1.15.0"')
content = content.replace('core = "1.18.0"', 'core = "1.15.0"') # if it exists

with open("gradle/libs.versions.toml", "w") as f:
    f.write(content)
