import re
with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

# The content has multiple instances of `// --- Custom Lists ---`. Let's split and keep the part before the first one.
parts = content.split("    // --- Custom Lists ---")
new_content = parts[0] + "    // --- Custom Lists ---\n" + parts[1]

# But parts[1] might not have the closing brace for the class.
# Let's clean it up properly.
import sys

def fix_file():
    with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
        lines = f.readlines()
    
    # Find the first index of "// --- Custom Lists ---"
    start_idx = -1
    for i, line in enumerate(lines):
        if "// --- Custom Lists ---" in line:
            start_idx = i
            break
            
    if start_idx == -1:
        return
        
    good_lines = lines[:start_idx]
    
    # Add imports to top if missing
    imports = "import com.example.data.local.CustomListEntity\nimport com.example.data.local.CustomListItemEntity\n"
    if imports not in "".join(good_lines):
        for i, line in enumerate(good_lines):
            if line.startswith("import "):
                good_lines.insert(i, imports)
                break
    
    custom_lists_code = """    // --- Custom Lists ---
    fun getAllCustomLists(): Flow<List<CustomListEntity>> = dao.getAllCustomLists()
    
    suspend fun createCustomList(name: String, description: String): Long {
        return dao.insertCustomList(CustomListEntity(name = name, description = description))
    }
    
    suspend fun deleteCustomList(listId: Long) {
        dao.deleteCustomListItems(listId)
        dao.deleteCustomList(listId)
    }
    
    fun getCustomListItems(listId: Long): Flow<List<CustomListItemEntity>> = dao.getCustomListItems(listId)
    
    suspend fun addAnimeToCustomList(listId: Long, animeId: String) {
        dao.insertCustomListItem(CustomListItemEntity(listId = listId, animeId = animeId))
    }
    
    suspend fun removeAnimeFromCustomList(listId: Long, animeId: String) {
        dao.deleteCustomListItem(listId, animeId)
    }
}
"""
    with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
        f.write("".join(good_lines) + custom_lists_code)

fix_file()
