import re

with open("app/src/main/java/com/example/data/local/Entities.kt", "r") as f:
    content = f.read()

new_entity = """
@Entity(tableName = "watched_episodes")
data class WatchedEpisodeEntity(
    @PrimaryKey val id: String, // animeId + "_" + episodeNumber
    val animeId: String,
    val episodeNumber: Int,
    val watchedAt: Long = System.currentTimeMillis()
)
"""
if "WatchedEpisodeEntity" not in content:
    content += new_entity

with open("app/src/main/java/com/example/data/local/Entities.kt", "w") as f:
    f.write(content)
