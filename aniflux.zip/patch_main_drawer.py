import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Collect the states inside ModalNavigationDrawer content
drawer_state_code = """
        val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
        val userName by viewModel.userName.collectAsStateWithLifecycle()
        val userAvatar by viewModel.userAvatar.collectAsStateWithLifecycle()
        val userBanner by viewModel.userBanner.collectAsStateWithLifecycle()

        ModalNavigationDrawer(
"""

content = content.replace("        ModalNavigationDrawer(", drawer_state_code)

drawer_call = """
            AnimeSlayerDrawerContent(
                selectedTab = selectedTab,
                isLoggedIn = isLoggedIn,
                userName = userName,
                userAvatar = userAvatar,
                userBanner = userBanner,
                onSelectTab = { tabIndex -> viewModel.setSelectedTab(tabIndex) },
                onCloseDrawer = { scope.launch { drawerState.close() } }
            )"""

content = re.sub(r'            AnimeSlayerDrawerContent\([\s\S]*?            \)', drawer_call, content)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
