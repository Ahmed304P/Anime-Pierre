with open("app/build.gradle.kts", "r") as f:
    content = f.read()

content = content.replace("""  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

""", "")

content = content.replace("""      signingConfig = signingConfigs.getByName("release")
""", "")

content = content.replace("""    debug { signingConfig = signingConfigs.getByName("debugConfig") }
""", "")

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
