import re

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

target = """                } else {                    
                    items(items = allAnime, key = { it.id }) { anime ->
                    val animatedAlpha = remember { androidx.compose.animation.core.Animatable(0f) }
                    val animatedTranslationY = remember { androidx.compose.animation.core.Animatable(100f) }
                    
                    LaunchedEffect(anime.id) {
                        launch { animatedAlpha.animateTo(1f, androidx.compose.animation.core.tween(500)) }
                        launch { animatedTranslationY.animateTo(0f, androidx.compose.animation.core.tween(500)) }
                    }
                    
                    val cardModifier = Modifier
                        .animateItem()
                        .graphicsLayer {
                            alpha = animatedAlpha.value
                            translationY = animatedTranslationY.value
                        }

                    if (isThreeColumns) {
                        AnimeCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            showLargePoster = false,
                            modifier = cardModifier
                        )
                    } else {
                        com.example.ui.components.AnimeListCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            modifier = cardModifier
                        )
                    }
                }
                }"""

replacement = """                } else {                    
                    items(items = allAnime, key = { it.id }) { anime ->
                    if (isThreeColumns) {
                        AnimeCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            showLargePoster = false,
                            modifier = Modifier.animateItem()
                        )
                    } else {
                        com.example.ui.components.AnimeListCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            modifier = Modifier.animateItem()
                        )
                    }
                }
                }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
