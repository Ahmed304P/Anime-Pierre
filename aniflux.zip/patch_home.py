import re

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    text = f.read()

# Update signature
text = text.replace(
    "onOpenAnimeDetails: (Anime) -> Unit,",
    "onOpenAnimeDetails: (Anime) -> Unit,\n    isGridMode: Boolean,\n    onToggleGridMode: () -> Unit,"
)

# Remove local state
text = text.replace("    var isThreeColumns by remember { mutableStateOf(true) }\n", "")

# Replace isThreeColumns with isGridMode
text = text.replace("isThreeColumns", "isGridMode")

# Update toggle action
text = text.replace("onClick = { isGridMode = !isGridMode }", "onClick = onToggleGridMode")

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(text)
