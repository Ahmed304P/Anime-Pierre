import re

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "r") as f:
    content = f.read()

# For AnimeCard Column
content = content.replace(
"""        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()
            .bounceClick { onClick() }""",
"""        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .bounceClick { onClick() }"""
)

# For AnimeListCard Row
content = content.replace(
"""        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()
            .bounceClick { onClick() }
            .padding(vertical = 4.dp, horizontal = 8.dp)""",
"""        modifier = modifier
            .graphicsLayer {
                alpha = animatedAlpha.value
                translationY = animatedTranslationY.value
            }
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .bounceClick { onClick() }
            .padding(vertical = 4.dp, horizontal = 8.dp)"""
)

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "w") as f:
    f.write(content)

