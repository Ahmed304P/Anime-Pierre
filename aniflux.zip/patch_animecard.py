import re

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "r") as f:
    text = f.read()

# Add onLongClick to AnimeCard
text = text.replace(
    "onClick: () -> Unit,\n    modifier: Modifier = Modifier,",
    "onClick: () -> Unit,\n    onLongClick: (() -> Unit)? = null,\n    modifier: Modifier = Modifier,"
)

# Update modifier in AnimeCard
text = text.replace(
    ".bounceClick { onClick() }",
    ".bounceClick(onClick = onClick, onLongClick = onLongClick)"
)

with open("app/src/main/java/com/example/ui/components/AnimeCard.kt", "w") as f:
    f.write(text)
