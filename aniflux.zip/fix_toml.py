with open("gradle/libs.versions.toml", "r") as f:
    content = f.read()

content = content.replace('agp = "8.7.2"', 'agp = "8.7.2"') # ensure it is 8.7.2
content = content.replace('agp = "9.1.1"', 'agp = "8.7.2"') 
content = content.replace('kotlin = "2.2.10"', 'kotlin = "2.0.21"')
content = content.replace('kotlin = "2.0.21"', 'kotlin = "2.0.21"') # ensure
content = content.replace('googleDevtoolsKsp = "2.3.5"', 'googleDevtoolsKsp = "2.0.21-1.0.27"')
content = content.replace('googleDevtoolsKsp = "2.0.21-1.0.27"', 'googleDevtoolsKsp = "2.0.21-1.0.27"') # ensure

with open("gradle/libs.versions.toml", "w") as f:
    f.write(content)
