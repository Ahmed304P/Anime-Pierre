import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# Replace AnimeDetailsTabContent signature
content = content.replace("fun AnimeDetailsTabContent(anime: Anime, isSaved: Boolean, savedStatus: String?, onOpenMyListOptions: () -> Unit, onRateClick: () -> Unit) {", "fun AnimeDetailsTabContent(anime: Anime, isSaved: Boolean, savedStatus: String?, onOpenMyListOptions: () -> Unit, onRateClick: () -> Unit, lazyListState: androidx.compose.foundation.lazy.LazyListState) {")

content = content.replace(
    """    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {""",
    """    LazyColumn(
        state = lazyListState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {"""
)

# Pass lazyListState to AnimeDetailsHeader
content = content.replace("AnimeDetailsHeader(anime)", "AnimeDetailsHeader(anime, lazyListState)")

# Also, we need to pass `val detailsListState = rememberLazyListState()` in `AnimeDetailScreen` to `AnimeDetailsTabContent`.
# But wait, each tab might need its own scroll state or we create one for the Details Tab.
# Let's search where `AnimeDetailsTabContent` is called.

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
