import re

with open("app/src/main/java/com/example/ui/components/VideoPlayerModal.kt", "r") as f:
    content = f.read()

target = """                // Skip Intro Button
                if (currentProgressSeconds <= 15f && currentProgressSeconds < totalSeconds - skipTime) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 40.dp, end = 16.dp),
                        contentAlignment = Alignment.BottomEnd
                    ) {
                        Button(
                            onClick = { 
                                currentProgressSeconds += skipTime
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "تخطي $skipTime ثواني",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }"""

content = content.replace(target, "")

with open("app/src/main/java/com/example/ui/components/VideoPlayerModal.kt", "w") as f:
    f.write(content)
