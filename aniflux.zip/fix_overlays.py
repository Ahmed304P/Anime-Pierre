with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    text = f.read()

# 1. Extract SearchScreenOverlay
search_start = text.find("SearchScreenOverlay(")
search_end = text.find(")", search_start) + 1
# Since SearchScreenOverlay is the last element before the closing braces of Box, we might need to find the exact end.
# It ends with:
#                     onResetFilters = { viewModel.resetFilters() }
#                 )
import re
match = re.search(r'SearchScreenOverlay\([\s\S]*?onResetFilters = \{ viewModel\.resetFilters\(\) \}\n\s*\)', text)
if match:
    search_block = match.group(0)
    # Remove from original location
    text = text.replace(search_block, "")
    
    # 2. Fix the onOpenAnimeDetails in search_block
    search_block = re.sub(
        r'onOpenAnimeDetails = \{\s*isSearchOverlayVisible = false\s*viewModel\.updateSearchQuery\(""\)\s*viewModel\.openAnimeDetails\(it\)\s*\},',
        'onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },',
        search_block
    )

    # 3. Insert it right before Anime Detail Screen Overlay
    insert_target = "// Anime Detail Screen Overlay"
    text = text.replace(insert_target, search_block + "\n\n                " + insert_target)

    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(text)
    print("Successfully re-ordered overlays.")
else:
    print("Could not find SearchScreenOverlay block.")

