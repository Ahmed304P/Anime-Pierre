import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# Add rememberLazyListState to AnimeDetailScreen
content = content.replace("    var selectedTabIndex by remember { mutableStateOf(0) }", "    var selectedTabIndex by remember { mutableStateOf(0) }\n    val detailsListState = androidx.compose.foundation.lazy.rememberLazyListState()")

# Update caller
content = content.replace(
    "                    0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true }, onRateClick = { showRatingDialog = true })",
    "                    0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true }, onRateClick = { showRatingDialog = true }, lazyListState = detailsListState)"
)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
