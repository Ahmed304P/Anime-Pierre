import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    17 -> LoginScreen(
                        onBack = { viewModel.setSelectedTab(0, addToHistory = false) },
                        onLoginSuccess = { viewModel.setSelectedTab(18) }
                    )
                    18 -> CompleteProfileScreen(
                        onComplete = { name, avatar, banner ->
                            viewModel.completeLogin(name, avatar, banner)
                            viewModel.setSelectedTab(0, addToHistory = false)
                        }
                    )"""

replacement = """                    17 -> LoginScreen(
                        onBack = { viewModel.setSelectedTab(0, addToHistory = false) },
                        onLoginSuccess = { viewModel.setSelectedTab(18) },
                        onAdminBackdoor = { viewModel.setSelectedTab(19) }
                    )
                    18 -> CompleteProfileScreen(
                        onComplete = { name, avatar, banner ->
                            viewModel.completeLogin(name, avatar, banner)
                            viewModel.setSelectedTab(0, addToHistory = false)
                        }
                    )
                    19 -> AdminPasswordScreen(
                        onBack = { viewModel.setSelectedTab(17) },
                        onSuccess = { viewModel.setSelectedTab(20) }
                    )
                    20 -> MasterAdminDashboardScreen(
                        onBack = { viewModel.setSelectedTab(19) }
                    )"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

