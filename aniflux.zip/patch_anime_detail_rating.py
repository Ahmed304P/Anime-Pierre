import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# Pass onRateClick
content = content.replace(
    "0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })",
    "0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true }, onRateClick = { showRatingDialog = true })"
)

# Add showRatingDialog state and rating callback
content = content.replace(
    "var showMyListSheet by remember { mutableStateOf(false) }",
    "var showMyListSheet by remember { mutableStateOf(false) }\n    var showRatingDialog by remember { mutableStateOf(false) }"
)

content = content.replace(
    """    isSaved: Boolean,
    savedStatus: String?,
    watchedEpisodes: Set<Int>,
    onToggleWatched: (Int, Boolean) -> Unit,
    onBack: () -> Unit,""",
    """    isSaved: Boolean,
    savedStatus: String?,
    watchedEpisodes: Set<Int>,
    onToggleWatched: (Int, Boolean) -> Unit,
    onRateAnime: (Int) -> Unit = {},
    onBack: () -> Unit,"""
)

# Add Rating Dialog UI
dialog_code = """
    if (showRatingDialog) {
        AlertDialog(
            onDismissRequest = { showRatingDialog = false },
            title = { Text("تقييم الأنمي", color = Color.White) },
            text = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (i in 1..10) {
                        if (i % 2 == 0) { // Just show 5 stars (each represents 2 points)
                            Icon(
                                imageVector = Icons.Default.StarBorder,
                                contentDescription = "$i",
                                tint = Color.Yellow,
                                modifier = Modifier.size(32.dp).clickable {
                                    onRateAnime(i)
                                    showRatingDialog = false
                                }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showRatingDialog = false }) {
                    Text("إلغاء", color = Color.White)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
"""

content = content.replace("    if (showMyListSheet) {", dialog_code + "\n    if (showMyListSheet) {")

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
