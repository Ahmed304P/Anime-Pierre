import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

target = "AnimeActionsRow(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })"
replacement = "AnimeActionsRow(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = onOpenMyListOptions)"

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
