import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

pattern = r"// Notifications Screen Overlay[\s\S]*?var lastPlayerPair by remember"

clean_text = """// Notifications Screen Overlay
                AnimatedVisibility(
                    visible = shouldOpenNotifications,
                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400)) + fadeIn(animationSpec = tween(400)),
                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(400)) + fadeOut(animationSpec = tween(400))
                ) {
                    com.example.ui.screens.NotificationsScreen(
                        viewModel = socialViewModel,
                        onBack = { socialViewModel.setShouldOpenNotifications(false) },
                        onNotificationClicked = { notif ->
                            socialViewModel.setShouldOpenNotifications(false)
                            socialViewModel.markNotificationsAsRead()
                            socialViewModel.setTargetScrollComment(notif.targetCommentId, notif.parentThreadId)
                            if (allAnime.isNotEmpty() && selectedAnimeDetails == null) {
                                viewModel.openAnimeDetails(allAnime.first())
                            }
                            socialViewModel.setShouldOpenComments(true)
                        }
                    )
                }

                // Anime Detail Screen Overlay
                AnimatedVisibility(
                    visible = selectedAnimeDetails != null,
                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400)) + fadeIn(animationSpec = tween(400)),
                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(400)) + fadeOut(animationSpec = tween(400))
                ) {
                    var lastAnime by remember { androidx.compose.runtime.mutableStateOf<com.example.data.model.Anime?>(null) }
                    androidx.compose.runtime.LaunchedEffect(selectedAnimeDetails) {
                        if (selectedAnimeDetails != null) {
                            lastAnime = selectedAnimeDetails
                        }
                    }
                    val currentAnime = selectedAnimeDetails ?: lastAnime
                    if (currentAnime != null) {
                        val anime = currentAnime
                        val episodes = remember(anime) { viewModel.getEpisodesForAnime(anime) }
                        val isSaved by viewModel.isAnimeSaved(anime.id).collectAsStateWithLifecycle(initialValue = false)
                        val savedStatus by viewModel.getAnimeSavedStatus(anime.id).collectAsStateWithLifecycle(initialValue = null)
                        val watchedEpisodes by viewModel.getWatchedEpisodes(anime.id).collectAsStateWithLifecycle(initialValue = emptySet())
                        AnimeDetailScreen(
                            anime = anime,
                            episodes = episodes,
                            isSaved = isSaved,
                            savedStatus = savedStatus,
                            watchedEpisodes = watchedEpisodes,
                            onToggleWatched = { epNum, watched -> viewModel.toggleEpisodeWatched(anime.id, epNum, watched) },
                            onRateAnime = { rating -> viewModel.rateAnime(anime.id, rating) },
                            onBack = { viewModel.closeAnimeDetails() },
                            onToggleSave = { status -> viewModel.toggleSaveAnime(anime.id, status) },
                            onRemoveSaved = { animeId -> viewModel.removeSavedAnime(animeId) },
                            onOpenPlayer = { ep ->
                                viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                                viewModel.openPlayer(anime, ep)
                            }
                        )
                    }
                }

                // Video Player Modal Overlay
                AnimatedVisibility(
                    visible = activePlayerPair != null,
                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(animationSpec = tween(300)),
                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300)) + fadeOut(animationSpec = tween(300))
                ) {
                    var lastPlayerPair by remember"""

content = re.sub(pattern, clean_text, content)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

