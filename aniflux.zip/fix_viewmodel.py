import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

# Replace any junk at the top until "import android.app.Application"
content = re.sub(r'^.*?import android\.app\.Application', 'package com.example.ui.viewmodel\n\nimport kotlinx.coroutines.delay\nimport android.app.Application', content, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
