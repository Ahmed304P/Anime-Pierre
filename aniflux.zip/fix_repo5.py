import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

old_func = """    fun getLocalComments(animeId: String, episodeNumber: Int): kotlinx.coroutines.flow.Flow<List<com.example.data.model.CommentItem>> {
        return kotlinx.coroutines.flow.map(dao.getCommentsForEpisode(animeId, episodeNumber)) { list ->
            list.map { entity ->
                com.example.data.model.CommentItem(
                    id = entity.id.toString(),
                    authorName = entity.authorName,
                    content = entity.content,
                    timestamp = entity.timestamp,
                    likesCount = entity.likesCount,
                    isLiked = entity.isLiked
                )
            }
        }
    }"""

new_func = """    fun getLocalComments(animeId: String, episodeNumber: Int): kotlinx.coroutines.flow.Flow<List<com.example.data.model.CommentItem>> {
        return kotlinx.coroutines.flow.map(dao.getCommentsForEpisode(animeId, episodeNumber)) { list ->
            list.map { entity ->
                com.example.data.model.CommentItem(
                    id = entity.id.toString(),
                    authorName = entity.authorName,
                    avatarUrl = "https://i.pravatar.cc/150?u=${entity.authorName}",
                    content = entity.content,
                    timeAgo = entity.timestamp,
                    likesCount = entity.likesCount,
                    isLikedByMe = entity.isLiked
                )
            }
        }
    }"""

content = content.replace(old_func, new_func)

# Add import kotlinx.coroutines.flow.map
imports = "import kotlinx.coroutines.flow.map\n"
if "import kotlinx.coroutines.flow.map" not in content:
    idx = content.find("import ")
    content = content[:idx] + imports + content[idx:]

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
    f.write(content)
