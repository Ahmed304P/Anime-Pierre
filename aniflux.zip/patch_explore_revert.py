import re

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "r") as f:
    content = f.read()

# Remove imports
content = content.replace("import androidx.compose.material.icons.filled.FilterAlt\nimport com.example.ui.components.FilterBottomSheet\n", "")

# Update signature
old_sig = """@Composable
fun ExploreScreen(
    allAnime: List<Anime>,
    filteredAnimeList: List<Anime>,
    filterState: FilterState,
    onSearchQueryChange: (String) -> Unit,
    onGenreFilterChange: (String?) -> Unit,
    onStatusFilterChange: (String?) -> Unit,
    onTypeFilterChange: (String?) -> Unit,
    onYearFilterChange: (Int?) -> Unit,
    onStudioFilterChange: (String?) -> Unit,
    onAgeRatingFilterChange: (String?) -> Unit,
    onSeasonFilterChange: (String?) -> Unit,
    onResetFilters: () -> Unit,
    onOpenAnimeDetails: (Anime) -> Unit,
    onOpenMenu: () -> Unit = {},
    onOpenSearch: () -> Unit = {},
    title: String = "لائحة الانمي",
    modifier: Modifier = Modifier
) {
    var showFilterSheet by remember { mutableStateOf(false) }"""

new_sig = """@Composable
fun ExploreScreen(
    filteredAnimeList: List<Anime>,
    filterState: FilterState,
    onSearchQueryChange: (String) -> Unit,
    onGenreFilterChange: (String?) -> Unit,
    onStatusFilterChange: (String?) -> Unit,
    onTypeFilterChange: (String?) -> Unit,
    onResetFilters: () -> Unit,
    onOpenAnimeDetails: (Anime) -> Unit,
    onOpenMenu: () -> Unit = {},
    onOpenSearch: () -> Unit = {},
    title: String = "لائحة الانمي",
    modifier: Modifier = Modifier
) {"""
content = content.replace(old_sig, new_sig)

# Remove the filter icon from app bar
filter_icon = """                IconButton(onClick = { showFilterSheet = true }) {
                    Icon(
                        imageVector = Icons.Default.FilterAlt,
                        contentDescription = "Filter",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }"""
content = content.replace(filter_icon, "")

# Remove the FilterBottomSheet block
bottom_sheet_code = """        // Filter Bottom Sheet
        if (showFilterSheet) {
            FilterBottomSheet(
                allAnime = allAnime,
                filterState = filterState,
                onDismiss = { showFilterSheet = false },
                onGenreFilterChange = onGenreFilterChange,
                onStatusFilterChange = onStatusFilterChange,
                onTypeFilterChange = onTypeFilterChange,
                onYearFilterChange = onYearFilterChange,
                onStudioFilterChange = onStudioFilterChange,
                onAgeRatingFilterChange = onAgeRatingFilterChange,
                onSeasonFilterChange = onSeasonFilterChange,
                onResetFilters = onResetFilters
            )
        }

"""
content = content.replace(bottom_sheet_code, "")

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "w") as f:
    f.write(content)

