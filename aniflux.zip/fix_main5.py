import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

bad_block = """                
                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تأكيد الخروج", color = Color.White) },
                        text = { Text("هل أنت متأكد أنك تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("إلغاء", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }"""

# Find the last closing braces
# Since there can be any amount of whitespace, let's find the last '}'
last_brace_index = content.rfind('}')
if last_brace_index != -1:
    # We need to insert inside the Box which is the 4th outer brace from the end?
    # Scaffold { Box { ... overlays ... } }
    # Let's find the last `AnimatedVisibility` block and insert after it.
    target_str = """AnimatedVisibility"""
    last_animated_idx = content.rfind(target_str)
    
    if last_animated_idx != -1:
        # Find the matching closing brace of this AnimatedVisibility block
        brace_count = 0
        started = False
        insert_idx = -1
        for i in range(last_animated_idx, len(content)):
            if content[i] == '{':
                brace_count += 1
                started = True
            elif content[i] == '}':
                brace_count -= 1
            
            if started and brace_count == 0:
                insert_idx = i + 1
                break
        
        if insert_idx != -1:
            content = content[:insert_idx] + "\n" + bad_block + "\n" + content[insert_idx:]
            with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
                f.write(content)
            print("Successfully inserted")
        else:
            print("Could not find matching brace")
    else:
        print("Could not find AnimatedVisibility")

