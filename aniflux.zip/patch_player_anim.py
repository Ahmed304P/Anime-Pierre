import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                // Video Player Modal Overlay
                if (activePlayerPair != null) {
                    val (anime, activeEp) = activePlayerPair!!
                    val episodes = remember(anime) { viewModel.getEpisodesForAnime(anime) }

                    val currentSkipTime by viewModel.skipTime.collectAsStateWithLifecycle()
                    VideoPlayerModal(
                        skipTime = currentSkipTime,
                        anime = anime,
                        currentEpisode = activeEp,
                        allEpisodes = episodes,
                        comments = activeComments,
                        onClose = { viewModel.closePlayer() },
                        onSelectEpisode = { ep ->
                            viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                            viewModel.openPlayer(anime, ep)
                        },
                        onAddComment = { content ->
                            viewModel.addComment(anime.id, activeEp.episodeNumber, "متابع AniFlux", content)
                        },
                        onLikeComment = { commentId ->
                            viewModel.likeComment(commentId)
                        }
                    )
                }"""

replacement = """                // Video Player Modal Overlay
                AnimatedVisibility(
                    visible = activePlayerPair != null,
                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(animationSpec = tween(300)),
                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300)) + fadeOut(animationSpec = tween(300))
                ) {
                    var lastPlayerPair by remember { androidx.compose.runtime.mutableStateOf<Pair<com.example.data.model.Anime, com.example.data.model.Episode>?>(null) }
                    androidx.compose.runtime.LaunchedEffect(activePlayerPair) {
                        if (activePlayerPair != null) {
                            lastPlayerPair = activePlayerPair
                        }
                    }
                    val currentPair = activePlayerPair ?: lastPlayerPair

                    if (currentPair != null) {
                        val (anime, activeEp) = currentPair
                        val episodes = remember(anime) { viewModel.getEpisodesForAnime(anime) }

                        val currentSkipTime by viewModel.skipTime.collectAsStateWithLifecycle()
                        VideoPlayerModal(
                            skipTime = currentSkipTime,
                            anime = anime,
                            currentEpisode = activeEp,
                            allEpisodes = episodes,
                            comments = activeComments,
                            onClose = { viewModel.closePlayer() },
                            onSelectEpisode = { ep ->
                                viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                                viewModel.openPlayer(anime, ep)
                            },
                            onAddComment = { content ->
                                viewModel.addComment(anime.id, activeEp.episodeNumber, "متابع AniFlux", content)
                            },
                            onLikeComment = { commentId ->
                                viewModel.likeComment(commentId)
                            }
                        )
                    }
                }"""

if target in content:
    content = content.replace(target, replacement)
else:
    print("Video Player Modal Overlay not found")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
