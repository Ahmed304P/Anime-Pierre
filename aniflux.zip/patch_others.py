import os
import re

files_to_update = [
    "app/src/main/java/com/example/ui/screens/MyListScreen.kt",
    "app/src/main/java/com/example/ui/screens/FavoritesScreen.kt",
    "app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt",
    "app/src/main/java/com/example/ui/screens/CustomListDetailScreen.kt",
    "app/src/main/java/com/example/ui/screens/SeasonsScreen.kt",
    "app/src/main/java/com/example/ui/screens/RankingScreen.kt",
    "app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt"
]

for file_path in files_to_update:
    if not os.path.exists(file_path):
        continue
        
    with open(file_path, "r") as f:
        content = f.read()
        
    # Check if we need to add isGridMode parameter
    if "isGridMode: Boolean" not in content:
        content = re.sub(r'(fun \w+\([\s\S]*?)(\)\s*\{)', r'\1, isGridMode: Boolean = true\2', content)
        
    # Remove local isGridView or isThreeColumns states
    content = re.sub(r'\s*var (isGridView|isThreeColumns) by remember \{ mutableStateOf\(true\) \}', '', content)
    
    # Replace usages of local state with isGridMode
    content = content.replace("isGridView", "isGridMode")
    content = content.replace("isThreeColumns", "isGridMode")
    
    with open(file_path, "w") as f:
        f.write(content)

print("Done")
