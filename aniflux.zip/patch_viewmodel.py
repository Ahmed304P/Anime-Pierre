import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

# Add new update methods
update_methods = """
    fun updateTypeFilter(type: String?) {
        _filterState.update { it.copy(selectedType = if (it.selectedType == type) null else type) }
    }

    fun updateYearFilter(year: Int?) {
        _filterState.update { it.copy(selectedYear = if (it.selectedYear == year) null else year) }
    }

    fun updateStudioFilter(studio: String?) {
        _filterState.update { it.copy(selectedStudio = if (it.selectedStudio == studio) null else studio) }
    }

    fun updateAgeRatingFilter(ageRating: String?) {
        _filterState.update { it.copy(selectedAgeRating = if (it.selectedAgeRating == ageRating) null else ageRating) }
    }

    fun updateSeasonFilter(season: String?) {
        _filterState.update { it.copy(selectedSeason = if (it.selectedSeason == season) null else season) }
    }
"""
content = content.replace("    fun updateTypeFilter(type: String?) {\n        _filterState.update { it.copy(selectedType = if (it.selectedType == type) null else type) }\n    }\n", update_methods)

# Update filtering logic
filter_target = """            val matchesGenre = filters.selectedGenre == null || anime.genres.contains(filters.selectedGenre)
            val matchesStatus = filters.selectedStatus == null || anime.status == filters.selectedStatus
            val matchesType = filters.selectedType == null || anime.type == filters.selectedType

            matchesQuery && matchesGenre && matchesStatus && matchesType"""
filter_replacement = """            val matchesGenre = filters.selectedGenre == null || anime.genres.contains(filters.selectedGenre)
            val matchesStatus = filters.selectedStatus == null || anime.status == filters.selectedStatus
            val matchesType = filters.selectedType == null || anime.type == filters.selectedType
            val matchesYear = filters.selectedYear == null || anime.year == filters.selectedYear
            val matchesStudio = filters.selectedStudio == null || anime.studio == filters.selectedStudio
            val matchesAgeRating = filters.selectedAgeRating == null || anime.ageRating == filters.selectedAgeRating
            val matchesSeason = filters.selectedSeason == null || anime.season == filters.selectedSeason

            matchesQuery && matchesGenre && matchesStatus && matchesType && matchesYear && matchesStudio && matchesAgeRating && matchesSeason"""
content = content.replace(filter_target, filter_replacement)

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
