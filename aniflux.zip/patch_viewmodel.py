import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    text = f.read()

insert_str = """
    private val _isGridMode = MutableStateFlow(true)
    val isGridMode: StateFlow<Boolean> = _isGridMode.asStateFlow()

    fun toggleGridMode() {
        _isGridMode.value = !_isGridMode.value
    }
"""

# Insert after currentTheme
text = text.replace(
    "val currentTheme: StateFlow<AppTheme> = _currentTheme.asStateFlow()",
    "val currentTheme: StateFlow<AppTheme> = _currentTheme.asStateFlow()\n" + insert_str
)

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(text)
