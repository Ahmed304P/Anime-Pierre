import re

with open("app/src/main/java/com/example/ui/screens/CompleteProfileScreen.kt", "r") as f:
    content = f.read()

content = content.replace("fun CompleteProfileScreen(\n    onComplete: () -> Unit\n)", "fun CompleteProfileScreen(\n    onComplete: (String, String, String) -> Unit\n)")

content = content.replace(
    'var avatarUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1534447677768-be436bb09401?w=200&auto=format&fit=crop") }',
    'var avatarUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1534447677768-be436bb09401?w=200&auto=format&fit=crop") }\n    var userName by remember { mutableStateOf("") }'
)

text_field_code = """
        Spacer(modifier = Modifier.height(32.dp))
        
        OutlinedTextField(
            value = userName,
            onValueChange = { userName = it },
            label = { Text("اسم المستخدم") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            shape = RoundedCornerShape(12.dp)
        )
        
        Spacer(modifier = Modifier.height(16.dp))"""

content = content.replace("        Spacer(modifier = Modifier.height(32.dp))", text_field_code)
content = content.replace("onClick = onComplete", "onClick = { onComplete(userName.ifBlank { \"مستخدم جديد\" }, avatarUrl, bannerUrl) }")

with open("app/src/main/java/com/example/ui/screens/CompleteProfileScreen.kt", "w") as f:
    f.write(content)
