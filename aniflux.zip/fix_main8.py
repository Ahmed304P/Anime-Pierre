with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if "enter = slideInVertically(initialOffsetY = { it }" in line and "if (showExitDialog) {" in line:
        # We found the corrupted line
        new_lines.append("                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(animationSpec = tween(300)),\n")
        new_lines.append("                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300)) + fadeOut(animationSpec = tween(300))\n")
        new_lines.append("                ) {\n")
        skip = True
        continue
    
    if skip:
        # We are skipping the injected AlertDialog
        if "                    )" in line and "}" in lines[i+1]:
            # This looks like the end of AlertDialog
            pass
        if "                }" in line and skip:
            skip = False
            continue
        continue
        
    new_lines.append(line)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.writelines(new_lines)
