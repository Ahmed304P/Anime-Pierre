import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    3, 8, 9, 11, 12 -> {
                        val title = when (selectedTab) {
                            8 -> "القائمة المخصصة"
                            9 -> "أنمياتي المفضلة"
                            11 -> "اخر المشاهدات"
                            12 -> "تحميلاتي"
                            else -> "قائمتي"
                        }
                        LibraryScreen(
                            selectedCategory = selectedLibraryCategory,
                            savedEntities = savedEntities,
                            watchHistoryList = watchHistoryList,
                            allAnimeList = allAnime,
                            onSelectCategory = { viewModel.setLibraryCategory(it) },
                            onRemoveSaved = { viewModel.removeSavedAnime(it) },
                            onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                            onOpenMenu = { scope.launch { drawerState.open() } },
                            title = title
                        )
                    }"""

replacement = """                    3, 8, 9, 12 -> {
                        val title = when (selectedTab) {
                            8 -> "القائمة المخصصة"
                            9 -> "أنمياتي المفضلة"
                            12 -> "تحميلاتي"
                            else -> "قائمتي"
                        }
                        LibraryScreen(
                            selectedCategory = selectedLibraryCategory,
                            savedEntities = savedEntities,
                            watchHistoryList = watchHistoryList,
                            allAnimeList = allAnime,
                            onSelectCategory = { viewModel.setLibraryCategory(it) },
                            onRemoveSaved = { viewModel.removeSavedAnime(it) },
                            onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                            onOpenMenu = { scope.launch { drawerState.open() } },
                            title = title
                        )
                    }
                    11 -> {
                        com.example.ui.screens.WatchHistoryScreen(
                            watchHistoryList = watchHistoryList,
                            allAnimeList = allAnime,
                            onOpenMenu = { scope.launch { drawerState.open() } },
                            onOpenSearch = { isSearchOverlayVisible = true },
                            onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                            onRemoveFromHistory = { viewModel.removeWatchHistory(it) }
                        )
                    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
