import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

old_func = """    fun getLocalComments(animeId: String, episodeNumber: Int): kotlinx.coroutines.flow.Flow<List<com.example.data.model.CommentItem>> {
        return kotlinx.coroutines.flow.map(dao.getCommentsForEpisode(animeId, episodeNumber)) { list ->
            list.map { entity ->
                com.example.data.model.CommentItem(
                    id = entity.id.toString(),
                    authorName = entity.authorName,
                    avatarUrl = "https://i.pravatar.cc/150?u=${entity.authorName}",
                    content = entity.content,
                    timeAgo = entity.timestamp,
                    likesCount = entity.likesCount,
                    isLikedByMe = entity.isLiked
                )
            }
        }
    }"""

new_func = """    fun getLocalComments(animeId: String, episodeNumber: Int): kotlinx.coroutines.flow.Flow<List<com.example.data.model.CommentItem>> {
        return dao.getCommentsForEpisode(animeId, episodeNumber).map { list ->
            list.map { entity ->
                com.example.data.model.CommentItem(
                    id = entity.id.toString(),
                    authorName = entity.authorName,
                    avatarUrl = "https://i.pravatar.cc/150?u=${entity.authorName}",
                    content = entity.content,
                    timeAgo = entity.timestamp,
                    likesCount = entity.likesCount,
                    isLikedByMe = entity.isLiked
                )
            }
        }
    }"""

content = content.replace(old_func, new_func)

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
    f.write(content)
