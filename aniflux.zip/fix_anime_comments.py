import re

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "r") as f:
    content = f.read()

# Replace the AnimatedContent block
target = """    AnimatedContent(
        targetState = activeThreadId != null,
        transitionSpec = {
            if (targetState) {
                slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
            } else {
                slideInHorizontally { -it } togetherWith slideOutHorizontally { it }
            }
        },
        label = "SocialScreenTransition",
        modifier = modifier
    ) { isThread ->
        if (isThread) {
            AnimeThreadScreen(
                viewModel = viewModel,
                parentCommentId = activeThreadId!!,
                onBack = { viewModel.setActiveThread(null) }
            )
        } else {
            MainCommentsContent(
                viewModel = viewModel,
                onBack = onBack
            )
        }
    }"""

replacement = """    var lastActiveThreadId by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(activeThreadId) {
        if (activeThreadId != null) {
            lastActiveThreadId = activeThreadId
        }
    }
    val currentThreadId = activeThreadId ?: lastActiveThreadId

    AnimatedContent(
        targetState = activeThreadId != null,
        transitionSpec = {
            if (targetState) {
                slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
            } else {
                slideInHorizontally { -it } togetherWith slideOutHorizontally { it }
            }
        },
        label = "SocialScreenTransition",
        modifier = modifier
    ) { isThread ->
        if (isThread && currentThreadId != null) {
            AnimeThreadScreen(
                viewModel = viewModel,
                parentCommentId = currentThreadId,
                onBack = { viewModel.setActiveThread(null) }
            )
        } else {
            MainCommentsContent(
                viewModel = viewModel,
                onBack = onBack
            )
        }
    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "w") as f:
    f.write(content)

