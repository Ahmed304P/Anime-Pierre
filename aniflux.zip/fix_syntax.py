import re
with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    "                    fontWeight = FontWeight.Bold\n                )\n            }\n        }\n    } else {",
    "                    fontWeight = FontWeight.Bold\n                )\n            }\n        }\n    }\n    } else {"
)

with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "w") as f:
    f.write(text)
