import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

replacement = """
    // --- Custom Lists ---
    val customLists = repository.getAllCustomLists().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun createCustomList(name: String, description: String) {
        viewModelScope.launch {
            repository.createCustomList(name, description)
        }
    }

    fun deleteCustomList(listId: Long) {
        viewModelScope.launch {
            repository.deleteCustomList(listId)
        }
    }

    private val _currentCustomListItems = MutableStateFlow<List<com.example.data.local.CustomListItemEntity>>(emptyList())
    val currentCustomListItems = _currentCustomListItems.asStateFlow()

    private var currentListJob: kotlinx.coroutines.Job? = null

    fun loadCustomListItems(listId: Long) {
        currentListJob?.cancel()
        currentListJob = viewModelScope.launch {
            repository.getCustomListItems(listId).collect { items ->
                _currentCustomListItems.value = items
            }
        }
    }

    fun addAnimeToCustomList(listId: Long, animeId: String) {
        viewModelScope.launch {
            repository.addAnimeToCustomList(listId, animeId)
        }
    }

    fun removeAnimeFromCustomList(listId: Long, animeId: String) {
        viewModelScope.launch {
            repository.removeAnimeFromCustomList(listId, animeId)
        }
    }
}"""

content = content[:content.rfind("}")] + replacement

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
