import re

with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "r") as f:
    content = f.read()

# Add imports
imports = """import com.example.data.model.FilterState
import com.example.ui.components.FilterBottomSheet"""
content = content.replace("import com.example.ui.components.AnimeCard", "import com.example.ui.components.AnimeCard\n" + imports)

# Update signature
old_sig = """@Composable
fun SearchScreenOverlay(
    visible: Boolean,
    onClose: () -> Unit,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    searchResults: List<Anime>,
    onOpenAnimeDetails: (Anime) -> Unit
) {"""

new_sig = """@Composable
fun SearchScreenOverlay(
    visible: Boolean,
    onClose: () -> Unit,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    searchResults: List<Anime>,
    onOpenAnimeDetails: (Anime) -> Unit,
    allAnime: List<Anime>,
    filterState: FilterState,
    onGenreFilterChange: (String?) -> Unit,
    onStatusFilterChange: (String?) -> Unit,
    onTypeFilterChange: (String?) -> Unit,
    onYearFilterChange: (Int?) -> Unit,
    onStudioFilterChange: (String?) -> Unit,
    onAgeRatingFilterChange: (String?) -> Unit,
    onSeasonFilterChange: (String?) -> Unit,
    onResetFilters: () -> Unit
) {
    var showFilterSheet by remember { mutableStateOf(false) }"""
content = content.replace(old_sig, new_sig)

# Update the filter button
filter_btn = """                    IconButton(onClick = { /* Filter */ }) {
                        Icon(
                            imageVector = Icons.Default.FilterAlt,
                            contentDescription = "Filter",
                            tint = Color.LightGray,
                            modifier = Modifier.size(22.dp)
                        )
                    }"""
new_filter_btn = """                    IconButton(onClick = { showFilterSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.FilterAlt,
                            contentDescription = "Filter",
                            tint = Color.LightGray,
                            modifier = Modifier.size(22.dp)
                        )
                    }"""
content = content.replace(filter_btn, new_filter_btn)

# Add FilterBottomSheet invocation
bottom_sheet_target = """            }
            // Results Grid"""

bottom_sheet_replacement = """            }

            if (showFilterSheet) {
                FilterBottomSheet(
                    allAnime = allAnime,
                    filterState = filterState,
                    onDismiss = { showFilterSheet = false },
                    onGenreFilterChange = onGenreFilterChange,
                    onStatusFilterChange = onStatusFilterChange,
                    onTypeFilterChange = onTypeFilterChange,
                    onYearFilterChange = onYearFilterChange,
                    onStudioFilterChange = onStudioFilterChange,
                    onAgeRatingFilterChange = onAgeRatingFilterChange,
                    onSeasonFilterChange = onSeasonFilterChange,
                    onResetFilters = onResetFilters
                )
            }

            // Results Grid"""
content = content.replace(bottom_sheet_target, bottom_sheet_replacement)

with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "w") as f:
    f.write(content)
