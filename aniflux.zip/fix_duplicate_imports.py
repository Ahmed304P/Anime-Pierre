import re
import os

files = [
    "app/src/main/java/com/example/ui/components/AnimeCard.kt",
    "app/src/main/java/com/example/ui/screens/ExploreScreen.kt",
    "app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt"
]

for f_path in files:
    with open(f_path, "r") as f:
        content = f.read()
    
    # Remove all imports for Animatable, tween, LaunchedEffect, graphicsLayer, launch
    content = re.sub(r'import androidx\.compose\.animation\.core\.Animatable\n?', '', content)
    content = re.sub(r'import androidx\.compose\.animation\.core\.tween\n?', '', content)
    content = re.sub(r'import androidx\.compose\.runtime\.LaunchedEffect\n?', '', content)
    content = re.sub(r'import androidx\.compose\.ui\.graphics\.graphicsLayer\n?', '', content)
    content = re.sub(r'import kotlinx\.coroutines\.launch\n?', '', content)
    
    # Re-insert them exactly once after package
    imports = """import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.launch
"""
    content = re.sub(r'(package .*\n)', r'\1\n' + imports, content)
    
    with open(f_path, "w") as f:
        f.write(content)
