import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

target = """                    IconButton(onClick = { socialViewModel.setShouldOpenComments(true) }) { Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chat") }"""
replacement = """                    val snackbarHostState = remember { SnackbarHostState() }
                    LaunchedEffect(Unit) {
                        // Just initializing
                    }
                    val coroutineScope = rememberCoroutineScope()
                    IconButton(onClick = {
                        if (anime.isCommentsLocked) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("التعليقات مغلقه من الاداره")
                            }
                        } else {
                            socialViewModel.setShouldOpenComments(true) 
                        }
                    }) { Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chat") }"""

content = content.replace(target, replacement)

# We also need to add a SnackbarHost to the Scaffold
target2 = """    Scaffold(
        modifier = modifier.fillMaxSize(),"""
replacement2 = """    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },"""

content = content.replace(target2, replacement2)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)

