with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    text = f.read()

import re
text = re.sub(r'\}\s*\}\s*\}\s*\}\s*@Composable\s*fun AnimeStatsTabContent', '}\n}\n}\n@Composable\nfun AnimeStatsTabContent', text)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(text)
