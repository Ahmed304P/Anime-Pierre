import re
with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

# Replace the entire NotificationBell composable to not use DropdownMenu
old_bell = """@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationBell(
    viewModel: SocialViewModel,
    onOpenNotifications: () -> Unit,
    onCloseDrawer: () -> Unit,
    onNotificationClicked: () -> Unit = {},
    modifier: Modifier = Modifier,
    tint: Color = Color.White
) {
    val notifications by viewModel.notifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }
    var showDropdown by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        IconButton(
            onClick = { showDropdown = true },
            modifier = Modifier.size(40.dp)
        ) {
            BadgedBox(
                badge = {
                    if (unreadCount > 0) {
                        Badge(
                            containerColor = Color.Red,
                            contentColor = Color.White
                        ) {
                            Text(unreadCount.toString())
                        }
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsNone,
                    contentDescription = "Notifications",
                    tint = tint,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        
        DropdownMenu(
            expanded = showDropdown,
            onDismissRequest = { showDropdown = false },
            modifier = Modifier
                .width(280.dp)
                .background(MaterialTheme.colorScheme.surface)
        ) {
            if (notifications.isEmpty()) {
                DropdownMenuItem(
                    text = { Text("لا توجد إشعارات", color = MaterialTheme.colorScheme.onSurface) },
                    onClick = { showDropdown = false }
                )
            } else {
                notifications.forEach { notif ->
                    DropdownMenuItem(
                        text = { 
                            Column {
                                Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(notif.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        },
                        onClick = { 
                            showDropdown = false
                            viewModel.markNotificationsAsRead()
                            viewModel.setTargetScrollComment(notif.targetCommentId)
                            onCloseDrawer()
                            onNotificationClicked()
                        }
                    )
                }
            }
        }
    }
}"""

new_bell = """@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationBell(
    viewModel: SocialViewModel,
    onOpenNotifications: () -> Unit,
    onCloseDrawer: () -> Unit,
    onNotificationClicked: () -> Unit = {},
    modifier: Modifier = Modifier,
    tint: Color = Color.White
) {
    val notifications by viewModel.notifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    Box(modifier = modifier) {
        IconButton(
            onClick = { 
                viewModel.setShouldOpenNotifications(true)
                onCloseDrawer()
            },
            modifier = Modifier.size(40.dp)
        ) {
            BadgedBox(
                badge = {
                    if (unreadCount > 0) {
                        Badge(
                            containerColor = Color.Red,
                            contentColor = Color.White
                        ) {
                            Text(unreadCount.toString())
                        }
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsNone,
                    contentDescription = "Notifications",
                    tint = tint,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}"""

content = content.replace(old_bell, new_bell)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
