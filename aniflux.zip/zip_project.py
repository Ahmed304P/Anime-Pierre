import os
import zipfile

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        if 'build' in root.split(os.sep) or '.gradle' in root.split(os.sep) or '.git' in root.split(os.sep):
            continue
        for file in files:
            if file.endswith('.zip') or file.endswith('.py'):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, path)
            ziph.write(file_path, arcname)

if __name__ == '__main__':
    zipf = zipfile.ZipFile('/app/applet/aniflux.zip', 'w', zipfile.ZIP_DEFLATED)
    zipdir('/app/applet', zipf)
    zipf.close()
    print("Zip created successfully.")
