import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    text = f.read()

text = text.replace(
    "onOpenSearch = { isSearchOverlayVisible = true },\n                        title = \"لائحة الانمي\"\n                    )",
    "onOpenSearch = { isSearchOverlayVisible = true },\n                        title = \"لائحة الانمي\",\n                        isGridMode = isGridMode,\n                        onToggleGridMode = { viewModel.toggleGridMode() }\n                    )"
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(text)
