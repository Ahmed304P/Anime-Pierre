import re

with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "r") as f:
    content = f.read()

target1 = """                        AnimatedVisibility(
                            visible = isVisible,
                            enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 4 }
                        ) {
                            HistoryAnimeCard(
                                anime = anime,
                                onClick = { onOpenAnimeDetails(anime) },
                                onRemove = { onRemoveFromHistory(anime.id) }
                            )
                        }"""

replacement1 = """                        Box {
                            androidx.compose.animation.AnimatedVisibility(
                                visible = isVisible,
                                enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 4 }
                            ) {
                                HistoryAnimeCard(
                                    anime = anime,
                                    onClick = { onOpenAnimeDetails(anime) },
                                    onRemove = { onRemoveFromHistory(anime.id) }
                                )
                            }
                        }"""

content = content.replace(target1, replacement1)

target2 = """            Surface(
                shape = RoundedCornerShape(topStart = 6.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier.align(Alignment.BottomEnd)
            ) {
                Text(
                    text = anime.year,
                    color = Color.White,
                    fontSize = 11.sp,"""

replacement2 = """            Surface(
                shape = RoundedCornerShape(topStart = 6.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier.align(Alignment.BottomEnd)
            ) {
                Text(
                    text = anime.year.toString(),
                    color = Color.White,
                    fontSize = 11.sp,"""

content = content.replace(target2, replacement2)

with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "w") as f:
    f.write(content)
