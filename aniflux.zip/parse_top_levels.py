with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    text = f.read()

count = 0
for line_num, line in enumerate(text.split("\n"), 1):
    if count == 0 and "fun " in line:
        print(f"Top level function: {line}")
    for char in line:
        if char == '{': count += 1
        elif char == '}': count -= 1
