import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

bad_block = """                
                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تأكيد الخروج", color = Color.White) },
                        text = { Text("هل أنت متأكد أنك تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("إلغاء", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }"""

# Insert right before the last closing braces
pattern = r"(\s+)\}\n\s+\}\n\s+\}\n\}$"

match = re.search(pattern, content)
if match:
    replacement = bad_block + match.group(0)
    content = content[:match.start()] + replacement
else:
    print("Could not find the end of the file braces pattern.")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

