import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

old_invocation = "0 -> AnimeDetailsTabContent(anime, onToggleSave, isSaved)"
new_invocation = "0 -> AnimeDetailsTabContent(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = { showMyListSheet = true })"
content = content.replace(old_invocation, new_invocation)

old_def = "fun AnimeDetailsTabContent(anime: Anime, onToggleSave: (String) -> Unit, isSaved: Boolean) {"
new_def = "fun AnimeDetailsTabContent(anime: Anime, isSaved: Boolean, savedStatus: String?, onOpenMyListOptions: () -> Unit) {"
content = content.replace(old_def, new_def)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
