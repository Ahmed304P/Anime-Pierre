import re

with open("app/src/main/java/com/example/ui/components/FilterBottomSheet.kt", "r") as f:
    content = f.read()

content = content.replace("import androidx.compose.foundation.layout.*", "import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.layout.ExperimentalLayoutApi\nimport androidx.compose.foundation.layout.FlowRow")

with open("app/src/main/java/com/example/ui/components/FilterBottomSheet.kt", "w") as f:
    f.write(content)
