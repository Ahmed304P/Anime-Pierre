import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace(
    """                    18 -> CompleteProfileScreen(
                        onComplete = { viewModel.setSelectedTab(0, addToHistory = false) }
                    )""",
    """                    18 -> CompleteProfileScreen(
                        onComplete = { name, avatar, banner ->
                            viewModel.completeLogin(name, avatar, banner)
                            viewModel.setSelectedTab(0, addToHistory = false)
                        }
                    )"""
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
