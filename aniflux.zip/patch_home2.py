import re

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

pattern = re.compile(r"val animatedAlpha = remember.*?graphicsLayer\s*\{.*?\}\s*", re.DOTALL)
content = pattern.sub("val cardModifier = Modifier.animateItem()\n                    ", content)

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
