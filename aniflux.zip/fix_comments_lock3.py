import re

with open("app/src/main/java/com/example/ui/components/VideoPlayerModal.kt", "r") as f:
    content = f.read()

target = """                    // Comment Section
                    CommentSection(
                        comments = comments,
                        onAddComment = onAddComment,
                        onLikeComment = onLikeComment
                    )"""

replacement = """                    // Comment Section
                    if (anime.isCommentsLocked) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "التعليقات مغلقه من الاداره",
                                color = Color.Red,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        CommentSection(
                            comments = comments,
                            onAddComment = onAddComment,
                            onLikeComment = onLikeComment
                        )
                    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/components/VideoPlayerModal.kt", "w") as f:
    f.write(content)

