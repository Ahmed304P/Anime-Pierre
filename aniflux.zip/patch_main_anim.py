import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Make sure imports are present
imports_to_add = """import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
"""
if "import androidx.compose.animation.AnimatedVisibility" not in content:
    content = content.replace("package com.example", "package com.example\n" + imports_to_add)

# The target block
target = """                // Anime Detail Screen Overlay
                if (selectedAnimeDetails != null) {
                    val anime = selectedAnimeDetails!!
                    val episodes = remember(anime) { viewModel.getEpisodesForAnime(anime) }
                    val isSaved by viewModel.isAnimeSaved(anime.id).collectAsStateWithLifecycle(initialValue = false)
                    val savedStatus by viewModel.getAnimeSavedStatus(anime.id).collectAsStateWithLifecycle(initialValue = null)

                    AnimeDetailScreen(
                        anime = anime,
                        episodes = episodes,
                        isSaved = isSaved,
                        savedStatus = savedStatus,
                        onBack = { viewModel.closeAnimeDetails() },
                        onToggleSave = { status -> viewModel.toggleSaveAnime(anime.id, status) },
                        onRemoveSaved = { animeId -> viewModel.removeSavedAnime(animeId) },
                        onOpenPlayer = { ep ->
                            viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                            viewModel.openPlayer(anime, ep)
                        }
                    )
                }"""

# The replacement block using AnimatedContent to handle the null state gracefully
replacement = """                // Anime Detail Screen Overlay
                AnimatedVisibility(
                    visible = selectedAnimeDetails != null,
                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400)) + fadeIn(animationSpec = tween(400)),
                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(400)) + fadeOut(animationSpec = tween(400))
                ) {
                    // We need a non-null reference inside the animation scope.
                    // But since selectedAnimeDetails becomes null on exit, we keep the last known value
                    var lastAnime by remember { androidx.compose.runtime.mutableStateOf<com.example.data.model.Anime?>(null) }
                    androidx.compose.runtime.LaunchedEffect(selectedAnimeDetails) {
                        if (selectedAnimeDetails != null) {
                            lastAnime = selectedAnimeDetails
                        }
                    }
                    val currentAnime = selectedAnimeDetails ?: lastAnime

                    if (currentAnime != null) {
                        val anime = currentAnime
                        val episodes = remember(anime) { viewModel.getEpisodesForAnime(anime) }
                        val isSaved by viewModel.isAnimeSaved(anime.id).collectAsStateWithLifecycle(initialValue = false)
                        val savedStatus by viewModel.getAnimeSavedStatus(anime.id).collectAsStateWithLifecycle(initialValue = null)

                        AnimeDetailScreen(
                            anime = anime,
                            episodes = episodes,
                            isSaved = isSaved,
                            savedStatus = savedStatus,
                            onBack = { viewModel.closeAnimeDetails() },
                            onToggleSave = { status -> viewModel.toggleSaveAnime(anime.id, status) },
                            onRemoveSaved = { animeId -> viewModel.removeSavedAnime(animeId) },
                            onOpenPlayer = { ep ->
                                viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                                viewModel.openPlayer(anime, ep)
                            }
                        )
                    }
                }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
