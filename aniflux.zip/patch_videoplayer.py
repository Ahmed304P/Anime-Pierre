import re

with open("app/src/main/java/com/example/ui/components/VideoPlayerModal.kt", "r") as f:
    content = f.read()

content = content.replace("var currentProgressSeconds by remember { mutableFloatStateOf(120f) }", "var currentProgressSeconds by remember { mutableFloatStateOf(0f) }\n    var skipUsed by remember(currentEpisode) { mutableStateOf(false) }")


target = """                        Text(
                            text = "السيرفر: ${selectedServer?.nameAr ?: "سيرفر AniFlux FHD"}",
                            color = AniFluxCyan,
                            fontSize = 11.sp
                        )
                    }"""

replacement = """                        Text(
                            text = "السيرفر: ${selectedServer?.nameAr ?: "سيرفر AniFlux FHD"}",
                            color = AniFluxCyan,
                            fontSize = 11.sp
                        )
                    }
                    
                    if (currentProgressSeconds < skipTime + 5f && !skipUsed) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = 24.dp, end = 24.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.9f))
                                .clickable {
                                    currentProgressSeconds += skipTime.toFloat()
                                    skipUsed = true
                                }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "تخطي",
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.FastForward,
                                    contentDescription = "Skip",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/components/VideoPlayerModal.kt", "w") as f:
    f.write(content)
