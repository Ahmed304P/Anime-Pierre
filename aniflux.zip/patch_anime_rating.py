import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

target1 = """fun AnimeDetailsTabContent(anime: Anime, isSaved: Boolean, savedStatus: String?, onOpenMyListOptions: () -> Unit) {"""
replacement1 = """fun AnimeDetailsTabContent(anime: Anime, isSaved: Boolean, savedStatus: String?, onOpenMyListOptions: () -> Unit, onRateClick: () -> Unit) {"""
content = content.replace(target1, replacement1)

target2 = """            AnimeActionsRow(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = onOpenMyListOptions)"""
replacement2 = """            AnimeActionsRow(anime = anime, isSaved = isSaved, savedStatus = savedStatus, onOpenMyListOptions = onOpenMyListOptions, onRateClick = onRateClick)"""
content = content.replace(target2, replacement2)

target3 = """fun AnimeActionsRow(
    anime: Anime, 
    isSaved: Boolean, 
    savedStatus: String?, 
    onOpenMyListOptions: () -> Unit
) {"""
replacement3 = """fun AnimeActionsRow(
    anime: Anime, 
    isSaved: Boolean, 
    savedStatus: String?, 
    onOpenMyListOptions: () -> Unit,
    onRateClick: () -> Unit
) {"""
content = content.replace(target3, replacement3)

target4 = """        // Add Rating
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.bounceClick { }) {"""
replacement4 = """        // Add Rating
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.bounceClick { onRateClick() }) {"""
content = content.replace(target4, replacement4)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
