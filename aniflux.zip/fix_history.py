with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    "    Column(\n        modifier = modifier\n            .fillMaxWidth()\n            .clip(RoundedCornerShape(6.dp))\n            .combinedClickable(\n                onClick = onClick,\n                onLongClick = { showDeleteMenu = true }\n            )\n    ) {",
    "    if (isGridMode) {\n    Column(\n        modifier = modifier\n            .fillMaxWidth()\n            .clip(RoundedCornerShape(6.dp))\n            .combinedClickable(\n                onClick = onClick,\n                onLongClick = { showDeleteMenu = true }\n            )\n    ) {"
)

with open("app/src/main/java/com/example/ui/screens/WatchHistoryScreen.kt", "w") as f:
    f.write(text)
