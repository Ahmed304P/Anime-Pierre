import re

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "r") as f:
    content = f.read()

target = """@Composable
fun ExploreScreen(
    filteredAnimeList: List<Anime>,
    filterState: FilterState,
    onSearchQueryChange: (String) -> Unit,
    onGenreFilterChange: (String?) -> Unit,
    onStatusFilterChange: (String?) -> Unit,
    onTypeFilterChange: (String?) -> Unit,
    onResetFilters: () -> Unit,
    onOpenAnimeDetails: (Anime) -> Unit,
    onOpenMenu: () -> Unit = {},
    onOpenSearch: () -> Unit = {},
    title: String = "لائحة الانمي",
    modifier: Modifier = Modifier
) {"""

replacement = """import androidx.compose.material.icons.filled.FilterAlt
import com.example.ui.components.FilterBottomSheet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    allAnime: List<Anime>,
    filteredAnimeList: List<Anime>,
    filterState: FilterState,
    onSearchQueryChange: (String) -> Unit,
    onGenreFilterChange: (String?) -> Unit,
    onStatusFilterChange: (String?) -> Unit,
    onTypeFilterChange: (String?) -> Unit,
    onYearFilterChange: (Int?) -> Unit,
    onStudioFilterChange: (String?) -> Unit,
    onAgeRatingFilterChange: (String?) -> Unit,
    onSeasonFilterChange: (String?) -> Unit,
    onResetFilters: () -> Unit,
    onOpenAnimeDetails: (Anime) -> Unit,
    onOpenMenu: () -> Unit = {},
    onOpenSearch: () -> Unit = {},
    title: String = "لائحة الانمي",
    modifier: Modifier = Modifier
) {
    var showFilterSheet by remember { mutableStateOf(false) }"""

content = content.replace(target, replacement)

# Add the Filter icon in the App Bar
appbar_target = """                IconButton(onClick = onOpenSearch) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }"""
appbar_replacement = """                IconButton(onClick = onOpenSearch) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                IconButton(onClick = { showFilterSheet = true }) {
                    Icon(
                        imageVector = Icons.Default.FilterAlt,
                        contentDescription = "Filter",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }"""
content = content.replace(appbar_target, appbar_replacement)

# Add the bottom sheet at the end of ExploreScreen
bottom_sheet_target = """        // Content Area
        AnimatedContent("""
bottom_sheet_replacement = """        // Filter Bottom Sheet
        if (showFilterSheet) {
            FilterBottomSheet(
                allAnime = allAnime,
                filterState = filterState,
                onDismiss = { showFilterSheet = false },
                onGenreFilterChange = onGenreFilterChange,
                onStatusFilterChange = onStatusFilterChange,
                onTypeFilterChange = onTypeFilterChange,
                onYearFilterChange = onYearFilterChange,
                onStudioFilterChange = onStudioFilterChange,
                onAgeRatingFilterChange = onAgeRatingFilterChange,
                onSeasonFilterChange = onSeasonFilterChange,
                onResetFilters = onResetFilters
            )
        }

        // Content Area
        AnimatedContent("""
content = content.replace(bottom_sheet_target, bottom_sheet_replacement)

with open("app/src/main/java/com/example/ui/screens/ExploreScreen.kt", "w") as f:
    f.write(content)
