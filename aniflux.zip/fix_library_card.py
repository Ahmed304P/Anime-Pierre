import re
with open("app/src/main/java/com/example/ui/screens/LibraryScreen.kt", "r") as f:
    text = f.read()

old = """                                    AnimeCard(index = index,
                                        anime = anime,
                                        onClick = { onOpenAnimeDetails(anime) }
                                    )"""

new = """                                    if (isGridMode) {
                                        AnimeCard(index = index,
                                            anime = anime,
                                            onClick = { onOpenAnimeDetails(anime) }
                                        )
                                    } else {
                                        com.example.ui.components.AnimeListCard(index = index,
                                            anime = anime,
                                            onClick = { onOpenAnimeDetails(anime) }
                                        )
                                    }"""

text = text.replace(old, new)
with open("app/src/main/java/com/example/ui/screens/LibraryScreen.kt", "w") as f:
    f.write(text)
