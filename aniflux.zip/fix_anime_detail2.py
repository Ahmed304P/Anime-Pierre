import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

target = """    val tabs = listOf("التفاصيل", "الحلقات", "الاحصائيات", "الشخصيات والطاقم")

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold("""

replacement = """    val tabs = listOf("التفاصيل", "الحلقات", "الاحصائيات", "الشخصيات والطاقم")
    val snackbarHostState = remember { SnackbarHostState() }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)

