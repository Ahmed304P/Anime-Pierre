import re

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

target_block = """                    items(items = allAnime, key = { it.id }) { anime ->
                    if (isThreeColumns) {
                        AnimeCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            showLargePoster = false,
                            modifier = Modifier.animateItem()
                        )
                    } else {
                        com.example.ui.components.AnimeListCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            modifier = Modifier.animateItem()
                        )
                    }
                }"""

replacement_block = """                    items(items = allAnime, key = { it.id }) { anime ->
                    val animatedAlpha = remember { androidx.compose.animation.core.Animatable(0f) }
                    val animatedTranslationY = remember { androidx.compose.animation.core.Animatable(100f) }
                    
                    LaunchedEffect(anime.id) {
                        kotlinx.coroutines.launch { animatedAlpha.animateTo(1f, androidx.compose.animation.core.tween(500)) }
                        kotlinx.coroutines.launch { animatedTranslationY.animateTo(0f, androidx.compose.animation.core.tween(500)) }
                    }
                    
                    val cardModifier = Modifier
                        .animateItem()
                        .androidx.compose.ui.graphics.graphicsLayer {
                            alpha = animatedAlpha.value
                            translationY = animatedTranslationY.value
                        }

                    if (isThreeColumns) {
                        AnimeCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            showLargePoster = false,
                            modifier = cardModifier
                        )
                    } else {
                        com.example.ui.components.AnimeListCard(
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            modifier = cardModifier
                        )
                    }
                }"""

# Using regex to replace the block to be more robust
pattern = re.compile(r'items\(items = allAnime, key = \{ it\.id \}\) \{ anime ->[\s\S]*?modifier = Modifier\.animateItem\(\)[\s\S]*?\}[\s\S]*?\}', re.MULTILINE)

content = content.replace("androidx.compose.ui.graphics.graphicsLayer", "androidx.compose.ui.graphics.graphicsLayer") # ensure it works

# I will just write a python script to find and replace
if target_block in content:
    content = content.replace(target_block, replacement_block.replace("androidx.compose.ui.graphics.", ""))
else:
    # Try regex
    content = re.sub(r'items\(items = allAnime, key = \{ it.id \}\) \{ anime ->[\s\S]*?else \{[\s\S]*?\}\n                \}', replacement_block.replace("androidx.compose.ui.graphics.", ""), content)


with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
