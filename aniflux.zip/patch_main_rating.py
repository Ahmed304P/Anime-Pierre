import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace(
    "onToggleWatched = { epNum, watched -> viewModel.toggleEpisodeWatched(anime.id, epNum, watched) },",
    "onToggleWatched = { epNum, watched -> viewModel.toggleEpisodeWatched(anime.id, epNum, watched) },\n                            onRateAnime = { rating -> viewModel.rateAnime(anime.id, rating) },"
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
