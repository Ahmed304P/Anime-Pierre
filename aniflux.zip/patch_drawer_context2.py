import re

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "r") as f:
    content = f.read()

# Let's make sure android.widget.Toast is correctly used
content = content.replace(
    "onClick = { android.widget.Toast.makeText(context, \"لا توجد إشعارات جديدة حالياً\", android.widget.Toast.LENGTH_SHORT).show() }",
    "onClick = { android.widget.Toast.makeText(context, \"لا توجد إشعارات جديدة حالياً\", android.widget.Toast.LENGTH_SHORT).show() }"
)

with open("app/src/main/java/com/example/ui/components/AnimeSlayerDrawer.kt", "w") as f:
    f.write(content)
