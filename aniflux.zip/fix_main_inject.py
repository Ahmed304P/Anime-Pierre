import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    text = f.read()

# For MyListScreen
text = text.replace(
    "onOpenAnimeDetails = { \n                        isSearchOverlayVisible = false\n                        viewModel.updateSearchQuery(\"\")\n                        viewModel.openAnimeDetails(it)\n                    }\n                        )",
    "onOpenAnimeDetails = { \n                        isSearchOverlayVisible = false\n                        viewModel.updateSearchQuery(\"\")\n                        viewModel.openAnimeDetails(it)\n                    },\n                            isGridMode = isGridMode\n                        )"
)

# For CustomListDetailScreen
text = text.replace(
    "onOpenAnimeDetails = { \n                        isSearchOverlayVisible = false\n                        viewModel.updateSearchQuery(\"\")\n                        viewModel.openAnimeDetails(it)\n                    },\n                                        onDeleteList = {",
    "onOpenAnimeDetails = { \n                        isSearchOverlayVisible = false\n                        viewModel.updateSearchQuery(\"\")\n                        viewModel.openAnimeDetails(it)\n                    },\n                                        isGridMode = isGridMode,\n                                        onDeleteList = {"
)

# For FavoritesScreen & WatchHistoryScreen
text = text.replace(
    "onRemoveFromFavorites = { viewModel.removeSavedAnime(it) }\n                        )",
    "onRemoveFromFavorites = { viewModel.removeSavedAnime(it) },\n                            isGridMode = isGridMode\n                        )"
)

text = text.replace(
    "onRemoveFromHistory = { viewModel.removeWatchHistory(it) }\n                        )",
    "onRemoveFromHistory = { viewModel.removeWatchHistory(it) },\n                            isGridMode = isGridMode\n                        )"
)

# For SearchScreenOverlay
text = text.replace(
    "onResetFilters = { viewModel.resetFilters() }\n                )",
    "onResetFilters = { viewModel.resetFilters() },\n                    isGridMode = isGridMode\n                )"
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(text)
