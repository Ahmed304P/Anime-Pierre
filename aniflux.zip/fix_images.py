import re

def fix_file(path):
    with open(path, "r") as f:
        content = f.read()

    bad_string = "loading = { androidx.compose.foundation.layout.Box(modifier = androidx.compose.ui.Modifier.fillMaxSize().shimmerEffect()) },\n                contentDescription ="
    content = content.replace(bad_string, "contentDescription =")

    pattern = r'(SubcomposeAsyncImage\([\s\S]*?)(contentDescription =)'
    new_content = re.sub(pattern, r'\1loading = { androidx.compose.foundation.layout.Box(modifier = androidx.compose.ui.Modifier.fillMaxSize().shimmerEffect()) },\n            \2', content)

    with open(path, "w") as f:
        f.write(new_content)
        
fix_file("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt")
fix_file("app/src/main/java/com/example/ui/components/FeaturedCarousel.kt")
