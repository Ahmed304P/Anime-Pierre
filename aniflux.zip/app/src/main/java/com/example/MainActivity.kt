package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AnimeSlayerDrawerContent
import com.example.ui.components.VideoPlayerModal
import com.example.ui.screens.*
import com.example.ui.screens.PlaceholderScreen
import com.example.ui.theme.AniFluxBg
import com.example.ui.theme.AniFluxCyan
import com.example.ui.theme.AniFluxPrimary
import com.example.ui.theme.AniFluxSurface
import com.example.ui.theme.AniFluxSurfaceVariant
import com.example.ui.theme.AniFluxTextSecondary
import com.example.ui.theme.AniFluxTheme
import com.example.ui.viewmodel.AnimeViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AniFluxTheme {
                AniFluxAppShell()
            }
        }
    }
}

@Composable
fun AniFluxAppShell(
    viewModel: AnimeViewModel = viewModel()
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val allAnime by viewModel.allAnime.collectAsStateWithLifecycle()
    val filteredAnimeList by viewModel.filteredAnimeList.collectAsStateWithLifecycle()
    val filterState by viewModel.filterState.collectAsStateWithLifecycle()
    val selectedAnimeDetails by viewModel.selectedAnimeForDetails.collectAsStateWithLifecycle()
    val activePlayerPair by viewModel.activePlayerEpisode.collectAsStateWithLifecycle()
    val savedEntities by viewModel.savedAnimeEntities.collectAsStateWithLifecycle()
    val watchHistoryList by viewModel.watchHistory.collectAsStateWithLifecycle()
    val activeComments by viewModel.activeComments.collectAsStateWithLifecycle()
    val selectedScheduleDay by viewModel.selectedScheduleDay.collectAsStateWithLifecycle()
    val scheduledAnimeList by viewModel.scheduledAnimeList.collectAsStateWithLifecycle()
    val selectedLibraryCategory by viewModel.selectedLibraryCategory.collectAsStateWithLifecycle()
    val aiMessages by viewModel.aiMessages.collectAsStateWithLifecycle()

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = selectedAnimeDetails == null && activePlayerPair == null,
        drawerContent = {
            AnimeSlayerDrawerContent(
                selectedTab = selectedTab,
                onSelectTab = { tabIndex -> viewModel.setSelectedTab(tabIndex) },
                onCloseDrawer = { scope.launch { drawerState.close() } }
            )
        }
    ) {
        Scaffold(
            containerColor = AniFluxBg
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Main Navigation Screen Selection
                when (selectedTab) {
                    0 -> HomeScreen(
                        allAnime = allAnime,
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        onOpenSearch = { viewModel.setSelectedTab(1) },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) }
                    )

                    1 -> ExploreScreen(
                        filteredAnimeList = filteredAnimeList,
                        filterState = filterState,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onGenreFilterChange = { viewModel.updateGenreFilter(it) },
                        onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        title = "لائحة الانمي"
                    )

                    2 -> ScheduleScreen(
                        selectedDay = selectedScheduleDay,
                        scheduledAnimeList = scheduledAnimeList,
                        onSelectDay = { viewModel.setScheduleDay(it) },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } }
                    )

                    3, 8, 9, 11 -> {
                        val title = when (selectedTab) {
                            8 -> "القائمة المخصصة"
                            9 -> "أنمياتي المفضلة"
                            11 -> "اخر المشاهدات"
                            else -> "قائمتي"
                        }
                        LibraryScreen(
                            selectedCategory = selectedLibraryCategory,
                            savedEntities = savedEntities,
                            watchHistoryList = watchHistoryList,
                            allAnimeList = allAnime,
                            onSelectCategory = { viewModel.setLibraryCategory(it) },
                            onRemoveSaved = { viewModel.removeSavedAnime(it) },
                            onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                            onOpenMenu = { scope.launch { drawerState.open() } },
                            title = title
                        )
                    }

                    4 -> AiAssistantScreen(
                        messages = aiMessages,
                        onSendPrompt = { viewModel.sendAiPrompt(it) },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } }
                    )
                    
                    5 -> ExploreScreen(
                        filteredAnimeList = filteredAnimeList,
                        filterState = filterState,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onGenreFilterChange = { viewModel.updateGenreFilter(it) },
                        onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        title = "المواسم"
                    )

                    6 -> ExploreScreen(
                        filteredAnimeList = filteredAnimeList,
                        filterState = filterState,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onGenreFilterChange = { viewModel.updateGenreFilter(it) },
                        onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        title = "التقييم العالمي"
                    )

                    7 -> ExploreScreen(
                        filteredAnimeList = filteredAnimeList,
                        filterState = filterState,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onGenreFilterChange = { viewModel.updateGenreFilter(it) },
                        onStatusFilterChange = { viewModel.updateStatusFilter(it) },
                        onTypeFilterChange = { viewModel.updateTypeFilter(it) },
                        onResetFilters = { viewModel.resetFilters() },
                        onOpenAnimeDetails = { viewModel.openAnimeDetails(it) },
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        title = "التقييم العربي"
                    )

                    10 -> PlaceholderScreen(
                        title = "شخصياتي المفضلة",
                        icon = androidx.compose.material.icons.Icons.Default.Favorite,
                        onOpenMenu = { scope.launch { drawerState.open() } }
                    )

                    12 -> PlaceholderScreen(
                        title = "تحميلاتي",
                        icon = androidx.compose.material.icons.Icons.Default.FileDownload,
                        onOpenMenu = { scope.launch { drawerState.open() } }
                    )

                    13 -> PlaceholderScreen(
                        title = "الشخصيات الأكثر شعبية",
                        icon = androidx.compose.material.icons.Icons.Default.Group,
                        onOpenMenu = { scope.launch { drawerState.open() } }
                    )

                    14 -> PlaceholderScreen(
                        title = "الاعدادات",
                        icon = androidx.compose.material.icons.Icons.Default.Settings,
                        onOpenMenu = { scope.launch { drawerState.open() } }
                    )

                    15 -> ProfileScreen(
                        onBackClick = { viewModel.setSelectedTab(0) },
                        onEditClick = { viewModel.setSelectedTab(16) }
                    )

                    16 -> EditProfileScreen(
                        onBackClick = { viewModel.setSelectedTab(15) }
                    )
                }

                // Anime Detail Screen Overlay
                if (selectedAnimeDetails != null) {
                    val anime = selectedAnimeDetails!!
                    val episodes = remember(anime) { viewModel.getEpisodesForAnime(anime) }
                    val isSaved by viewModel.isAnimeSaved(anime.id).collectAsStateWithLifecycle(initialValue = false)
                    val savedStatus by viewModel.getAnimeSavedStatus(anime.id).collectAsStateWithLifecycle(initialValue = null)

                    AnimeDetailScreen(
                        anime = anime,
                        episodes = episodes,
                        isSaved = isSaved,
                        savedStatus = savedStatus,
                        onBack = { viewModel.closeAnimeDetails() },
                        onToggleSave = { status -> viewModel.toggleSaveAnime(anime.id, status) },
                        onOpenPlayer = { ep ->
                            viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                            viewModel.openPlayer(anime, ep)
                        }
                    )
                }

                // Video Player Modal Overlay
                if (activePlayerPair != null) {
                    val (anime, activeEp) = activePlayerPair!!
                    val episodes = remember(anime) { viewModel.getEpisodesForAnime(anime) }

                    VideoPlayerModal(
                        anime = anime,
                        currentEpisode = activeEp,
                        allEpisodes = episodes,
                        comments = activeComments,
                        onClose = { viewModel.closePlayer() },
                        onSelectEpisode = { ep ->
                            viewModel.loadCommentsForEpisode(anime.id, ep.episodeNumber)
                            viewModel.openPlayer(anime, ep)
                        },
                        onAddComment = { content ->
                            viewModel.addComment(anime.id, activeEp.episodeNumber, "متابع AniFlux", content)
                        },
                        onLikeComment = { commentId ->
                            viewModel.likeComment(commentId)
                        },
                        onRecordProgress = { progressSec, totalSec ->
                            viewModel.recordWatchProgress(
                                anime.id,
                                activeEp.episodeNumber,
                                activeEp.titleAr,
                                progressSec,
                                totalSec
                            )
                        }
                    )
                }
            }
        }
    }
}
