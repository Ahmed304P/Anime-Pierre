package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AniFluxPrimary,
    onPrimary = Color.White,
    primaryContainer = AniFluxPrimaryVariant,
    onPrimaryContainer = Color.White,
    secondary = AniFluxSecondary,
    onSecondary = Color.White,
    tertiary = AniFluxCyan,
    onTertiary = Color.White,
    background = AniFluxBg,
    onBackground = AniFluxTextPrimary,
    surface = AniFluxSurface,
    onSurface = AniFluxTextPrimary,
    surfaceVariant = AniFluxSurfaceVariant,
    onSurfaceVariant = AniFluxTextSecondary
)

@Composable
fun AniFluxTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
