package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AniFluxDatabase
import com.example.data.model.*
import com.example.data.repository.AnimeRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String, // "USER" or "AI"
    val text: String,
    val suggestedAnimeList: List<Anime> = emptyList()
)

class AnimeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AniFluxDatabase.getDatabase(application)
    private val repository = AnimeRepository(db.dao())

    // UI Navigation State
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    fun setSelectedTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
        when (tabIndex) {
            8 -> setLibraryCategory(LibraryCategory.PLAN_TO_WATCH)
            9 -> setLibraryCategory(LibraryCategory.FAVORITES)
            11 -> setLibraryCategory(LibraryCategory.HISTORY)
            // Default to WATCHING if tab 3 is clicked directly
            3 -> setLibraryCategory(LibraryCategory.WATCHING)
            
            // For Ratings, could optionally reset filters and change sort order
            1, 5, 6, 7 -> resetFilters()
        }
    }

    // Anime Data Catalog
    val allAnime: StateFlow<List<Anime>> = MutableStateFlow(repository.sampleAnimeList)

    val featuredAnime: StateFlow<Anime?> = allAnime.map { list ->
        list.find { it.isFeatured } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Lazily, repository.sampleAnimeList.firstOrNull())

    // Search and Filters
    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    fun updateSearchQuery(query: String) {
        _filterState.update { it.copy(query = query) }
    }

    fun updateGenreFilter(genre: String?) {
        _filterState.update { it.copy(selectedGenre = if (it.selectedGenre == genre) null else genre) }
    }

    fun updateStatusFilter(status: String?) {
        _filterState.update { it.copy(selectedStatus = if (it.selectedStatus == status) null else status) }
    }

    fun updateTypeFilter(type: String?) {
        _filterState.update { it.copy(selectedType = if (it.selectedType == type) null else type) }
    }

    fun resetFilters() {
        _filterState.value = FilterState()
    }

    // Filtered Anime List for Explore / Search
    val filteredAnimeList: StateFlow<List<Anime>> = combine(allAnime, _filterState) { list, filters ->
        list.filter { anime ->
            val matchesQuery = filters.query.isBlank() ||
                    anime.titleAr.contains(filters.query, ignoreCase = true) ||
                    anime.titleEn.contains(filters.query, ignoreCase = true) ||
                    anime.genres.any { it.contains(filters.query, ignoreCase = true) }

            val matchesGenre = filters.selectedGenre == null || anime.genres.contains(filters.selectedGenre)
            val matchesStatus = filters.selectedStatus == null || anime.status == filters.selectedStatus
            val matchesType = filters.selectedType == null || anime.type == filters.selectedType

            matchesQuery && matchesGenre && matchesStatus && matchesType
        }.sortedByDescending { it.rating }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Anime Details Screen
    private val _selectedAnimeForDetails = MutableStateFlow<Anime?>(null)
    val selectedAnimeForDetails: StateFlow<Anime?> = _selectedAnimeForDetails.asStateFlow()

    fun openAnimeDetails(anime: Anime) {
        _selectedAnimeForDetails.value = anime
    }

    fun closeAnimeDetails() {
        _selectedAnimeForDetails.value = null
    }

    // Active Video Player Modal
    private val _activePlayerEpisode = MutableStateFlow<Pair<Anime, Episode>?>(null)
    val activePlayerEpisode: StateFlow<Pair<Anime, Episode>?> = _activePlayerEpisode.asStateFlow()

    fun openPlayer(anime: Anime, episode: Episode) {
        _activePlayerEpisode.value = Pair(anime, episode)
    }

    fun closePlayer() {
        _activePlayerEpisode.value = null
    }

    // Episodes list for current anime
    fun getEpisodesForAnime(anime: Anime): List<Episode> {
        return repository.getEpisodesForAnime(anime.id, anime.currentEpisodes)
    }

    // Saved Anime / Favorites Flow from Room DB
    val savedAnimeEntities = repository.getAllSavedAnime().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun isAnimeSaved(animeId: String): Flow<Boolean> {
        return repository.getSavedAnimeById(animeId).map { it != null }
    }

    fun getAnimeSavedStatus(animeId: String): Flow<String?> {
        return repository.getSavedAnimeById(animeId).map { it?.status }
    }

    fun toggleSaveAnime(animeId: String, status: String = "FAVORITE") {
        viewModelScope.launch {
            repository.setAnimeSavedStatus(animeId, status)
        }
    }

    fun removeSavedAnime(animeId: String) {
        viewModelScope.launch {
            repository.removeSavedAnime(animeId)
        }
    }

    // Watch History
    val watchHistory = repository.getAllWatchHistory().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun recordWatchProgress(animeId: String, episodeNum: Int, title: String, progressSec: Int, totalSec: Int) {
        viewModelScope.launch {
            repository.recordWatchProgress(animeId, episodeNum, title, progressSec, totalSec)
        }
    }

    // Episode Comments State
    private val _activeComments = MutableStateFlow<List<CommentItem>>(emptyList())
    val activeComments: StateFlow<List<CommentItem>> = _activeComments.asStateFlow()

    fun loadCommentsForEpisode(animeId: String, epNum: Int) {
        viewModelScope.launch {
            // Combine initial sample comments with local room comments
            repository.getLocalComments(animeId, epNum).collect { localList ->
                val initial = repository.getInitialComments(animeId, epNum)
                _activeComments.value = localList + initial
            }
        }
    }

    fun addComment(animeId: String, epNum: Int, author: String, content: String) {
        viewModelScope.launch {
            repository.addComment(animeId, epNum, author, content)
            loadCommentsForEpisode(animeId, epNum)
        }
    }

    fun likeComment(commentId: String) {
        val idLong = commentId.toLongOrNull()
        if (idLong != null) {
            viewModelScope.launch {
                repository.likeComment(idLong)
            }
        } else {
            _activeComments.update { list ->
                list.map { c ->
                    if (c.id == commentId) {
                        c.copy(
                            likesCount = if (c.isLikedByMe) c.likesCount - 1 else c.likesCount + 1,
                            isLikedByMe = !c.isLikedByMe
                        )
                    } else c
                }
            }
        }
    }

    // Schedule Day Filter
    private val _selectedScheduleDay = MutableStateFlow("الأحد")
    val selectedScheduleDay: StateFlow<String> = _selectedScheduleDay.asStateFlow()

    fun setScheduleDay(day: String) {
        _selectedScheduleDay.value = day
    }

    val scheduledAnimeList: StateFlow<List<Anime>> = combine(allAnime, _selectedScheduleDay) { list, day ->
        list.filter { it.releaseDay == day }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Library Tab Filter
    private val _selectedLibraryCategory = MutableStateFlow(LibraryCategory.FAVORITES)
    val selectedLibraryCategory: StateFlow<LibraryCategory> = _selectedLibraryCategory.asStateFlow()

    fun setLibraryCategory(category: LibraryCategory) {
        _selectedLibraryCategory.value = category
    }

    // AI Recommendation Assistant
    private val _aiMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                sender = "AI",
                text = "أهلاً بك في مساعد AniFlux الذكي! 🤖✨\nاطلب مني أي اقتراحات لأنمي، مثل:\n- \"أبي أنمي ذكاء وغموض\"\n- \"اقترح لي أنمي خيال وأكشن قوافل\"\n- \"أنمي رومنسي وشريحة من الحياة\""
            )
        )
    )
    val aiMessages: StateFlow<List<ChatMessage>> = _aiMessages.asStateFlow()

    fun sendAiPrompt(promptText: String) {
        if (promptText.isBlank()) return

        val userMsg = ChatMessage(sender = "USER", text = promptText)
        _aiMessages.update { it + userMsg }

        viewModelScope.launch {
            val queryLower = promptText.lowercase()
            val matchedAnime = repository.sampleAnimeList.filter { anime ->
                queryLower.split(" ").any { keyword ->
                    keyword.length > 2 && (
                        anime.titleAr.contains(keyword, true) ||
                        anime.synopsisAr.contains(keyword, true) ||
                        anime.genres.any { genre -> genre.contains(keyword, true) }
                    )
                }
            }.take(3)

            val finalSuggestions = if (matchedAnime.isNotEmpty()) matchedAnime else repository.sampleAnimeList.take(3)

            val aiResponseText = when {
                matchedAnime.isNotEmpty() -> "بناءً على طلبك \"$promptText\"، إليك أفضل أنميات AniFlux المقترحة لك:"
                else -> "إليك تشكيلة من أفضل وأعلى الأنميات تقييماً على شبكة AniFlux لهذا الموسم:"
            }

            _aiMessages.update {
                it + ChatMessage(
                    sender = "AI",
                    text = aiResponseText,
                    suggestedAnimeList = finalSuggestions
                )
            }
        }
    }
}
