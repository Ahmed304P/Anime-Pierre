package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Anime
import com.example.data.model.FilterState
import com.example.ui.components.AnimeCard
import com.example.ui.theme.*

@Composable
fun ExploreScreen(
    filteredAnimeList: List<Anime>,
    filterState: FilterState,
    onSearchQueryChange: (String) -> Unit,
    onGenreFilterChange: (String?) -> Unit,
    onStatusFilterChange: (String?) -> Unit,
    onTypeFilterChange: (String?) -> Unit,
    onResetFilters: () -> Unit,
    onOpenAnimeDetails: (Anime) -> Unit,
    onOpenMenu: () -> Unit = {},
    title: String = "استكشاف وتصفية الأنمي 🔍",
    modifier: Modifier = Modifier
) {
    var showFilterPanel by remember { mutableStateOf(false) }

    val genresList = listOf("أكشن", "خيال", "مغامرات", "إيسيكاي", "غموض", "دراما", "شريحة من الحياة", "شونين", "كوميديا")
    val statusesList = listOf("مستمر", "مكتمل")
    val typesList = listOf("TV", "Movie", "OVA")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AniFluxBg)
    ) {
        // Search Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onOpenMenu) {
                    Icon(
                        imageVector = androidx.compose.material.icons.Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = Color.White
                    )
                }

                Text(
                    text = title,
                    color = AniFluxTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar Input
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = filterState.query,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("ابحث عن أنمي، تصنيف، أو اسم عربي/إنجليزي...", color = AniFluxTextSecondary, fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = AniFluxCyan)
                    },
                    trailingIcon = {
                        if (filterState.query.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = AniFluxTextSecondary)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AniFluxPrimary,
                        unfocusedBorderColor = AniFluxSurfaceVariant,
                        focusedContainerColor = AniFluxSurface,
                        unfocusedContainerColor = AniFluxSurface,
                        focusedTextColor = AniFluxTextPrimary,
                        unfocusedTextColor = AniFluxTextPrimary
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = { showFilterPanel = !showFilterPanel },
                    modifier = Modifier
                        .size(52.dp)
                        .background(
                            if (showFilterPanel || filterState.selectedGenre != null || filterState.selectedStatus != null || filterState.selectedType != null)
                                AniFluxPrimary else AniFluxSurface,
                            shape = RoundedCornerShape(16.dp)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Filter",
                        tint = Color.White
                    )
                }
            }
        }

        // Expandable Filter Panel
        AnimatedVisibility(visible = showFilterPanel) {
            Surface(
                color = AniFluxSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "خيارات التصفية Advanced Filters:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        TextButton(onClick = onResetFilters) {
                            Text("إعادة ضبط", color = AniFluxPrimary, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text("التصانيف (Genre):", color = AniFluxTextSecondary, fontSize = 11.sp)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        items(genresList) { genre ->
                            val isSelected = filterState.selectedGenre == genre
                            FilterChip(
                                selected = isSelected,
                                onClick = { onGenreFilterChange(genre) },
                                label = { Text(genre, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AniFluxPrimary,
                                    selectedLabelColor = Color.White,
                                    containerColor = AniFluxSurfaceVariant,
                                    labelColor = AniFluxTextSecondary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("حالة الأنمي:", color = AniFluxTextSecondary, fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                statusesList.forEach { st ->
                                    val isSelected = filterState.selectedStatus == st
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) AniFluxCyan else AniFluxSurfaceVariant,
                                        modifier = Modifier
                                            .padding(top = 4.dp)
                                            .clickable { onStatusFilterChange(if (isSelected) null else st) }
                                    ) {
                                        Text(st, color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                                    }
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("نوع العرض:", color = AniFluxTextSecondary, fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                typesList.forEach { tp ->
                                    val isSelected = filterState.selectedType == tp
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) AniFluxSecondary else AniFluxSurfaceVariant,
                                        modifier = Modifier
                                            .padding(top = 4.dp)
                                            .clickable { onTypeFilterChange(if (isSelected) null else tp) }
                                    ) {
                                        Text(tp, color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Horizontal Quick Genre Bar
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (filterState.selectedGenre == null) AniFluxPrimary else AniFluxSurface,
                    modifier = Modifier.clickable { onGenreFilterChange(null) }
                ) {
                    Text("الكل", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
            items(genresList) { genre ->
                val isSelected = filterState.selectedGenre == genre
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) AniFluxPrimary else AniFluxSurface,
                    modifier = Modifier.clickable { onGenreFilterChange(genre) }
                ) {
                    Text(genre, color = if (isSelected) Color.White else AniFluxTextSecondary, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
        }

        Text(
            text = "نتائج البحث (${filteredAnimeList.size}):",
            color = AniFluxTextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        // Grid Results
        if (filteredAnimeList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("لم يتم العثور على أنمي يطابق بحثك 🕵️‍♂️", color = AniFluxTextSecondary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = onResetFilters, colors = ButtonDefaults.buttonColors(containerColor = AniFluxPrimary)) {
                        Text("عرض جميع الأنميات")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)
            ) {
                items(filteredAnimeList.chunked(2)) { pair ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (anime in pair) {
                            AnimeCard(
                                anime = anime,
                                onClick = { onOpenAnimeDetails(anime) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
