package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AniFluxBg
import com.example.ui.theme.AniFluxPrimary
import com.example.ui.theme.AniFluxSurfaceVariant
import com.example.ui.theme.AniFluxTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AniFluxBg)
    ) {
        // Top App Bar
        TopAppBar(
            title = {
                Text(
                    text = "تعديل الملف الشخصي",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            },
            actions = {
                TextButton(onClick = { onBackClick() }) {
                    Text("حفظ", color = AniFluxPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = AniFluxBg,
                titleContentColor = Color.White
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // Banner & Avatar Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                // Banner Placeholder
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(Color.DarkGray)
                        .clickable { /* Pick Banner Image */ }
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Add Banner",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(40.dp)
                    )
                }

                // Avatar
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp)
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(Color.Gray)
                        .border(3.dp, AniFluxBg, CircleShape)
                        .clickable { /* Pick Avatar Image */ }
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Add Avatar",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Form Fields
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                // Full Name
                ProfileTextField(
                    label = "الاسم الكامل",
                    value = fullName,
                    onValueChange = { if (it.length <= 25) fullName = it },
                    placeholder = "",
                    helperText = "يمكنك تغيير الاسم مرة واحدة في الشهر",
                    charCount = "${fullName.length}/25"
                )

                // Username
                ProfileTextField(
                    label = "اسم المستخدم",
                    value = username,
                    onValueChange = { username = it },
                    placeholder = "@",
                )

                // Bio
                ProfileTextField(
                    label = "النبذة التعريفية",
                    value = bio,
                    onValueChange = { if (it.length <= 160) bio = it },
                    placeholder = "",
                    charCount = "${bio.length}/160"
                )

                // Location
                ProfileTextField(
                    label = "الموقع الجغرافي",
                    value = location,
                    onValueChange = { if (it.length <= 30) location = it },
                    placeholder = "",
                    charCount = "${location.length}/30"
                )

                // Birth Date
                ProfileTextField(
                    label = "تاريخ الميلاد",
                    value = birthDate,
                    onValueChange = { birthDate = it },
                    placeholder = "YYYY-MM-DD",
                    keyboardType = KeyboardType.Number
                )
                
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
fun ProfileTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    helperText: String? = null,
    charCount: String? = null,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    Column(modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth()) {
        Text(
            text = label,
            color = AniFluxTextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        
        TextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = AniFluxTextSecondary) },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.White,
                unfocusedIndicatorColor = AniFluxTextSecondary,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = AniFluxPrimary
            ),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        if (helperText != null || charCount != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (charCount != null) {
                    Text(
                        text = charCount,
                        color = AniFluxTextSecondary,
                        fontSize = 10.sp
                    )
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }
                
                if (helperText != null) {
                    Text(
                        text = helperText,
                        color = AniFluxTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
