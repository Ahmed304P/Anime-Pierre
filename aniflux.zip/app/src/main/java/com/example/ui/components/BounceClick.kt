package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed

// Kept the same name to avoid refactoring hundreds of files, but it's now just a regular clickable
fun Modifier.bounceClick(
    scaleDown: Float = 1f, // ignored
    onClick: () -> Unit
) = composed {
    val interactionSource = remember { MutableInteractionSource() }
    this.clickable(
        interactionSource = interactionSource,
        indication = androidx.compose.material3.ripple(),
        onClick = onClick
    )
}
