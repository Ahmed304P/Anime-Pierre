package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AniFluxBg = Color(0xFF101820)
val AniFluxSurface = Color(0xFF1A242F)
val AniFluxSurfaceVariant = Color(0xFF13283B)
val AniFluxCardBg = Color(0xFF16212B)

val AniFluxPrimary = Color(0xFF2D9CDB)
val AniFluxPrimaryVariant = Color(0xFF1E7FB8)
val AniFluxSecondary = Color(0xFFF2994A)
val AniFluxCyan = Color(0xFF56CCF2)

val AniFluxTextPrimary = Color(0xFFE1E8ED)
val AniFluxTextSecondary = Color(0xFF9BAEC0)
val AniFluxStar = Color(0xFFF2C94C)

val AniFluxGreen = Color(0xFF27AE60)
val AniFluxOrange = Color(0xFFF2994A)
