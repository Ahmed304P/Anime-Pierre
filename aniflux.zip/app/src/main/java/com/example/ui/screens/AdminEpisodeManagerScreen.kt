package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminEpisodeManagerScreen(
    animeId: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showEditDialog by remember { mutableStateOf(false) }
    var editingEpisodeId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    
    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("إدارة الحلقات المتكاملة", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1A1A1A)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { 
                    editingEpisodeId = null
                    showEditDialog = true 
                },
                containerColor = Color(0xFF2196F3),
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة حلقة")
            }
        },
        containerColor = Color(0xFF121212)
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(5) { index ->
                val epNum = index + 1
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { 
                        editingEpisodeId = epNum.toString()
                        showEditDialog = true 
                    },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("الحلقة $epNum", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("المدة: 24 دقيقة", color = Color.Gray, fontSize = 12.sp)
                        }
                        Row {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Color(0xFFFFD700))
                            Spacer(modifier = Modifier.width(16.dp))
                            Icon(
                                Icons.Default.Delete, 
                                contentDescription = "حذف", 
                                tint = Color.Red,
                                modifier = Modifier.clickable {
                                    scope.launch {
                                        delay(1000)
                                        snackbarHostState.showSnackbar("تم حذف الحلقة $epNum بنجاح")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
        
        if (showEditDialog) {
            AdminEpisodeEditDialog(
                isEdit = editingEpisodeId != null,
                onDismiss = { showEditDialog = false },
                onSave = { errorMsg ->
                    scope.launch {
                        if (errorMsg != null) {
                            snackbarHostState.showSnackbar(errorMsg)
                        } else {
                            delay(1500)
                            showEditDialog = false
                            snackbarHostState.showSnackbar("تم حفظ بيانات الحلقة في النظام")
                        }
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminEpisodeEditDialog(
    isEdit: Boolean,
    onDismiss: () -> Unit,
    onSave: (String?) -> Unit
) {
    var episodeNum by remember { mutableStateOf("") }
    var episodeTitle by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("24") }
    var videoUrl by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        title = { Text(if (isEdit) "تعديل بيانات الحلقة" else "إضافة حلقة جديدة", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = episodeNum,
                    onValueChange = { episodeNum = it },
                    label = { Text("رقم الحلقة *", color = Color.Gray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = episodeTitle,
                    onValueChange = { episodeTitle = it },
                    label = { Text("عنوان الحلقة (اختياري)", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = duration,
                    onValueChange = { duration = it },
                    label = { Text("مدة الحلقة (بالدقائق)", color = Color.Gray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = videoUrl,
                    onValueChange = { videoUrl = it },
                    label = { Text("رابط سيرفر المشاهدة *", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (episodeNum.isBlank() || videoUrl.isBlank()) {
                        onSave("الرجاء ملء الحقول الإجبارية (*)")
                    } else {
                        isLoading = true
                        onSave(null)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                } else {
                    Text("تأكيد وحفظ", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = Color.Gray)
            }
        }
    )
}
