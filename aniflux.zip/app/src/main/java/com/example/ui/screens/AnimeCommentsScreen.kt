package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import com.example.ui.components.bounceClick
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

data class AnimeComment(
    val id: Int,
    val username: String,
    val avatarUrl: String,
    val timeAgo: String,
    val text: String,
    val likes: Int,
    val dislikes: Int,
    val replies: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimeCommentsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var commentText by remember { mutableStateOf("") }
    
    val comments = listOf(
        AnimeComment(
            1, "Suspicious", "https://i.pravatar.cc/150?img=1", "قبل ساعتين",
            "انا بنت والصراحة وقت شفت الشخصيات حسيت اللي شعرها بنفسجي حلوة ففتحتها لقيتها ولد 🤣🤣💔\n\nيا عمي هاذا يشبه كل شي الا الرجال",
            0, 0, 0
        ),
        AnimeComment(
            2, "mohamad ali", "https://i.pravatar.cc/150?img=11", "قبل يوم",
            "امممم",
            0, 0, 0
        ),
        AnimeComment(
            3, "طالعه من الباك وبدي انمي يرجع لي الشغف", "https://i.pravatar.cc/150?img=5", "قبل يوم",
            "اقترحوا علي🤗",
            4, 0, 7
        ),
        AnimeComment(
            4, "mini✨🌸", "https://i.pravatar.cc/150?img=0", "قبل يوم",
            "هل الأنمي مثلي لسة ما شاهدته",
            1, 1, 0
        ),
        AnimeComment(
            5, "#-Yuki", "https://i.pravatar.cc/150?img=33", "قبل يوم",
            "أبو شعر بنفسجي و ابو شعر ابيض و ابو شعر أحمر لو كانو بنات أفضل\nشكلهم و هم أولاد جدا سيء",
            0, 0, 0
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = "التعليقات",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {}) { 
                        Icon(Icons.Default.Sort, contentDescription = "Sort") 
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.background,
                modifier = Modifier.fillMaxWidth(),
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Flame icon on the left (as in screenshot)
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Hot",
                        tint = Color.Gray,
                        modifier = Modifier.size(28.dp)
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    // Input field
                    Surface(
                        modifier = Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 16.dp, end = 4.dp)
                        ) {
                            TextField(
                                value = commentText,
                                onValueChange = { commentText = it },
                                placeholder = { Text("اضافة تعليق", color = Color.Gray, fontSize = 14.sp) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    disabledContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    cursorColor = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier.weight(1f),
                                textStyle = LocalTextStyle.current.copy(color = Color.White)
                            )
                            
                            IconButton(onClick = { if(commentText.isNotBlank()) commentText = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Send",
                                    tint = if (commentText.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                                )
                            }
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(items = comments, key = { it.id }) { comment ->
                CommentItem(comment)
                HorizontalDivider(color = Color.White.copy(alpha = 0.1f), thickness = 1.dp)
            }
        }
    }
}

@Composable
fun CommentItem(comment: AnimeComment) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            // Avatar
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(comment.avatarUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Avatar",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            // Content
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = comment.username,
                        color = Color.LightGray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = comment.timeAgo,
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = comment.text,
                    color = Color.White,
                    fontSize = 15.sp,
                    lineHeight = 22.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Actions Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Like
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.bounceClick { }) {
                            Icon(Icons.Default.ThumbUp, contentDescription = "Like", tint = Color.Gray, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${comment.likes}", color = Color.Gray, fontSize = 14.sp)
                        }
                        
                        // Dislike
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.bounceClick { }) {
                            Icon(Icons.Default.ThumbDown, contentDescription = "Dislike", tint = Color.Gray, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${comment.dislikes}", color = Color.Gray, fontSize = 14.sp)
                        }
                        
                        // Reply
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.bounceClick { }) {
                            Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Reply", tint = Color.Gray, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${comment.replies}", color = Color.Gray, fontSize = 14.sp)
                        }
                    }
                    
                    // More options
                    IconButton(
                        onClick = { },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.Gray)
                    }
                }
            }
        }
    }
}
