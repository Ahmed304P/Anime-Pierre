package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

// Exact Anime Slayer Drawer Colors
private val DrawerBgColor = Color(0xFF101820)
private val DrawerSelectedItemBg = Color(0xFF13283B)
private val DrawerSelectedBlue = Color(0xFF2D9CDB)
private val DrawerUnselectedText = Color(0xFFE1E8ED)
private val DrawerIconColor = Color(0xFF9BAEC0)
private val DrawerDividerColor = Color(0xFF1B2734)

@Composable
fun AnimeSlayerDrawerContent(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxHeight()
            .width(300.dp),
        color = DrawerBgColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            // Header Profile & Notification Row (Exact Match to Screenshot)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                // Top Left Profile Avatar & Name (\shiro/)
                Column(
                    modifier = Modifier.clickable {
                        onSelectTab(15)
                        onCloseDrawer()
                    }
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF3B1A24))
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data("https://images.unsplash.com/photo-1534447677768-be436bb09401?w=200&auto=format&fit=crop&q=80")
                                .crossfade(true)
                                .build(),
                            contentDescription = "User Avatar",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "¯\\shiro/¯",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Top Right Bell Notification Icon
                IconButton(
                    onClick = { /* Handle Notifications */ },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsNone,
                        contentDescription = "Notifications",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // SECTION 1
            DrawerMenuItem(
                icon = Icons.Default.LocalFireDepartment,
                title = "اخر التحديثات",
                isSelected = selectedTab == 0,
                onClick = {
                    onSelectTab(0)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.FormatListBulleted,
                title = "لائحة الانمي",
                isSelected = selectedTab == 1,
                onClick = {
                    onSelectTab(1)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.CalendarToday,
                title = "المواسم",
                isSelected = selectedTab == 5,
                onClick = {
                    onSelectTab(5)
                    onCloseDrawer()
                }
            )

            DrawerSectionDivider()

            // SECTION 2
            DrawerMenuItem(
                icon = Icons.Default.BarChart,
                title = "التقييم العالمي",
                isSelected = selectedTab == 6,
                onClick = {
                    onSelectTab(6)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.BarChart,
                title = "التقييم العربي",
                isSelected = selectedTab == 7,
                onClick = {
                    onSelectTab(7)
                    onCloseDrawer()
                }
            )

            DrawerSectionDivider()

            // SECTION 3
            DrawerMenuItem(
                icon = Icons.Default.BarChart,
                title = "قائمتي",
                isSelected = selectedTab == 3,
                onClick = {
                    onSelectTab(3)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.BarChart,
                title = "القائمة المخصصة",
                isSelected = selectedTab == 8,
                onClick = {
                    onSelectTab(8)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.Favorite,
                title = "أنمياتي المفضلة",
                isSelected = selectedTab == 9,
                onClick = {
                    onSelectTab(9)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.Favorite,
                title = "شخصياتي المفضلة",
                isSelected = selectedTab == 10,
                onClick = {
                    onSelectTab(10)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.Schedule,
                title = "اخر المشاهدات",
                isSelected = selectedTab == 11,
                onClick = {
                    onSelectTab(11)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.FileDownload,
                title = "تحميلاتي",
                isSelected = selectedTab == 12,
                onClick = {
                    onSelectTab(12)
                    onCloseDrawer()
                }
            )

            DrawerSectionDivider()

            // SECTION 4
            DrawerMenuItem(
                icon = Icons.Default.BarChart,
                title = "الشخصيات الأكثر شعبية",
                isSelected = selectedTab == 13,
                onClick = {
                    onSelectTab(13)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.Extension,
                title = "التوصيات",
                isSelected = selectedTab == 4,
                onClick = {
                    onSelectTab(4)
                    onCloseDrawer()
                }
            )

            DrawerMenuItem(
                icon = Icons.Default.CalendarToday,
                title = "مواعيد نزول الحلقات",
                isSelected = selectedTab == 2,
                onClick = {
                    onSelectTab(2)
                    onCloseDrawer()
                }
            )

            DrawerSectionDivider()

            // SECTION 5
            DrawerMenuItem(
                icon = Icons.Default.Settings,
                title = "الاعدادات",
                isSelected = selectedTab == 14,
                onClick = {
                    onSelectTab(14)
                    onCloseDrawer()
                }
            )
        }
    }
}

@Composable
private fun DrawerSectionDivider() {
    Divider(
        color = DrawerDividerColor,
        thickness = 1.dp,
        modifier = Modifier.padding(vertical = 6.dp)
    )
}

@Composable
fun DrawerMenuItem(
    icon: ImageVector,
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) DrawerSelectedItemBg else Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Side: Icon
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) DrawerSelectedBlue else DrawerIconColor,
                modifier = Modifier.size(22.dp)
            )

            // Right Side: Arabic Text Title
            Text(
                text = title,
                color = if (isSelected) DrawerSelectedBlue else DrawerUnselectedText,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
