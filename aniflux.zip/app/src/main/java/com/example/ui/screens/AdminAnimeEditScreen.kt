package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAnimeEditScreen(
    animeId: String?,
    onBack: () -> Unit,
    onManageEpisodes: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // 1-to-1 Mirror Fields
    var titleAr by remember { mutableStateOf("") }
    var titleEn by remember { mutableStateOf("") }
    var posterUrl by remember { mutableStateOf("") }
    var bannerUrl by remember { mutableStateOf("") }
    var synopsisAr by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("مستمر") }
    var type by remember { mutableStateOf("TV") }
    var year by remember { mutableStateOf("") }
    var studio by remember { mutableStateOf("") }
    var genres by remember { mutableStateOf("") }
    var rating by remember { mutableStateOf("") }
    var ageRating by remember { mutableStateOf("+13") }
    var season by remember { mutableStateOf("ربيع") }
    
    var isCommentsLocked by remember { mutableStateOf(false) }
    
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    
    val isEditMode = animeId != null

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(if (isEditMode) "تعديل الأنمي الشامل" else "إضافة أنمي متكامل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                    }
                },
                actions = {
                    if (isEditMode) {
                        IconButton(
                            onClick = {
                                scope.launch {
                                    isLoading = true
                                    delay(1500)
                                    isLoading = false
                                    snackbarHostState.showSnackbar("تم الحذف بنجاح")
                                    onBack()
                                }
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1A1A1A))
            )
        },
        containerColor = Color(0xFF121212)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("البيانات الأساسية", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            AdminTextField("اسم الأنمي (عربي) *", titleAr) { titleAr = it }
            AdminTextField("اسم الأنمي (إنجليزي) *", titleEn) { titleEn = it }
            AdminTextField("سنة الإصدار", year, keyboardType = KeyboardType.Number) { year = it }
            AdminTextField("الاستوديو المنتج", studio) { studio = it }
            
            Text("التصنيفات والتقييم", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            AdminTextField("التصنيفات (مفصولة بفاصلة)", genres) { genres = it }
            AdminTextField("تقييم الأنمي (من 10)", rating, keyboardType = KeyboardType.Decimal) { rating = it }
            
            AdminDropdown("حالة الأنمي", listOf("مستمر", "مكتمل", "قريباً"), status) { status = it }
            AdminDropdown("نوع الإصدار", listOf("TV", "Movie", "OVA", "ONA"), type) { type = it }
            AdminDropdown("التصنيف العمري", listOf("للجميع", "+13", "+17", "+18"), ageRating) { ageRating = it }
            AdminDropdown("موسم العرض", listOf("ربيع", "صيف", "خريف", "شتاء"), season) { season = it }

            Text("الوسائط المتعددة والقصة", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            AdminTextField("رابط صورة الغلاف (Poster) *", posterUrl) { posterUrl = it }
            AdminTextField("رابط صورة الخلفية (Banner)", bannerUrl) { bannerUrl = it }
            
            OutlinedTextField(
                value = synopsisAr,
                onValueChange = { synopsisAr = it },
                label = { Text("قصة الأنمي (Synopsis)", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFFFD700),
                    unfocusedBorderColor = Color.DarkGray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color(0xFFFFD700)
                ),
                modifier = Modifier.fillMaxWidth().height(120.dp),
                shape = RoundedCornerShape(12.dp),
                maxLines = 5
            )
            
            // Comment Lock Switch
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("إغلاق التعليقات لهذا الأنمي", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("سيتم منع المستخدمين من التعليق", color = Color.Gray, fontSize = 12.sp)
                    }
                    Switch(
                        checked = isCommentsLocked,
                        onCheckedChange = { isCommentsLocked = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color.Red)
                    )
                }
            }
            
            if (isEditMode) {
                Button(
                    onClick = { onManageEpisodes(animeId!!) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Text("إدارة حلقات الأنمي", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = {
                    // Form Validation Logic
                    if (titleAr.isBlank() || titleEn.isBlank() || posterUrl.isBlank()) {
                        scope.launch { snackbarHostState.showSnackbar("الرجاء ملء الحقول الإجبارية (*)") }
                        return@Button
                    }
                    
                    scope.launch {
                        isLoading = true
                        delay(2000) // Mock Firebase Add/Update
                        isLoading = false
                        snackbarHostState.showSnackbar(if (isEditMode) "تم تحديث الأنمي بنجاح" else "تمت إضافة الأنمي بنجاح")
                        delay(500)
                        onBack()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text("حفظ التغييرات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AdminTextField(
    label: String, 
    value: String, 
    keyboardType: KeyboardType = KeyboardType.Text,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = Color.Gray) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFFFD700),
            unfocusedBorderColor = Color.DarkGray,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = Color(0xFFFFD700)
        ),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        singleLine = true
    )
}

@Composable
fun AdminDropdown(label: String, options: List<String>, selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, color = Color.Gray) },
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, "") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFFFFD700),
                unfocusedBorderColor = Color.DarkGray,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )
        // Invisible box to catch clicks over the entire TextField
        Box(modifier = Modifier.matchParentSize().clickable { expanded = true })
        
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color(0xFF1E1E1E)).fillMaxWidth(0.9f)
        ) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = { Text(opt, color = Color.White) },
                    onClick = {
                        onSelected(opt)
                        expanded = false
                    }
                )
            }
        }
    }
}
