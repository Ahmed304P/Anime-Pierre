package com.example.ui.screens

import androidx.compose.foundation.background
import com.example.data.model.Anime
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.network.AniListApi
import com.example.data.network.AniListSearchResult
import com.example.data.network.AniListCharacter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAnimeEditScreen(
    animeId: String?,
    onBack: () -> Unit,
    onManageEpisodes: (String) -> Unit,
    onSaveAnime: (Anime) -> Unit = {},
    modifier: Modifier = Modifier
) {
    // Search State
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<AniListSearchResult>>(emptyList()) }
    var isSearching by remember { mutableStateOf(false) }
    var isFetchingDetails by remember { mutableStateOf(false) }

    LaunchedEffect(searchQuery) {
        if (searchQuery.length >= 2) {
            isSearching = true
            delay(800) // Debounce
            try {
                searchResults = AniListApi.searchAnime(searchQuery)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            isSearching = false
        } else {
            searchResults = emptyList()
        }
    }

    // 1-to-1 Mirror Fields
    var titleAr by remember { mutableStateOf("") }
    var titleEn by remember { mutableStateOf("") }
    var posterUrl by remember { mutableStateOf("") }
    var bannerUrl by remember { mutableStateOf("") }
    var synopsisAr by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("مستمر") }
    var type by remember { mutableStateOf("TV") }
    var year by remember { mutableStateOf("") }
    var studio by remember { mutableStateOf("") }
    var genres by remember { mutableStateOf("") }
    var rating by remember { mutableStateOf("") }
    var ageRating by remember { mutableStateOf("+13") }
    var season by remember { mutableStateOf("ربيع") }
    var isCommentsLocked by remember { mutableStateOf(false) }
    
    var charactersList by remember { mutableStateOf<List<AniListCharacter>>(emptyList()) }
    
    var isLoading by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    
    val isEditMode = animeId != null

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(if (isEditMode) "تعديل الأنمي" else "إضافة أنمي جديد", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                    }
                },
                actions = {
                    if (isEditMode) {
                        IconButton(
                            onClick = {
                                scope.launch {
                                    isLoading = true
                                    delay(1500)
                                    isLoading = false
                                    snackbarHostState.showSnackbar("تم الحذف بنجاح")
                                    onBack()
                                }
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1A1A1A))
            )
        },
        containerColor = Color(0xFF121212)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // --- 1. SEARCH BAR AT THE VERY TOP ---
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("جلب البيانات التلقائي (AniList)", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("ابحث عن اسم الأنمي هنا...", color = Color.Gray) },
                        trailingIcon = {
                            if (isSearching) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color(0xFFFFD700), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Search, contentDescription = "بحث", tint = Color.Gray)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFD700),
                            unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    
                    // --- SEARCH RESULTS INLINE ---
                    if (isFetchingDetails) {
                        Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color(0xFFFFD700))
                        }
                    } else if (searchResults.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            searchResults.take(10).forEach { result ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            scope.launch {
                                                isFetchingDetails = true
                                                val details = AniListApi.getAnimeDetails(result.id)
                                                isFetchingDetails = false
                                                if (details != null) {
                                                    titleEn = details.titleEn
                                                    titleAr = details.titleAr
                                                    posterUrl = details.coverImage
                                                    bannerUrl = details.bannerImage
                                                    synopsisAr = details.description
                                                    status = details.status
                                                    type = details.format
                                                    season = details.season
                                                    year = details.year
                                                    studio = details.studio
                                                    genres = details.genres
                                                    rating = details.averageScore
                                                    charactersList = details.characters
                                                    
                                                    // Hide results after selection
                                                    searchResults = emptyList()
                                                    searchQuery = ""
                                                    
                                                    snackbarHostState.showSnackbar("تم ملء جميع البيانات بنجاح!")
                                                } else {
                                                    snackbarHostState.showSnackbar("فشل في جلب التفاصيل")
                                                }
                                            }
                                        },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C2C2C)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        AsyncImage(
                                            model = result.imageUrl,
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .width(50.dp)
                                                .height(70.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color.DarkGray)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = result.title,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            maxLines = 2
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 8.dp))

            // --- 2. MANUAL FORM UI (ALWAYS VISIBLE BELOW SEARCH) ---
            Text("البيانات الأساسية", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            AdminTextField("اسم الأنمي (عربي) *", titleAr) { titleAr = it }
            AdminTextField("اسم الأنمي (إنجليزي) *", titleEn) { titleEn = it }
            AdminTextField("سنة الإصدار", year, keyboardType = KeyboardType.Number) { year = it }
            AdminTextField("الاستوديو المنتج", studio) { studio = it }
            
            Text("التصنيفات والتقييم", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            AdminTextField("التصنيفات (مفصولة بفاصلة)", genres) { genres = it }
            AdminTextField("تقييم الأنمي (من 10)", rating, keyboardType = KeyboardType.Decimal) { rating = it }
            
            AdminDropdown("حالة الأنمي", listOf("مستمر", "مكتمل", "قريباً"), status) { status = it }
            AdminDropdown("نوع الإصدار", listOf("TV", "MOVIE", "OVA", "ONA"), type) { type = it }
            AdminDropdown("التصنيف العمري", listOf("للجميع", "+13", "+17", "+18"), ageRating) { ageRating = it }
            AdminDropdown("موسم العرض", listOf("ربيع", "صيف", "خريف", "شتاء"), season) { season = it }

            Text("الوسائط المتعددة والقصة", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            AdminTextField("رابط صورة الغلاف (Poster) *", posterUrl) { posterUrl = it }
            AdminTextField("رابط صورة الخلفية (Banner)", bannerUrl) { bannerUrl = it }
            
            OutlinedTextField(
                value = synopsisAr,
                onValueChange = { synopsisAr = it },
                label = { Text("قصة الأنمي (Synopsis)", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFFFD700),
                    unfocusedBorderColor = Color.DarkGray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color(0xFFFFD700)
                ),
                modifier = Modifier.fillMaxWidth().height(180.dp),
                shape = RoundedCornerShape(12.dp),
                maxLines = 8
            )
            
            // --- 3. CHARACTERS AND STAFF SECTION (MIRRORED) ---
            if (charactersList.isNotEmpty()) {
                Text("الشخصيات والطاقم (${charactersList.size})", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(charactersList) { char ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(80.dp)
                        ) {
                            AsyncImage(
                                model = char.imageUrl,
                                contentDescription = char.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color.DarkGray)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = char.name,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = char.role,
                                color = Color.Gray,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
            
            // --- 4. COMMENT LOCK ---
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("إغلاق التعليقات لهذا الأنمي", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("سيتم منع المستخدمين من التعليق", color = Color.Gray, fontSize = 12.sp)
                    }
                    Switch(
                        checked = isCommentsLocked,
                        onCheckedChange = { isCommentsLocked = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color.Red)
                    )
                }
            }
            
            Button(
                onClick = { 
                    val currentId = animeId ?: java.util.UUID.randomUUID().toString()
                    val newAnime = Anime(
                        id = currentId,
                        titleAr = titleAr.ifBlank { "أنمي جديد" },
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsisAr = synopsisAr,
                        status = status,
                        type = type,
                        year = year.toIntOrNull() ?: 2026,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24,
                        releaseDay = "الأحد"
                    )
                    onSaveAnime(newAnime)
                    onManageEpisodes(currentId) 
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3)),
                shape = RoundedCornerShape(12.dp),
                enabled = true,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(
                    "إدارة الحلقات واستخراج السيرفرات", 
                    color = Color.White, 
                    fontSize = 16.sp, 
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = {
                    if (titleAr.isBlank() || titleEn.isBlank() || posterUrl.isBlank()) {
                        scope.launch { snackbarHostState.showSnackbar("الرجاء ملء الحقول الإجبارية (*)") }
                        return@Button
                    }
                    
                    val newAnime = Anime(
                        id = animeId ?: java.util.UUID.randomUUID().toString(),
                        titleAr = titleAr,
                        titleEn = titleEn,
                        posterUrl = posterUrl,
                        bannerUrl = bannerUrl,
                        synopsisAr = synopsisAr,
                        status = status,
                        type = type,
                        year = year.toIntOrNull() ?: 2026,
                        studio = studio,
                        genres = genres.split("،").map { it.trim() }.filter { it.isNotEmpty() },
                        rating = rating.toDoubleOrNull() ?: 0.0,
                        ageRating = ageRating,
                        season = season,
                        isCommentsLocked = isCommentsLocked,
                        currentEpisodes = 0,
                        totalEpisodes = 24,
                        releaseDay = "الأحد"
                    )
                    
                    scope.launch {
                        isLoading = true
                        delay(1000)
                        onSaveAnime(newAnime)
                        isLoading = false
                        snackbarHostState.showSnackbar(if (isEditMode) "تم تحديث الأنمي بنجاح" else "تمت إضافة الأنمي بقاعدة البيانات بنجاح")
                        delay(500)
                        // If it's a new anime, maybe don't go back immediately if they want to add episodes?
                        // But going back to manager is standard.
                        onBack()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text("حفظ في قاعدة البيانات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AdminTextField(
    label: String, 
    value: String, 
    keyboardType: KeyboardType = KeyboardType.Text,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = Color.Gray) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFFFD700),
            unfocusedBorderColor = Color.DarkGray,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = Color(0xFFFFD700)
        ),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        singleLine = true
    )
}

@Composable
fun AdminDropdown(label: String, options: List<String>, selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, color = Color.Gray) },
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, "") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFFFFD700),
                unfocusedBorderColor = Color.DarkGray,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )
        Box(modifier = Modifier.matchParentSize().clickable { expanded = true })
        
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color(0xFF1E1E1E)).fillMaxWidth(0.9f)
        ) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = { Text(opt, color = Color.White) },
                    onClick = {
                        onSelected(opt)
                        expanded = false
                    }
                )
            }
        }
    }
}
