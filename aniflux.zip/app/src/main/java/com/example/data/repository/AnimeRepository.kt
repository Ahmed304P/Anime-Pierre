package com.example.data.repository

import com.example.data.local.AniFluxDao
import com.example.data.local.LocalCommentEntity
import com.example.data.local.SavedAnimeEntity
import com.example.data.local.WatchHistoryEntity
import com.example.data.model.Anime
import com.example.data.model.CommentItem
import com.example.data.model.Episode
import com.example.data.model.StreamServer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AnimeRepository(private val dao: AniFluxDao) {

    // Sample Anime Catalog with realistic Arabic metadata
    val sampleAnimeList = listOf(
        Anime(
            id = "solo_leveling",
            titleAr = "سولو ليفلينج: رفع المستوى فردياً",
            titleEn = "Solo Leveling: Arise",
            posterUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop",
            rating = 9.4,
            totalEpisodes = 12,
            currentEpisodes = 12,
            status = "مستمر",
            type = "TV",
            year = 2024,
            studio = "A-1 Pictures",
            synopsisAr = "في عالم ظهرت فيه بوابات تحتوي على وحوش خطيرة، يحصل الصياد الضعيف سونغ جين وو على قدرة فريدة تتيح له رؤية واجهة نظام تسمح له بالارتقاء بمستواه ومضاعفة قوته بلا حدود ليصبح أعظم صياد في العالم.",
            genres = listOf("أكشن", "خيال", "مغامرات", "إيسيكاي", "قوة خارقة"),
            releaseDay = "الأحد",
            trendingRank = 1,
            isFeatured = true,
            featuredTag = "الأكثر مشاهدة هذا الموسم 🔥"
        ),
        Anime(
            id = "demon_slayer_s4",
            titleAr = "قاتل الشياطين: تدريب الهاشيرا",
            titleEn = "Demon Slayer: Hashira Training Arc",
            posterUrl = "https://images.unsplash.com/photo-1563089145-599997674d42?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=1200&auto=format&fit=crop",
            rating = 9.2,
            totalEpisodes = 8,
            currentEpisodes = 8,
            status = "مكتمل",
            type = "TV",
            year = 2024,
            studio = "ufotable",
            synopsisAr = "يتوجه تانجيرو وأصدقاؤه للخضوع لتدريب شاق ومدمر تحت إشراف أعضاء الهاشيرا، أقوى سيّافي فيلق قاتلي الشياطين، استعداداً للمعركة النهائية القادمة ضد موزان كيبوتسوجي.",
            genres = listOf("أكشن", "شياطين", "خيال تاريخي", "شونين"),
            releaseDay = "الإثنين",
            trendingRank = 2,
            isFeatured = true,
            featuredTag = "أنمي فائق الجودة ⚡"
        ),
        Anime(
            id = "attack_on_titan_final",
            titleAr = "هجوم العمالقة: الفصل النهائي",
            titleEn = "Attack on Titan: The Final Season",
            posterUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop",
            rating = 9.6,
            totalEpisodes = 28,
            currentEpisodes = 28,
            status = "مكتمل",
            type = "TV",
            year = 2023,
            studio = "MAPPA",
            synopsisAr = "بعد اكتشاف الحقيقة الجغرافية والتاريخية وراء العمالقة والأسوار، يبدأ إيرين ييغر رحلة مصيرية ومثيرة للجدل لتغيير مصير شعب إيلديا والعالم بأكمله.",
            genres = listOf("أكشن", "غموض", "دراما", "عسكري", "خيال ملحمي"),
            releaseDay = "الأربعاء",
            trendingRank = 3,
            isFeatured = true,
            featuredTag = "أسطوري ⭐"
        ),
        Anime(
            id = "jujutsu_kaisen_s2",
            titleAr = "جوجوتسو كايسن: الموسم الثاني",
            titleEn = "Jujutsu Kaisen Season 2",
            posterUrl = "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=1200&auto=format&fit=crop",
            rating = 9.1,
            totalEpisodes = 23,
            currentEpisodes = 23,
            status = "مكتمل",
            type = "TV",
            year = 2023,
            studio = "MAPPA",
            synopsisAr = "يتناول الموسم أحداث الماضي الخفية بين ساتورو غوجو وسوغورو غيتو خلال سنوات دراستهما، يليه أرك شيبويا الكارثي والمواجهة المباشرة ضد اللعنات الأقوى.",
            genres = listOf("أكشن", "خوارق", "مدرسة", "شونين"),
            releaseDay = "الخميس",
            trendingRank = 4,
            isFeatured = false
        ),
        Anime(
            id = "frieren_journey",
            titleAr = "فريرين: ما بعد نهاية الرحلة",
            titleEn = "Frieren: Beyond Journey's End",
            posterUrl = "https://images.unsplash.com/photo-1514539079130-25950c84af65?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200&auto=format&fit=crop",
            rating = 9.5,
            totalEpisodes = 28,
            currentEpisodes = 28,
            status = "مكتمل",
            type = "TV",
            year = 2024,
            studio = "Madhouse",
            synopsisAr = "الساحرة الجنية فريرين، التي عاشت لآلاف السنين، تبدأ رحلة جديدة بعد وفاة صديقها البطل هيميل، لتفهم مشاعر البشر وقيمة الذكريات والعلاقات الإنسانية.",
            genres = listOf("خيال", "شريحة من الحياة", "مغامرات", "دراما"),
            releaseDay = "الجمعة",
            trendingRank = 5,
            isFeatured = true,
            featuredTag = "تحفة فنية 🌸"
        ),
        Anime(
            id = "kaiju_no8",
            titleAr = "كايجو رقم 8",
            titleEn = "Kaiju No. 8",
            posterUrl = "https://images.unsplash.com/photo-1563089145-599997674d42?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop",
            rating = 8.8,
            totalEpisodes = 12,
            currentEpisodes = 12,
            status = "مستمر",
            type = "TV",
            year = 2024,
            studio = "Production I.G",
            synopsisAr = "كافكا هيبينو البالغ من العمر 32 عاماً يعمل في فريق تنظيف جثث الكايجو، لكن حادثة غريبة تمنحه القدرة على التحول بنفسه إلى كايجو قوي ينضم لقوات الدفاع.",
            genres = listOf("أكشن", "خيال علمي", "عسكري", "كوميديا"),
            releaseDay = "السبت",
            trendingRank = 6,
            isFeatured = false
        ),
        Anime(
            id = "one_piece_egghead",
            titleAr = "ون بيس: آرك إيغ هيد",
            titleEn = "One Piece: Egghead Arc",
            posterUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=1200&auto=format&fit=crop",
            rating = 9.3,
            totalEpisodes = 1110,
            currentEpisodes = 1110,
            status = "مستمر",
            type = "TV",
            year = 1999,
            studio = "Toei Animation",
            synopsisAr = "يصل طاقم قبعة القش إلى جزيرة المستقبل إيغ هيد ويلتقون بالعالم العبقري فيغابانك، لتبدأ مرحلة ملحمية تكشف أسرار الفراغ الزمني وحكومة العالم.",
            genres = listOf("مغامرات", "أكشن", "كوميديا", "شونين", "خيال"),
            releaseDay = "الأحد",
            trendingRank = 7,
            isFeatured = false
        ),
        Anime(
            id = "bleach_tybw",
            titleAr = "بليتش: حرب الدم الألفية",
            titleEn = "Bleach: Thousand-Year Blood War",
            posterUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600&auto=format&fit=crop",
            bannerUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop",
            rating = 9.0,
            totalEpisodes = 26,
            currentEpisodes = 26,
            status = "مستمر",
            type = "TV",
            year = 2024,
            studio = "Studio Pierrot",
            synopsisAr = "يعود ملك الكوينشي يوهاباخ بعد ألف عام لشن حرب شاملة ومدمجة ضد مجتمع الأرواح، ليجبر إيتشيغو كوروساكي وقادة الفرق على الخروج بأقصى طاقاتهم.",
            genres = listOf("أكشن", "خوارق", "شونين", "سيوف"),
            releaseDay = "الثلاثاء",
            trendingRank = 8,
            isFeatured = false
        )
    )

    fun getEpisodesForAnime(animeId: String, totalEpisodes: Int): List<Episode> {
        val anime = sampleAnimeList.find { it.id == animeId }
        val displayCount = if (totalEpisodes > 24) 24 else totalEpisodes
        return (1..displayCount).map { epNum ->
            Episode(
                id = "${animeId}_ep_$epNum",
                animeId = animeId,
                episodeNumber = epNum,
                titleAr = "الحلقة $epNum : ${anime?.titleAr ?: "أنمي"} ",
                durationMinutes = 24,
                thumbnailUrl = anime?.bannerUrl ?: "",
                releaseDate = "2024-08-0${(epNum % 9) + 1}",
                servers = listOf(
                    StreamServer("s1", "سيرفر AniFlux FHD (سريع)", "1080p", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
                    StreamServer("s2", "سيرفر Cloud HD", "720p", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
                    StreamServer("s3", "سيرفر VIP (تلقائي)", "1080p", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"),
                    StreamServer("s4", "سيرفر اقتصاد 480p", "480p", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4")
                )
            )
        }
    }

    // Default sample comments for episodes
    fun getInitialComments(animeId: String, epNum: Int): List<CommentItem> {
        return listOf(
            CommentItem("c1", "أحمد الأسطورة", "", "حلقة حماسية جداً! الإخراج والتحريك في هذه الحلقة من عالم آخر 🔥🔥", "منذ ساعتين", 24, false),
            CommentItem("c2", "سارة أنمي", "", "أفضل حلقة في الموسم بدون منازع، الأحداث بدأت تشتعل بشكل رهيب!", "منذ 4 ساعات", 18, true),
            CommentItem("c3", "عمر_اوتاكو", "", "سيرفر AniFlux FHD شغال بسلاسة وبدون أي تقطيع، شكراً للقائمين على التطبيق ❤️", "منذ 6 ساعات", 31, false),
            CommentItem("c4", "OtakuKing", "", "منتظر الحلقة القادمة بفارغ الصبر، النهاية كانت غير متوقعة إطلاقاً!", "منذ يوم واحد", 9, false)
        )
    }

    // Database Integration Methods
    fun getAllSavedAnime(): Flow<List<SavedAnimeEntity>> = dao.getAllSavedAnime()

    fun getSavedAnimeById(animeId: String): Flow<SavedAnimeEntity?> = dao.getSavedAnimeById(animeId)

    suspend fun setAnimeSavedStatus(animeId: String, status: String) {
        dao.saveAnime(SavedAnimeEntity(animeId = animeId, status = status))
    }

    suspend fun removeSavedAnime(animeId: String) {
        dao.removeSavedAnime(animeId)
    }

    fun getAllWatchHistory(): Flow<List<WatchHistoryEntity>> = dao.getAllWatchHistory()

    suspend fun recordWatchProgress(animeId: String, episodeNumber: Int, episodeTitle: String, progressSec: Int, totalSec: Int) {
        val historyId = "${animeId}_$episodeNumber"
        dao.saveWatchHistory(
            WatchHistoryEntity(
                historyId = historyId,
                animeId = animeId,
                episodeNumber = episodeNumber,
                episodeTitle = episodeTitle,
                progressSeconds = progressSec,
                totalSeconds = totalSec
            )
        )
    }

    fun getLocalComments(animeId: String, episodeNumber: Int): Flow<List<CommentItem>> {
        return dao.getCommentsForEpisode(animeId, episodeNumber).map { list ->
            list.map { entity ->
                CommentItem(
                    id = entity.id.toString(),
                    authorName = entity.authorName,
                    avatarUrl = "",
                    content = entity.content,
                    timeAgo = entity.timestamp,
                    likesCount = entity.likesCount,
                    isLikedByMe = entity.isLiked
                )
            }
        }
    }

    suspend fun addComment(animeId: String, episodeNumber: Int, author: String, content: String) {
        dao.insertComment(
            LocalCommentEntity(
                animeId = animeId,
                episodeNumber = episodeNumber,
                authorName = if (author.isBlank()) "متابع AniFlux" else author,
                content = content,
                timestamp = "الآن"
            )
        )
    }

    suspend fun likeComment(commentId: Long) {
        dao.likeComment(commentId)
    }
}
