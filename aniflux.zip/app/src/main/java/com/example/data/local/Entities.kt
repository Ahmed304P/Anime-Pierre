package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_anime")
data class SavedAnimeEntity(
    @PrimaryKey val animeId: String,
    val status: String, // "FAVORITE", "WATCHING", "PLAN_TO_WATCH", "COMPLETED"
    val addedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val historyId: String, // animeId + "_" + episodeNumber
    val animeId: String,
    val episodeNumber: Int,
    val episodeTitle: String,
    val progressSeconds: Int,
    val totalSeconds: Int,
    val lastWatchedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "local_comments")
data class LocalCommentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val animeId: String,
    val episodeNumber: Int,
    val authorName: String,
    val content: String,
    val timestamp: String,
    val likesCount: Int = 0,
    val isLiked: Boolean = false
)
