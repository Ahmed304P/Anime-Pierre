package com.example.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

data class AniListSearchResult(
    val id: Int,
    val title: String,
    val imageUrl: String
)

data class AniListAnimeDetails(
    val titleEn: String,
    val titleAr: String,
    val coverImage: String,
    val bannerImage: String,
    val description: String,
    val status: String,
    val format: String,
    val season: String,
    val year: String,
    val studio: String,
    val genres: String,
    val averageScore: String,
    val characters: List<AniListCharacter>
)

data class AniListCharacter(
    val role: String,
    val name: String,
    val imageUrl: String
)

object AniListApi {
    private val client = OkHttpClient()
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    private const val URL = "https://graphql.anilist.co"

    suspend fun searchAnime(query: String): List<AniListSearchResult> = withContext(Dispatchers.IO) {
        val graphqlQuery = """
            query (${'$'}search: String) {
              Page(page: 1, perPage: 15) {
                media(search: ${'$'}search, type: ANIME) {
                  id
                  title { romaji english native }
                  coverImage { large }
                }
              }
            }
        """.trimIndent()

        val variables = JSONObject().apply { put("search", query) }
        val bodyJson = JSONObject().apply {
            put("query", graphqlQuery)
            put("variables", variables)
        }

        val request = Request.Builder()
            .url(URL)
            .post(bodyJson.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val results = mutableListOf<AniListSearchResult>()
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: return@use
                    val json = JSONObject(responseBody)
                    val mediaArray = json.getJSONObject("data")
                        .getJSONObject("Page")
                        .getJSONArray("media")
                    
                    for (i in 0 until mediaArray.length()) {
                        val media = mediaArray.getJSONObject(i)
                        val id = media.getInt("id")
                        val titleObj = media.getJSONObject("title")
                        val title = titleObj.optString("english").takeIf { it.isNotEmpty() }
                            ?: titleObj.optString("romaji")
                        val imageUrl = media.getJSONObject("coverImage").optString("large")
                        results.add(AniListSearchResult(id, title, imageUrl))
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext results
    }

    private val genreTranslations = mapOf(
        "Action" to "أكشن",
        "Adventure" to "مغامرات",
        "Comedy" to "كوميديا",
        "Drama" to "دراما",
        "Ecchi" to "إيتشي",
        "Fantasy" to "خيال",
        "Horror" to "رعب",
        "Mahou Shoujo" to "سحر",
        "Mecha" to "ميكا",
        "Music" to "موسيقى",
        "Mystery" to "غموض",
        "Psychological" to "نفسي",
        "Romance" to "رومانسي",
        "Sci-Fi" to "خيال علمي",
        "Slice of Life" to "شريحة من الحياة",
        "Sports" to "رياضة",
        "Supernatural" to "خارق للطبيعة",
        "Thriller" to "إثارة"
    )

    private suspend fun translateTextToArabic(text: String): String = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext ""
        try {
            val encodedText = java.net.URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=$encodedText"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: return@withContext text
                    val jsonArray = org.json.JSONArray(responseBody)
                    val sentences = jsonArray.getJSONArray(0)
                    val translatedText = java.lang.StringBuilder()
                    for (i in 0 until sentences.length()) {
                        val sentenceArray = sentences.getJSONArray(i)
                        translatedText.append(sentenceArray.getString(0))
                    }
                    return@withContext translatedText.toString()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext text
    }

    suspend fun getAnimeDetails(id: Int): AniListAnimeDetails? = withContext(Dispatchers.IO) {
        val graphqlQuery = """
            query (${'$'}id: Int) {
              Media(id: ${'$'}id, type: ANIME) {
                title { romaji english native }
                coverImage { extraLarge large }
                bannerImage
                description(asHtml: false)
                status
                format
                season
                seasonYear
                studios(isMain: true) { nodes { name } }
                genres
                averageScore
                characters(sort: ROLE, perPage: 10) {
                  edges {
                    role
                    node { name { full } image { large } }
                  }
                }
              }
            }
        """.trimIndent()

        val variables = JSONObject().apply { put("id", id) }
        val bodyJson = JSONObject().apply {
            put("query", graphqlQuery)
            put("variables", variables)
        }

        val request = Request.Builder()
            .url(URL)
            .post(bodyJson.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: return@use null
                    val json = JSONObject(responseBody)
                    val media = json.getJSONObject("data").getJSONObject("Media")

                    val titleObj = media.getJSONObject("title")
                    val titleEn = titleObj.optString("english").takeIf { it.isNotEmpty() } ?: titleObj.optString("romaji")
                    
                    val coverImage = media.optJSONObject("coverImage")?.optString("extraLarge") 
                        ?: media.optJSONObject("coverImage")?.optString("large") ?: ""
                    
                    val bannerImage = media.optString("bannerImage", "")
                    var description = media.optString("description", "")
                    description = description.replace("<br>", "\n").replace("<i>", "").replace("</i>", "")
                    
                    // Translate description to Arabic
                    val translatedDescription = translateTextToArabic(description)
                    
                    // Optionally translate the title too if it's English/Romaji
                    val translatedTitle = translateTextToArabic(titleEn)
                    
                    val rawStatus = media.optString("status", "")
                    val mappedStatus = when (rawStatus) {
                        "RELEASING" -> "مستمر"
                        "FINISHED" -> "مكتمل"
                        "NOT_YET_RELEASED" -> "قريباً"
                        else -> "مستمر"
                    }

                    val rawFormat = media.optString("format", "TV")
                    val mappedFormat = if (rawFormat in listOf("TV", "MOVIE", "OVA", "ONA")) rawFormat else "TV"

                    val rawSeason = media.optString("season", "")
                    val mappedSeason = when (rawSeason) {
                        "WINTER" -> "شتاء"
                        "SPRING" -> "ربيع"
                        "SUMMER" -> "صيف"
                        "FALL" -> "خريف"
                        else -> "ربيع"
                    }

                    val year = media.optString("seasonYear", "")
                    
                    val studiosNodes = media.optJSONObject("studios")?.optJSONArray("nodes")
                    val studio = if (studiosNodes != null && studiosNodes.length() > 0) {
                        studiosNodes.getJSONObject(0).optString("name", "")
                    } else ""

                                        val genresArray = media.optJSONArray("genres")
                    val genresList = mutableListOf<String>()
                    if (genresArray != null) {
                        for (i in 0 until genresArray.length()) {
                            val englishGenre = genresArray.getString(i)
                            genresList.add(genreTranslations[englishGenre] ?: englishGenre)
                        }
                    }
                    val genresStr = genresList.joinToString("، ")

                    val score = media.optInt("averageScore", 0)
                    val mappedScore = if (score > 0) (score / 10.0).toString() else ""

                    val charactersList = mutableListOf<AniListCharacter>()
                    val charactersEdges = media.optJSONObject("characters")?.optJSONArray("edges")
                    if (charactersEdges != null) {
                        for (i in 0 until charactersEdges.length()) {
                            val edge = charactersEdges.getJSONObject(i)
                            val role = edge.optString("role", "")
                            val node = edge.optJSONObject("node")
                            val name = node?.optJSONObject("name")?.optString("full", "") ?: ""
                            val charImageUrl = node?.optJSONObject("image")?.optString("large", "") ?: ""
                            charactersList.add(AniListCharacter(role, name, charImageUrl))
                        }
                    }

                    return@withContext AniListAnimeDetails(
                        titleEn = titleEn,
                        titleAr = translatedTitle, // Requires manual translation by admin
                        coverImage = coverImage,
                        bannerImage = bannerImage,
                        description = translatedDescription,
                        status = mappedStatus,
                        format = mappedFormat,
                        season = mappedSeason,
                        year = year,
                        studio = studio,
                        genres = genresStr,
                        averageScore = mappedScore,
                        characters = charactersList
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext null
    }
}
