import os

files_to_update = [
    "app/src/main/java/com/example/ui/screens/HomeScreen.kt",
    "app/src/main/java/com/example/ui/screens/ExploreScreen.kt",
    "app/src/main/java/com/example/ui/screens/MyListScreen.kt",
    "app/src/main/java/com/example/ui/screens/RankingScreen.kt",
    "app/src/main/java/com/example/ui/screens/ScheduleScreen.kt",
    "app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt",
    "app/src/main/java/com/example/ui/screens/SeasonsScreen.kt"
]

for filepath in files_to_update:
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            content = f.read()
        
        # Replace simple `items(items = ` with `itemsIndexed(items = `
        content = content.replace("items(items = allAnime, key = { it.id }) { anime ->", "itemsIndexed(items = allAnime, key = { _, it -> it.id }) { index, anime ->")
        content = content.replace("items(filteredAnimeList, key = { it.id }) { anime ->", "itemsIndexed(items = filteredAnimeList, key = { _, it -> it.id }) { index, anime ->")
        content = content.replace("items(filteredList, key = { it.id }) { anime ->", "itemsIndexed(items = filteredList, key = { _, it -> it.id }) { index, anime ->")
        content = content.replace("items(items = animeList, key = { it.id }) { anime ->", "itemsIndexed(items = animeList, key = { _, it -> it.id }) { index, anime ->")
        content = content.replace("items(items = scheduledAnimeList, key = { it.id }) { anime ->", "itemsIndexed(items = scheduledAnimeList, key = { _, it -> it.id }) { index, anime ->")
        content = content.replace("items(items = searchResults, key = { it.id }) { anime ->", "itemsIndexed(items = searchResults, key = { _, it -> it.id }) { index, anime ->")

        # In LibraryScreen etc we might need to add itemsIndexed explicitly, but let's see.
        with open(filepath, "w") as f:
            f.write(content)
