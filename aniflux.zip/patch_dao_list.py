import re

with open("app/src/main/java/com/example/data/local/AniFluxDao.kt", "r") as f:
    content = f.read()

replacement = """    @Query("SELECT * FROM local_comments WHERE animeId = :animeId AND episodeNumber = :episodeNumber ORDER BY id DESC")
    fun getCommentsForEpisode(animeId: String, episodeNumber: Int): Flow<List<LocalCommentEntity>>
    
    // --- Custom Lists ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomList(list: CustomListEntity): Long

    @Query("SELECT * FROM custom_lists ORDER BY createdAt DESC")
    fun getAllCustomLists(): Flow<List<CustomListEntity>>

    @Query("DELETE FROM custom_lists WHERE id = :listId")
    suspend fun deleteCustomList(listId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomListItem(item: CustomListItemEntity)

    @Query("DELETE FROM custom_list_items WHERE listId = :listId AND animeId = :animeId")
    suspend fun deleteCustomListItem(listId: Long, animeId: String)

    @Query("DELETE FROM custom_list_items WHERE listId = :listId")
    suspend fun deleteCustomListItems(listId: Long)

    @Query("SELECT * FROM custom_list_items WHERE listId = :listId ORDER BY addedAt DESC")
    fun getCustomListItems(listId: Long): Flow<List<CustomListItemEntity>>
"""

content = content.replace("""    @Query("SELECT * FROM local_comments WHERE animeId = :animeId AND episodeNumber = :episodeNumber ORDER BY id DESC")
    fun getCommentsForEpisode(animeId: String, episodeNumber: Int): Flow<List<LocalCommentEntity>>""", replacement)

with open("app/src/main/java/com/example/data/local/AniFluxDao.kt", "w") as f:
    f.write(content)
