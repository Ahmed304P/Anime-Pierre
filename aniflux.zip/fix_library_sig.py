import re
with open("app/src/main/java/com/example/ui/screens/LibraryScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    "title: String = \"المكتبة والمفضلة \U0001f4da\",\n    modifier: Modifier = Modifier\n) {",
    "title: String = \"المكتبة والمفضلة \U0001f4da\",\n    isGridMode: Boolean = true,\n    modifier: Modifier = Modifier\n) {"
)
with open("app/src/main/java/com/example/ui/screens/LibraryScreen.kt", "w") as f:
    f.write(text)
