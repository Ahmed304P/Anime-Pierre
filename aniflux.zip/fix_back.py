import re

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "r") as f:
    content = f.read()

# Add import for BackHandler
if "import androidx.activity.compose.BackHandler" not in content:
    content = content.replace("import androidx.compose.runtime.*", "import androidx.compose.runtime.*\nimport androidx.activity.compose.BackHandler")

# Add BackHandler in AnimeCommentsScreen
target = """    val activeThreadId by viewModel.activeThreadCommentId.collectAsState()"""
replacement = """    val activeThreadId by viewModel.activeThreadCommentId.collectAsState()
    
    BackHandler(enabled = true) {
        if (activeThreadId != null) {
            viewModel.setActiveThread(null)
        } else {
            onBack()
        }
    }"""
content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/AnimeCommentsScreen.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/ui/screens/NotificationsScreen.kt", "r") as f:
    content_notif = f.read()

if "import androidx.activity.compose.BackHandler" not in content_notif:
    content_notif = content_notif.replace("import androidx.compose.runtime.*", "import androidx.compose.runtime.*\nimport androidx.activity.compose.BackHandler")

target_notif = """    val notifications by viewModel.notifications.collectAsState()"""
replacement_notif = """    val notifications by viewModel.notifications.collectAsState()
    
    BackHandler(enabled = true) {
        onBack()
    }"""
content_notif = content_notif.replace(target_notif, replacement_notif)

with open("app/src/main/java/com/example/ui/screens/NotificationsScreen.kt", "w") as f:
    f.write(content_notif)
