import re

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "r") as f:
    content = f.read()

new_methods = """
    fun getWatchedEpisodes(animeId: String): Flow<Set<Int>> {
        return dao.getWatchedEpisodesForAnime(animeId).map { list ->
            list.map { it.episodeNumber }.toSet()
        }
    }

    fun toggleEpisodeWatched(animeId: String, episodeNumber: Int, isWatched: Boolean) {
        viewModelScope.launch {
            val id = "${animeId}_${episodeNumber}"
            if (isWatched) {
                dao.insertWatchedEpisode(com.example.data.local.WatchedEpisodeEntity(id, animeId, episodeNumber))
            } else {
                dao.removeWatchedEpisode(id)
            }
        }
    }
"""

if "getWatchedEpisodes" not in content:
    content = content.replace("class AnimeViewModel(application: Application) : AndroidViewModel(application) {", "class AnimeViewModel(application: Application) : AndroidViewModel(application) {\n" + new_methods)
    content = "import kotlinx.coroutines.flow.map\n" + content

with open("app/src/main/java/com/example/ui/viewmodel/AnimeViewModel.kt", "w") as f:
    f.write(content)
