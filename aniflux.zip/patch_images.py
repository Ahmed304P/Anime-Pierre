import re

def replace_async_image(file_path):
    with open(file_path, "r") as f:
        content = f.read()

    # Add imports
    if "import coil.compose.SubcomposeAsyncImage" not in content:
        content = content.replace(
            "import coil.compose.AsyncImage",
            "import coil.compose.SubcomposeAsyncImage\nimport com.example.util.shimmerEffect"
        )
    
    # Simple regex to replace AsyncImage with SubcomposeAsyncImage and add loading block
    # Note: Regex to replace the specific blocks accurately
    
    parts = content.split("AsyncImage(")
    new_content = parts[0]
    for part in parts[1:]:
        # Insert SubcomposeAsyncImage and loading parameter before contentDescription
        replaced = part.replace(
            "contentDescription =",
            "loading = { androidx.compose.foundation.layout.Box(modifier = androidx.compose.ui.Modifier.fillMaxSize().shimmerEffect()) },\n                contentDescription ="
        )
        new_content += "SubcomposeAsyncImage(" + replaced
        
    with open(file_path, "w") as f:
        f.write(new_content)

replace_async_image("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt")
replace_async_image("app/src/main/java/com/example/ui/components/FeaturedCarousel.kt")
