import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

old = """                    enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400)) + fadeIn(animationSpec = tween(400)),
                    exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(400)) + fadeOut(animationSpec = tween(400))"""

new = """                    enter = scaleIn(initialScale = 0.85f, animationSpec = tween(300)) + fadeIn(animationSpec = tween(300)),
                    exit = scaleOut(targetScale = 0.85f, animationSpec = tween(300)) + fadeOut(animationSpec = tween(300))"""

content = content.replace(old, new)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
