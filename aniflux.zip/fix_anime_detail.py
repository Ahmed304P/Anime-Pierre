import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

target = """                    IconButton(onClick = {
                        if (anime.isCommentsLocked) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("التعليقات مغلقه من الاداره")
                            }
                        } else {
                            socialViewModel.setShouldOpenComments(true) 
                        }
                    }) { Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chat") }"""

replacement = """                    IconButton(onClick = {
                        if (anime.isCommentsLocked) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("التعليقات مغلقه من الاداره")
                            }
                        } else {
                            socialViewModel.setShouldOpenComments(true) 
                        }
                    }) { Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chat") }"""

# Wait, the issue is that coroutineScope was completely removed. Let's add it before `IconButton`
target2 = """                actions = {
                    IconButton(onClick = {"""

replacement2 = """                actions = {
                    val coroutineScope = rememberCoroutineScope()
                    IconButton(onClick = {"""

content = content.replace(target2, replacement2)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)

