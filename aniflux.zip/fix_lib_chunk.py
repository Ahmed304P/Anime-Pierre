import re
with open("app/src/main/java/com/example/ui/screens/LibraryScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    "itemsIndexed(items = savedAnimeForCategory.chunked(2), key = { _, it -> it.first().id }) { index, pair ->",
    "val chunks = if (isGridMode) 2 else 1\n                    itemsIndexed(items = savedAnimeForCategory.chunked(chunks), key = { _, it -> it.first().id }) { index, pair ->"
)

with open("app/src/main/java/com/example/ui/screens/LibraryScreen.kt", "w") as f:
    f.write(text)
