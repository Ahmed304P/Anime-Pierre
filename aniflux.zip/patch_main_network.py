import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """        setContent {
            val viewModel: AnimeViewModel = viewModel()
            val currentTheme by viewModel.currentTheme.collectAsStateWithLifecycle()
            AniFluxTheme(appTheme = currentTheme) {
                AniFluxAppShell()
            }
        }"""

replacement = """        setContent {
            val viewModel: AnimeViewModel = viewModel()
            val currentTheme by viewModel.currentTheme.collectAsStateWithLifecycle()
            
            val context = androidx.compose.ui.platform.LocalContext.current
            val networkMonitor = remember { com.example.util.NetworkMonitor(context) }
            val isOnline by networkMonitor.isConnected.collectAsStateWithLifecycle(initialValue = true)

            AniFluxTheme(appTheme = currentTheme) {
                if (!isOnline) {
                    com.example.ui.screens.NoInternetScreen(onRetry = {
                        // The NetworkMonitor will automatically detect when it's back online
                    })
                } else {
                    AniFluxAppShell()
                }
            }
        }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
