import re
with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "r") as f:
    text = f.read()

old = """                    AnimeCard(index = index,
                        anime = anime,
                        onClick = { onOpenAnimeDetails(anime) },
                        showLargePoster = false
                    )"""

new = """                    if (isGridMode) {
                        AnimeCard(index = index,
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) },
                            showLargePoster = false
                        )
                    } else {
                        com.example.ui.components.AnimeListCard(index = index,
                            anime = anime,
                            onClick = { onOpenAnimeDetails(anime) }
                        )
                    }"""

text = text.replace(old, new)
with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "w") as f:
    f.write(text)
