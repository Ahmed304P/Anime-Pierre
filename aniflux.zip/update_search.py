import re

with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "r") as f:
    text = f.read()

text = text.replace("visible: Boolean,", "visible: Boolean,\n    isDetailScreenOpen: Boolean = false,")

old_effect = """        LaunchedEffect(visible) {
            if (visible) {
                kotlinx.coroutines.delay(300) // Wait for transition
                focusRequester.requestFocus()
                keyboardController?.show()
            } else {
                keyboardController?.hide()
            }
        }"""

new_effect = """        LaunchedEffect(visible, isDetailScreenOpen) {
            if (visible && !isDetailScreenOpen) {
                kotlinx.coroutines.delay(300) // Wait for transition
                focusRequester.requestFocus()
                keyboardController?.show()
            } else {
                keyboardController?.hide()
            }
        }"""

text = text.replace(old_effect, new_effect)

with open("app/src/main/java/com/example/ui/screens/SearchScreenOverlay.kt", "w") as f:
    f.write(text)
