import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Pass socialViewModel to AniFluxAppShell
content = content.replace(
    """fun AniFluxAppShell(
    viewModel: AnimeViewModel = viewModel()
) {""",
    """fun AniFluxAppShell(
    viewModel: AnimeViewModel = viewModel(),
    socialViewModel: com.example.ui.viewmodel.SocialViewModel = viewModel()
) {"""
)

# And pass socialViewModel to AnimeSlayerDrawerContent
content = content.replace(
    """            AnimeSlayerDrawerContent(
                selectedTab = selectedTab,
                isLoggedIn = isLoggedIn,
                userName = userName,
                userAvatar = userAvatar,
                userBanner = userBanner,
                onSelectTab = { viewModel.selectTab(it) },
                onCloseDrawer = { scope.launch { drawerState.close() } }
            )""",
    """            AnimeSlayerDrawerContent(
                selectedTab = selectedTab,
                isLoggedIn = isLoggedIn,
                userName = userName,
                userAvatar = userAvatar,
                userBanner = userBanner,
                onSelectTab = { viewModel.selectTab(it) },
                onCloseDrawer = { scope.launch { drawerState.close() } },
                socialViewModel = socialViewModel,
                onNotificationClicked = {
                    if (allAnime.isNotEmpty()) {
                        viewModel.selectAnimeForDetails(allAnime.first())
                    }
                    socialViewModel.setShouldOpenComments(true)
                }
            )"""
)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
