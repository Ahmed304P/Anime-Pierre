import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

pattern = r"    val isBackEnabled = activePlayerPair != null \|\| \n        selectedAnimeDetails != null \|\| \n        isSearchOverlayVisible \|\| \n        drawerState\.isOpen \|\| \n        selectedTab != 0 \|\| \n        tabHistorySize > 0\n\n    BackHandler\(enabled = isBackEnabled\) \{\n        if \(activePlayerPair != null\) \{\n            viewModel\.closePlayer\(\)\n        \} else if \(selectedAnimeDetails != null\) \{\n            viewModel\.closeAnimeDetails\(\)\n        \} else if \(isSearchOverlayVisible\) \{\n            isSearchOverlayVisible = false\n            viewModel\.updateSearchQuery\(\"\"\)\n        \} else if \(drawerState\.isOpen\) \{\n            scope\.launch \{ drawerState\.close\(\) \}\n        \} else if \(tabHistorySize > 0\) \{\n            viewModel\.popTabStack\(\)\n        \} else if \(selectedTab != 0\) \{\n            viewModel\.setSelectedTab\(0, addToHistory = false\)\n        \}\n    \}"

replacement = """    var showExitDialog by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    BackHandler(enabled = true) {
        if (activePlayerPair != null) {
            viewModel.closePlayer()
        } else if (selectedAnimeDetails != null) {
            viewModel.closeAnimeDetails()
        } else if (isSearchOverlayVisible) {
            isSearchOverlayVisible = false
            viewModel.updateSearchQuery("")
        } else if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (tabHistorySize > 0) {
            viewModel.popTabStack()
        } else if (selectedTab != 0) {
            viewModel.setSelectedTab(0, addToHistory = false)
        } else {
            showExitDialog = true
        }
    }"""

content = re.sub(pattern, replacement, content)

target_scaffold_end = """            }
        }
    }
}"""
replacement_scaffold_end = """                
                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تأكيد الخروج", color = Color.White) },
                        text = { Text("هل أنت متأكد أنك تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("إلغاء", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }
            }
        }
    }
}"""
content = content.replace(target_scaffold_end, replacement_scaffold_end)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
