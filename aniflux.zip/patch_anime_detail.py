import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

# Add new parameters
content = content.replace(
"""    isSaved: Boolean,
    savedStatus: String?,
    onBack: () -> Unit,""",
"""    isSaved: Boolean,
    savedStatus: String?,
    watchedEpisodes: Set<Int>,
    onToggleWatched: (Int, Boolean) -> Unit,
    onBack: () -> Unit,"""
)

# Pass them to AnimeEpisodesTabContent
content = content.replace(
"""                    1 -> AnimeEpisodesTabContent(episodes, onOpenPlayer)""",
"""                    1 -> AnimeEpisodesTabContent(episodes, watchedEpisodes, onToggleWatched, onOpenPlayer)"""
)

# Update AnimeEpisodesTabContent signature
content = content.replace(
"""fun AnimeEpisodesTabContent(episodes: List<Episode>, onOpenPlayer: (Episode) -> Unit) {""",
"""fun AnimeEpisodesTabContent(episodes: List<Episode>, watchedEpisodes: Set<Int>, onToggleWatched: (Int, Boolean) -> Unit, onOpenPlayer: (Episode) -> Unit) {"""
)

# Update Row inside AnimeEpisodesTabContent
target_row = """                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = ep.titleAr, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "المدة: ${ep.durationMinutes} دقيقة • سيرفرات متعددة", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    }

                    IconButton(onClick = { onOpenPlayer(ep) }) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play", tint = AniFluxCyan)
                    }
                }"""

replacement_row = """                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = ep.titleAr, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "المدة: ${ep.durationMinutes} دقيقة • سيرفرات متعددة", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    }

                    val isWatched = watchedEpisodes.contains(ep.episodeNumber)
                    IconButton(onClick = { onToggleWatched(ep.episodeNumber, !isWatched) }) {
                        Icon(
                            imageVector = Icons.Default.Visibility, 
                            contentDescription = "Watched", 
                            tint = if (isWatched) Color(0xFFE53935) else Color.LightGray
                        )
                    }
                    IconButton(onClick = { onOpenPlayer(ep) }) {
                        Icon(imageVector = Icons.Default.ChatBubbleOutline, contentDescription = "Comments", tint = Color.LightGray)
                    }
                }"""
content = content.replace(target_row, replacement_row)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)
