import re

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "r") as f:
    content = f.read()

import_statement = "import kotlinx.coroutines.launch\n"
content = content.replace("package com.example.ui.screens", "package com.example.ui.screens\n" + import_statement)

with open("app/src/main/java/com/example/ui/screens/AnimeDetailScreen.kt", "w") as f:
    f.write(content)

