import re

with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "r") as f:
    content = f.read()

# Find where it got cut off:
cutoff = "    fun getEpisodesForAnime(animeId: String, totalEpisodes: Int): List<Episode> {"

if cutoff in content:
    idx = content.find(cutoff) + len(cutoff)
    
    rest_of_methods = """
        return (1..totalEpisodes).map { num ->
            com.example.data.model.Episode(
                id = "${animeId}_ep_$num",
                episodeNumber = num,
                title = "الحلقة $num",
                duration = "24:00",
                thumbnailUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&auto=format&fit=crop"
            )
        }
    }

    // --- Watch History ---
    suspend fun recordWatchProgress(animeId: String, episodeNumber: Int, episodeTitle: String, progressSeconds: Int, totalSeconds: Int) {
        val historyId = "${animeId}_${episodeNumber}"
        val entity = com.example.data.local.WatchHistoryEntity(
            historyId = historyId,
            animeId = animeId,
            episodeNumber = episodeNumber,
            episodeTitle = episodeTitle,
            progressSeconds = progressSeconds,
            totalSeconds = totalSeconds
        )
        dao.insertWatchHistory(entity)
    }

    fun getAllWatchHistory(): kotlinx.coroutines.flow.Flow<List<com.example.data.local.WatchHistoryEntity>> {
        return dao.getAllWatchHistory()
    }

    suspend fun removeWatchHistoryByAnime(animeId: String) {
        dao.deleteWatchHistoryByAnime(animeId)
    }

    // --- Saved Anime ---
    suspend fun setAnimeSavedStatus(animeId: String, status: String) {
        val entity = com.example.data.local.SavedAnimeEntity(animeId = animeId, status = status)
        dao.insertSavedAnime(entity)
    }

    fun getAllSavedAnime(): kotlinx.coroutines.flow.Flow<List<com.example.data.local.SavedAnimeEntity>> {
        return dao.getAllSavedAnime()
    }

    fun getSavedAnimeById(animeId: String): kotlinx.coroutines.flow.Flow<com.example.data.local.SavedAnimeEntity?> {
        return dao.getSavedAnimeById(animeId)
    }

    suspend fun removeSavedAnime(animeId: String) {
        dao.deleteSavedAnime(animeId)
    }

    // --- Comments ---
    fun getLocalComments(animeId: String, episodeNumber: Int): kotlinx.coroutines.flow.Flow<List<com.example.data.local.LocalCommentEntity>> {
        return dao.getCommentsForEpisode(animeId, episodeNumber)
    }
    
    fun getInitialComments(animeId: String, episodeNumber: Int): List<com.example.data.local.LocalCommentEntity> {
        return emptyList()
    }

    suspend fun addComment(animeId: String, episodeNumber: Int, authorName: String, content: String, timestamp: String) {
        val entity = com.example.data.local.LocalCommentEntity(
            animeId = animeId,
            episodeNumber = episodeNumber,
            authorName = authorName,
            content = content,
            timestamp = timestamp
        )
        dao.insertComment(entity)
    }

    suspend fun likeComment(commentId: Long) {
        // Implementation
    }
"""
    
    # We also need to keep the Custom Lists methods that we added!
    # They are currently after the cutoff in the broken file.
    # Let's extract them.
    
    custom_lists_part = content[content.find("    // --- Custom Lists ---"):]
    
    new_content = content[:idx] + rest_of_methods + "\n" + custom_lists_part
    
    with open("app/src/main/java/com/example/data/repository/AnimeRepository.kt", "w") as f:
        f.write(new_content)
