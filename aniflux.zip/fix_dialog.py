import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تأكيد الخروج", color = Color.White) },
                        text = { Text("هل أنت متأكد أنك تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("إلغاء", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }"""

replacement = """                if (showExitDialog) {
                    AlertDialog(
                        onDismissRequest = { showExitDialog = false },
                        title = { Text("تنبيه", color = Color.White) },
                        text = { Text("هل تريد الخروج من التطبيق؟", color = Color.LightGray) },
                        confirmButton = {
                            TextButton(onClick = { (context as? android.app.Activity)?.finish() }) {
                                Text("نعم", color = MaterialTheme.colorScheme.primary)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("لا", color = Color.Gray)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = Color.White,
                        textContentColor = Color.LightGray
                    )
                }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

